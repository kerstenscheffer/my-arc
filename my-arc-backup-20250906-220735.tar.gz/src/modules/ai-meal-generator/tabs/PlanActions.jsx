// src/modules/ai-meal-generator/tabs/PlanActions.jsx
// TAB 5: Save & Export Plan Actions - MAIN ORCHESTRATOR

import { useState } from 'react'
import { Save, Download, Send, Info } from 'lucide-react'
import SaveSection from './plan-actions/SaveSection'
import ExportSection from './plan-actions/ExportSection'
import ShareSection from './plan-actions/ShareSection'

export default function PlanActions({
  db,
  selectedClient,
  generatedPlan,
  planModifications,
  isMobile
}) {
  // States
  const [saved, setSaved] = useState(false)
  const [exportOptions, setExportOptions] = useState({
    includeMacros: true,
    includeShoppingList: true,
    includeRecipes: false,
    includePrices: false
  })
  const [emailAddress, setEmailAddress] = useState(selectedClient?.email || '')
  const [shareMessage, setShareMessage] = useState('')
  
  if (!generatedPlan?.weekPlan) {
    return (
      <div style={{
        textAlign: 'center',
        padding: '3rem',
        color: 'rgba(255,255,255,0.5)'
      }}>
        <Save size={48} style={{ marginBottom: '1rem', opacity: 0.3 }} />
        <p>Genereer en analyseer eerst een plan</p>
      </div>
    )
  }
  
  // Calculate total meals
  const totalMeals = generatedPlan.weekPlan.reduce((acc, day) => {
    const dayMeals = [day.breakfast, day.lunch, day.dinner, ...day.snacks].filter(Boolean)
    return acc + dayMeals.length
  }, 0)
  
  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      gap: isMobile ? '1rem' : '1.5rem'
    }}>
      {/* Header */}
      <div>
        <h2 style={{
          fontSize: isMobile ? '1.25rem' : '1.5rem',
          fontWeight: '700',
          color: '#fff',
          marginBottom: '0.5rem',
          display: 'flex',
          alignItems: 'center',
          gap: '0.5rem'
        }}>
          <Save size={24} style={{ color: '#ec4899' }} />
          Opslaan & Exporteren
        </h2>
        <p style={{
          fontSize: isMobile ? '0.875rem' : '0.95rem',
          color: 'rgba(255,255,255,0.6)'
        }}>
          Sla het plan op en deel het met {selectedClient?.first_name}
        </p>
      </div>
      
      {/* Save Section - MOST IMPORTANT */}
      <SaveSection
        db={db}
        selectedClient={selectedClient}
        generatedPlan={generatedPlan}
        planModifications={planModifications}
        saved={saved}
        setSaved={setSaved}
        isMobile={isMobile}
      />
      
      {/* Export Section */}
      <ExportSection
        generatedPlan={generatedPlan}
        exportOptions={exportOptions}
        setExportOptions={setExportOptions}
        isMobile={isMobile}
      />
      
      {/* Share Section */}
      <ShareSection
        selectedClient={selectedClient}
        emailAddress={emailAddress}
        setEmailAddress={setEmailAddress}
        shareMessage={shareMessage}
        setShareMessage={setShareMessage}
        isMobile={isMobile}
      />
      
      {/* Summary */}
      <div style={{
        padding: '1rem',
        background: 'linear-gradient(135deg, rgba(59, 130, 246, 0.05) 0%, rgba(59, 130, 246, 0.02) 100%)',
        borderRadius: '12px',
        border: '1px solid rgba(59, 130, 246, 0.2)'
      }}>
        <div style={{
          display: 'flex',
          gap: '0.75rem'
        }}>
          <Info size={20} style={{ color: '#3b82f6', flexShrink: 0, marginTop: '0.1rem' }} />
          <div style={{ fontSize: isMobile ? '0.85rem' : '0.9rem', color: 'rgba(255,255,255,0.7)' }}>
            <strong>Plan Samenvatting:</strong> 7 dagen • {totalMeals} maaltijden • 
            {' '}Gem. {generatedPlan.dailyTargets?.kcal || 0} kcal/dag • 
            {' '}{generatedPlan.dailyTargets?.protein || 0}g eiwit/dag
          </div>
        </div>
      </div>
    </div>
  )
}
