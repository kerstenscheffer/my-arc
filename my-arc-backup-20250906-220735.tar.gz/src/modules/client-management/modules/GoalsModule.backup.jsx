export default function GoalsModule() { return <div>Goals Module</div> }
