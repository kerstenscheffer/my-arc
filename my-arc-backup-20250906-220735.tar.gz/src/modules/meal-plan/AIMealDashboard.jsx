// src/modules/meal-plan/AIMealDashboard.jsx
import React, { useState, useEffect } from 'react'
import AIMealPlanService from './AIMealPlanService'

// Core Components
import AIDailyGoals from './components/AIDailyGoals'
import AINextMeal from './components/AINextMeal'
import AIDaySchedule from './components/AIDaySchedule'

// Modals
import AIAlternativesModal from './components/AIAlternativesModal'
import AIMealInfoModal from './components/AIMealInfoModal'

// Quick Actions & Links
import AIQuickActions from './components/AIQuickActions'

// Video Widget (existing)
import PageVideoWidget from '../videos/PageVideoWidget'

export default function AIMealDashboard({ client, onNavigate, db }) {
  const [service] = useState(() => new AIMealPlanService(db))
  const isMobile = window.innerWidth <= 768
  
  // Main state
  const [loading, setLoading] = useState(true)
  const [dashboardData, setDashboardData] = useState(null)
  const [selectedDay, setSelectedDay] = useState('today')
  
  // Modal states
  const [modals, setModals] = useState({
    alternatives: null,
    info: null,
    quickIntake: false,
    customMeal: false,
    history: false,
    mealBase: false,
    favorites: false,
    shopping: false,
    recipes: false
  })
  
  // Load dashboard data
  useEffect(() => {
    if (client?.id) {
      loadDashboardData()
    }
  }, [client])
  
  const loadDashboardData = async () => {
    setLoading(true)
    
    try {
      const data = await service.loadAIDashboardData(client.id)
      
      // FIX: Enhance dailyTotals with plan targets if missing
      if (data.dailyTotals && data.activePlan) {
        // Ensure targets come from the active plan
        const planTargets = {
          calories: data.activePlan.daily_calories || 2200,
          protein: data.activePlan.daily_protein || 165,
          carbs: data.activePlan.daily_carbs || 220,
          fat: data.activePlan.daily_fat || 73
        }
        
        // Override dailyTotals targets with plan data
        data.dailyTotals.targets = planTargets
        
        // Recalculate percentages with correct targets
        data.dailyTotals.percentages = {
          calories: Math.round((data.dailyTotals.consumed.calories / planTargets.calories) * 100),
          protein: Math.round((data.dailyTotals.consumed.protein / planTargets.protein) * 100),
          carbs: Math.round((data.dailyTotals.consumed.carbs / planTargets.carbs) * 100),
          fat: Math.round((data.dailyTotals.consumed.fat / planTargets.fat) * 100)
        }
      }
      
      // FIX: Calculate nextMeal if not properly set
      if (!data.nextMeal && data.todayMeals?.length > 0) {
        // Find first unconsumed meal
        const unconsumedMeal = data.todayMeals.find(meal => !meal.isConsumed)
        if (unconsumedMeal) {
          data.nextMeal = unconsumedMeal
        }
      }
      
      console.log('✅ Dashboard data enhanced:', {
        hasTargets: !!data.dailyTotals?.targets,
        targets: data.dailyTotals?.targets,
        consumed: data.dailyTotals?.consumed,
        nextMeal: data.nextMeal?.slot
      })
      
      setDashboardData(data)
    } catch (error) {
      console.error('Failed to load dashboard:', error)
      // Set empty data structure to prevent crashes
      setDashboardData({
        activePlan: null,
        todayMeals: [],
        nextMeal: null,
        todayProgress: null,
        dailyTotals: {
          targets: { calories: 2200, protein: 165, carbs: 220, fat: 73 },
          consumed: { calories: 0, protein: 0, carbs: 0, fat: 0 },
          percentages: { calories: 0, protein: 0, carbs: 0, fat: 0 },
          mealsConsumed: 0,
          mealsPlanned: 0
        },
        waterIntake: 0,
        todayMood: null,
        favorites: [],
        customMeals: [],
        recentHistory: []
      })
    } finally {
      setLoading(false)
    }
  }
  
  // Handler functions
  const handleUpdateWater = async (milliliters) => {
    try {
      await service.updateAIWaterIntake(client.id, milliliters)
      setDashboardData(prev => ({
        ...prev,
        waterIntake: milliliters
      }))
    } catch (error) {
      console.error('Failed to update water:', error)
    }
  }
  
  const handleMoodLog = async (moodData) => {
    try {
      const result = await service.logAIMood(client.id, moodData)
      setDashboardData(prev => ({
        ...prev,
        mood: result
      }))
      console.log('😊 Mood logged:', moodData)
      return result
    } catch (error) {
      console.error('Failed to log mood:', error)
      return null
    }
  }
  
  const handleQuickIntake = async (intakeData) => {
    try {
      await service.logManualIntake(
        client.id, 
        dashboardData.activePlan?.id,
        intakeData
      )
      // Reload to get updated totals
      await loadDashboardData()
    } catch (error) {
      console.error('Failed to log manual intake:', error)
    }
  }
  
  const handleCheckMeal = async (slot, mealData) => {
    try {
      await service.checkAIMeal(
        client.id,
        dashboardData.activePlan?.id,
        slot,
        mealData
      )
      // Reload to get updated totals and nextMeal
      await loadDashboardData()
    } catch (error) {
      console.error('Failed to check meal:', error)
    }
  }
  
  const handleUncheckMeal = async (slot) => {
    try {
      await service.uncheckAIMeal(
        client.id,
        dashboardData.activePlan?.id,
        slot
      )
      // Reload to get updated totals and nextMeal
      await loadDashboardData()
    } catch (error) {
      console.error('Failed to uncheck meal:', error)
    }
  }
  
  const handleFinishMeal = async (meal) => {
    try {
      await service.checkAIMeal(
        client.id,
        dashboardData.activePlan?.id,
        meal.slot,
        meal
      )
      // Reload to get updated totals and nextMeal
      await loadDashboardData()
    } catch (error) {
      console.error('Failed to finish meal:', error)
    }
  }
  
  const handleSwapMeal = async (originalMeal, newMealId) => {
    try {
      await service.swapAIMeal(
        client.id,
        dashboardData.activePlan?.id,
        dashboardData.dayName,
        originalMeal.slot,
        newMealId
      )
      setModals(prev => ({ ...prev, alternatives: null }))
      await loadDashboardData()
    } catch (error) {
      console.error('Failed to swap meal:', error)
    }
  }
  
  const handleDayChange = (day) => {
    setSelectedDay(day)
    // TODO: Load meals for selected day
  }
  
  // Quick Actions Handlers
  const handleOpenFavorites = () => {
    console.log('Opening favorites...')
    // TODO: Implement favorites modal
    alert('Favorieten komen binnenkort!')
  }
  
  const handleOpenCustomMeal = () => {
    console.log('Opening custom meal creator...')
    // TODO: Implement custom meal modal
    alert('Eigen maaltijden maken komt binnenkort!')
  }
  
  const handleOpenHistory = () => {
    console.log('Opening meal history...')
    // TODO: Implement history modal
    alert('Historie bekijken komt binnenkort!')
  }
  
  const handleOpenMealBase = () => {
    console.log('Opening meal database...')
    // TODO: Implement meal base modal
    alert('Meal database komt binnenkort!')
  }
  
  const handleOpenShopping = () => {
    console.log('Navigating to shopping hub...')
    // Navigate to shopping hub with shopping view
    onNavigate('shopping')
  }
  
  const handleOpenRecipes = () => {
    console.log('Navigating to recipes...')
    // Navigate to recipe library page
    onNavigate('recipe-library')
  }
  
  // Loading state
  if (loading) {
    return (
      <div style={{
        minHeight: '100vh',
        background: 'linear-gradient(180deg, #0a0a0a 0%, #171717 100%)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }}>
        <div style={{
          textAlign: 'center'
        }}>
          <div style={{
            width: '60px',
            height: '60px',
            border: '3px solid rgba(16, 185, 129, 0.2)',
            borderTopColor: '#10b981',
            borderRadius: '50%',
            animation: 'spin 1s linear infinite',
            margin: '0 auto 1.5rem'
          }} />
          <div style={{
            color: '#fff',
            fontSize: '1.1rem',
            fontWeight: '500'
          }}>
            AI Meal Dashboard laden...
          </div>
        </div>
        <style>{`
          @keyframes spin { 
            to { transform: rotate(360deg); }
          }
        `}</style>
      </div>
    )
  }
  
  // No plan state
  if (!dashboardData?.activePlan) {
    return (
      <div style={{
        minHeight: '100vh',
        background: 'linear-gradient(180deg, #0a0a0a 0%, #171717 100%)',
        padding: isMobile ? '2rem 1rem' : '4rem 2rem'
      }}>
        <div style={{
          maxWidth: '600px',
          margin: '0 auto',
          textAlign: 'center'
        }}>
          <div style={{
            width: '100px',
            height: '100px',
            background: 'linear-gradient(135deg, rgba(251, 191, 36, 0.2) 0%, rgba(251, 191, 36, 0.1) 100%)',
            borderRadius: '24px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto 2rem',
            border: '1px solid rgba(251, 191, 36, 0.3)'
          }}>
            <span style={{ fontSize: '3rem' }}>🍽️</span>
          </div>
          
          <h2 style={{
            fontSize: isMobile ? '1.5rem' : '2rem',
            fontWeight: '700',
            color: 'white',
            marginBottom: '1rem'
          }}>
            Geen actief meal plan
          </h2>
          
          <p style={{
            fontSize: isMobile ? '1rem' : '1.125rem',
            color: 'rgba(255, 255, 255, 0.6)',
            marginBottom: '2rem',
            lineHeight: 1.6
          }}>
            Je coach heeft nog geen AI meal plan voor je aangemaakt. 
            Vraag je coach om een gepersonaliseerd plan te genereren!
          </p>
          
          <button
            onClick={() => onNavigate('home')}
            style={{
              marginTop: '2rem',
              padding: isMobile ? '0.875rem 2rem' : '1rem 2.5rem',
              background: 'linear-gradient(135deg, #064e3b 0%, #10b981 100%)',
              border: '1px solid rgba(16, 185, 129, 0.3)',
              borderRadius: '14px',
              color: 'white',
              fontSize: isMobile ? '1rem' : '1.125rem',
              fontWeight: '600',
              cursor: 'pointer',
              transition: 'all 0.3s ease',
              boxShadow: '0 10px 30px rgba(16, 185, 129, 0.3)'
            }}
          >
            Terug naar Home
          </button>
        </div>
      </div>
    )
  }
  
  // Main render
  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(180deg, #0a0a0a 0%, #171717 100%)',
      paddingBottom: isMobile ? '6rem' : '2rem',
      animation: 'fadeIn 0.5s ease'
    }}>
      
      {/* 1. Daily Goals Section */}
      <AIDailyGoals
        dailyTotals={dashboardData.dailyTotals || {
          targets: { calories: 2200, protein: 165, carbs: 220, fat: 73 },
          consumed: { calories: 0, protein: 0, carbs: 0, fat: 0 },
          percentages: { calories: 0, protein: 0, carbs: 0, fat: 0 },
          mealsConsumed: 0,
          mealsPlanned: dashboardData.todayMeals?.length || 0
        }}
        waterIntake={dashboardData.waterIntake || 0}
        todayMood={dashboardData.mood}
        onUpdateWater={handleUpdateWater}
        onLogMood={handleMoodLog}
        onQuickIntake={handleQuickIntake}
        db={db}
      />
      
      {/* 2. Next Meal Section */}
      <AINextMeal
        nextMeal={dashboardData.nextMeal}
        todayMeals={dashboardData.todayMeals || []}
        onOpenInfo={(meal) => setModals(prev => ({ ...prev, info: meal }))}
        onOpenAlternatives={(meal) => setModals(prev => ({ ...prev, alternatives: meal }))}
        onFinishMeal={handleFinishMeal}
        onOpenDaySchedule={() => {
          document.getElementById('day-schedule')?.scrollIntoView({ 
            behavior: 'smooth', 
            block: 'start' 
          })
        }}
        db={db}
      />
      
      {/* 3. Quick Actions - NOW ACTIVE! */}
      <div id="quick-actions">
        <AIQuickActions
          onOpenFavorites={handleOpenFavorites}
          onOpenCustomMeal={handleOpenCustomMeal}
          onOpenHistory={handleOpenHistory}
          onOpenMealBase={handleOpenMealBase}
          onOpenShopping={handleOpenShopping}
          onOpenRecipes={handleOpenRecipes}
        />
      </div>
      
      {/* 4. Video Widget */}
      <div style={{
        padding: isMobile ? '0 1rem 1rem' : '0 1.5rem 1.5rem'
      }}>
        <PageVideoWidget
          client={client}
          db={db}
          pageContext="nutrition"
          title="Voeding & Meal Prep Video's"
          compact={true}
        />
      </div>
      
      {/* 5. Day Schedule */}
      <div id="day-schedule">
        {dashboardData.todayMeals && dashboardData.todayMeals.length > 0 && (
          <AIDaySchedule
            todayMeals={dashboardData.todayMeals}
            todayProgress={dashboardData.todayProgress}
            activePlan={dashboardData.activePlan}
            selectedDay={selectedDay}
            onDayChange={handleDayChange}
            onCheckMeal={handleCheckMeal}
            onUncheckMeal={handleUncheckMeal}
            onOpenInfo={(meal) => setModals(prev => ({ ...prev, info: meal }))}
            onOpenAlternatives={(meal) => setModals(prev => ({ ...prev, alternatives: meal }))}
            db={db}
          />
        )}
      </div>
      
      {/* MODALS */}
      
      {/* Alternatives Modal */}
      {modals.alternatives && (
        <AIAlternativesModal
          isOpen={!!modals.alternatives}
          onClose={() => setModals(prev => ({ ...prev, alternatives: null }))}
          currentMeal={modals.alternatives}
          onSelectMeal={(newMealId) => handleSwapMeal(modals.alternatives, newMealId)}
          db={db}
          service={service}
        />
      )}
      
      {/* Meal Info Modal */}
      {modals.info && (
        <AIMealInfoModal
          isOpen={!!modals.info}
          onClose={() => setModals(prev => ({ ...prev, info: null }))}
          meal={modals.info}
          db={db}
        />
      )}
      
      {/* Favorites Modal */}
      {modals.favorites && (
        <AIFavoritesModal
          isOpen={modals.favorites}
          onClose={() => setModals(prev => ({ ...prev, favorites: false }))}
          onSelectMeal={(mealId) => handleSwapMeal(dashboardData.nextMeal || dashboardData.todayMeals?.[0], mealId)}
          currentMeal={dashboardData.nextMeal}
          db={db}
          service={service}
          clientId={client.id}
        />
      )}
      
      {/* CSS */}
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
      `}</style>
    </div>
  )
}
