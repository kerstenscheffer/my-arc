// src/modules/meal-plan/components/AIDailyGoals.jsx
import React, { useState } from 'react'
import { 
  Flame, Target, Droplets, Plus, Calendar,
  Frown, Meh, CircleSlash, Smile, SmilePlus,
  TrendingUp, Zap, Activity
} from 'lucide-react'

export default function AIDailyGoals({ 
  dailyTotals, 
  waterIntake, 
  todayMood,
  onUpdateWater,
  onLogMood,
  onQuickIntake,
  db 
}) {
  const isMobile = window.innerWidth <= 768
  const [showIntakeModal, setShowIntakeModal] = useState(false)
  const [showMoodSelector, setShowMoodSelector] = useState(false)
  const [selectedMoodScore, setSelectedMoodScore] = useState(todayMood?.mood_score || null)
  
  // Calculate progress
  const caloriesPercent = Math.min(100, Math.round(
    ((dailyTotals?.consumed?.calories || 0) / (dailyTotals?.targets?.calories || 2200)) * 100
  ))
  const proteinPercent = Math.min(100, Math.round(
    ((dailyTotals?.consumed?.protein || 0) / (dailyTotals?.targets?.protein || 165)) * 100
  ))
  const waterPercent = Math.min(100, Math.round((waterIntake / 2000) * 100))
  
  // Mood icons with Lucide
  const moodIcons = [
    { icon: Frown, color: '#ef4444', label: 'Slecht' },
    { icon: Meh, color: '#f97316', label: 'Matig' },
    { icon: CircleSlash, color: '#eab308', label: 'Neutraal' },
    { icon: Smile, color: '#84cc16', label: 'Goed' },
    { icon: SmilePlus, color: '#10b981', label: 'Geweldig' }
  ]
  
  const handleWaterClick = () => {
    const newAmount = waterIntake >= 3000 ? 0 : waterIntake + 200
    onUpdateWater(newAmount)
  }
  
  const handleMoodSelect = async (score) => {
    console.log('🎯 Selecting mood:', score)
    
    // Update local state immediately for UI feedback
    setSelectedMoodScore(score)
    setShowMoodSelector(false)
    
    // Save to database
    const result = await onLogMood({ score, reason: null })
    
    // If save failed, revert to previous state
    if (!result) {
      console.error('❌ Failed to save mood, reverting')
      setSelectedMoodScore(todayMood?.mood_score || null)
    }
  }

  return (
    <div style={{ 
      padding: isMobile ? '0.75rem' : '1.5rem'
    }}>
      {/* Header - Compact */}
      <div style={{
        marginBottom: isMobile ? '0.5rem' : '1rem'
      }}>
        <h2 style={{
          fontSize: isMobile ? '1rem' : '1.25rem',
          fontWeight: '700',
          margin: 0,
          background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
          backgroundClip: 'text',
          marginBottom: '0.15rem'
        }}>
          Dagelijkse Doelen
        </h2>
        <p style={{
          fontSize: isMobile ? '0.65rem' : '0.75rem',
          color: 'rgba(255, 255, 255, 0.4)',
          margin: 0,
          fontWeight: '500'
        }}>
          {dailyTotals?.mealsConsumed || 0} van {dailyTotals?.mealsPlanned || 4} maaltijden • {new Date().toLocaleDateString('nl-NL', { weekday: 'long' })}
        </p>
      </div>
      
      {/* Primary Goals Cards - 60/40 RATIO */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1.5fr 1fr', // 60/40 ratio
        gap: isMobile ? '0.5rem' : '1rem',
        marginBottom: isMobile ? '0.625rem' : '1rem'
      }}>
        {/* Calories Card - 60% width */}
        <div style={{
          background: caloriesPercent >= 90 
            ? 'linear-gradient(135deg, rgba(16, 185, 129, 0.12) 0%, rgba(16, 185, 129, 0.04) 100%)'
            : 'linear-gradient(135deg, rgba(249, 115, 22, 0.06) 0%, rgba(16, 185, 129, 0.02) 100%)',
          borderRadius: isMobile ? '14px' : '16px',
          padding: isMobile ? '0.875rem' : '1.25rem',
          border: caloriesPercent >= 90 
            ? '1px solid rgba(16, 185, 129, 0.25)'
            : '1px solid rgba(249, 115, 22, 0.12)',
          position: 'relative',
          backdropFilter: 'blur(20px)',
          boxShadow: caloriesPercent >= 90
            ? '0 8px 32px rgba(16, 185, 129, 0.15), inset 0 1px 0 rgba(255, 255, 255, 0.03)'
            : '0 8px 32px rgba(0, 0, 0, 0.15), inset 0 1px 0 rgba(255, 255, 255, 0.02)',
          minHeight: isMobile ? '95px' : '110px',
          overflow: 'hidden'
        }}>
          {/* Glass morphism gloss overlay */}
          <div style={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            height: '50%',
            background: 'linear-gradient(180deg, rgba(255, 255, 255, 0.04) 0%, transparent 100%)',
            pointerEvents: 'none'
          }} />
          
          {/* Top Row - Label & Percentage */}
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: isMobile ? '0.4rem' : '0.625rem'
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.35rem'
            }}>
              <Flame size={isMobile ? 13 : 14} color={caloriesPercent >= 90 ? '#10b981' : '#f97316'} style={{ opacity: 0.9 }} />
              <span style={{
                fontSize: isMobile ? '0.6rem' : '0.65rem',
                color: 'rgba(255, 255, 255, 0.35)',
                fontWeight: '600',
                textTransform: 'uppercase',
                letterSpacing: '0.05em'
              }}>
                Calorieën
              </span>
            </div>
            
            <div style={{
              background: caloriesPercent >= 90 
                ? 'linear-gradient(135deg, rgba(16, 185, 129, 0.25) 0%, rgba(16, 185, 129, 0.15) 100%)'
                : caloriesPercent >= 70
                ? 'linear-gradient(135deg, rgba(16, 185, 129, 0.15) 0%, rgba(249, 115, 22, 0.1) 100%)'
                : 'linear-gradient(135deg, rgba(249, 115, 22, 0.2) 0%, rgba(249, 115, 22, 0.1) 100%)',
              padding: '0.1rem 0.35rem',
              borderRadius: '5px',
              fontSize: isMobile ? '0.6rem' : '0.65rem',
              fontWeight: '700',
              color: caloriesPercent >= 90 ? '#10b981' : caloriesPercent >= 70 ? '#84cc16' : '#f97316',
              border: `1px solid ${caloriesPercent >= 90 ? 'rgba(16, 185, 129, 0.3)' : 'rgba(249, 115, 22, 0.2)'}`,
              backdropFilter: 'blur(10px)'
            }}>
              {caloriesPercent}%
            </div>
          </div>
          
          {/* Middle Row - Horizontal layout */}
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: isMobile ? '0.625rem' : '1rem'
          }}>
            {/* Icon */}
            <div style={{
              width: isMobile ? '32px' : '40px',
              height: isMobile ? '32px' : '40px',
              borderRadius: '10px',
              background: caloriesPercent >= 90
                ? 'linear-gradient(135deg, rgba(16, 185, 129, 0.2) 0%, rgba(16, 185, 129, 0.1) 100%)'
                : 'linear-gradient(135deg, rgba(249, 115, 22, 0.12) 0%, rgba(16, 185, 129, 0.05) 100%)',
              border: `1px solid ${caloriesPercent >= 90 ? 'rgba(16, 185, 129, 0.25)' : 'rgba(249, 115, 22, 0.15)'}`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0,
              backdropFilter: 'blur(10px)',
              boxShadow: 'inset 0 1px 0 rgba(255, 255, 255, 0.05)'
            }}>
              <Activity size={isMobile ? 16 : 20} color={caloriesPercent >= 90 ? '#10b981' : '#f97316'} />
            </div>
            
            {/* Numbers - More space for calories */}
            <div style={{ flex: 1 }}>
              <div style={{
                display: 'flex',
                alignItems: 'baseline',
                gap: '0.3rem',
                flexWrap: 'wrap'
              }}>
                <span style={{
                  fontSize: isMobile ? '1.5rem' : '2rem',
                  fontWeight: '800',
                  color: caloriesPercent >= 90 ? '#10b981' : '#f97316',
                  lineHeight: 1,
                  letterSpacing: '-0.02em'
                }}>
                  {dailyTotals?.consumed?.calories || 0}
                </span>
                <span style={{
                  fontSize: isMobile ? '0.7rem' : '0.875rem',
                  color: 'rgba(255, 255, 255, 0.25)',
                  fontWeight: '500'
                }}>
                  / {dailyTotals?.targets?.calories || 2200}
                </span>
              </div>
            </div>
          </div>
          
          {/* Progress Bar */}
          <div style={{
            marginTop: isMobile ? '0.5rem' : '0.75rem',
            height: '6px',
            background: 'rgba(0, 0, 0, 0.5)',
            borderRadius: '3px',
            overflow: 'hidden',
            border: '1px solid rgba(16, 185, 129, 0.1)'
          }}>
            <div style={{
              height: '100%',
              width: `${caloriesPercent}%`,
              background: caloriesPercent >= 90
                ? 'linear-gradient(90deg, #10b981 0%, #34d399 100%)'
                : caloriesPercent >= 70
                ? 'linear-gradient(90deg, #f97316 0%, #10b981 100%)'
                : 'linear-gradient(90deg, #f97316 0%, #fb923c 100%)',
              transition: 'width 0.5s cubic-bezier(0.4, 0, 0.2, 1)',
              boxShadow: caloriesPercent >= 90 
                ? '0 0 15px rgba(16, 185, 129, 0.5)'
                : '0 0 10px rgba(249, 115, 22, 0.4)'
            }} />
          </div>
        </div>
        
        {/* Protein Card - 40% width */}
        <div style={{
          background: proteinPercent >= 90 
            ? 'linear-gradient(135deg, rgba(16, 185, 129, 0.12) 0%, rgba(16, 185, 129, 0.04) 100%)'
            : 'linear-gradient(135deg, rgba(139, 92, 246, 0.06) 0%, rgba(16, 185, 129, 0.02) 100%)',
          borderRadius: isMobile ? '14px' : '16px',
          padding: isMobile ? '0.875rem 0.75rem' : '1.25rem 1rem',
          border: proteinPercent >= 90 
            ? '1px solid rgba(16, 185, 129, 0.25)'
            : '1px solid rgba(139, 92, 246, 0.12)',
          position: 'relative',
          backdropFilter: 'blur(20px)',
          boxShadow: proteinPercent >= 90
            ? '0 8px 32px rgba(16, 185, 129, 0.15), inset 0 1px 0 rgba(255, 255, 255, 0.03)'
            : '0 8px 32px rgba(0, 0, 0, 0.15), inset 0 1px 0 rgba(255, 255, 255, 0.02)',
          minHeight: isMobile ? '95px' : '110px',
          overflow: 'hidden'
        }}>
          {/* Glass morphism gloss overlay */}
          <div style={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            height: '50%',
            background: 'linear-gradient(180deg, rgba(255, 255, 255, 0.04) 0%, transparent 100%)',
            pointerEvents: 'none'
          }} />
          
          {/* Top Row - Label & Percentage */}
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: isMobile ? '0.4rem' : '0.625rem'
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.3rem'
            }}>
              <Target size={isMobile ? 13 : 14} color={proteinPercent >= 90 ? '#10b981' : '#8b5cf6'} style={{ opacity: 0.9 }} />
              <span style={{
                fontSize: isMobile ? '0.6rem' : '0.65rem',
                color: 'rgba(255, 255, 255, 0.35)',
                fontWeight: '600',
                textTransform: 'uppercase',
                letterSpacing: '0.03em'
              }}>
                Eiwitten
              </span>
            </div>
            
            <div style={{
              background: proteinPercent >= 90 
                ? 'linear-gradient(135deg, rgba(16, 185, 129, 0.25) 0%, rgba(16, 185, 129, 0.15) 100%)'
                : proteinPercent >= 70
                ? 'linear-gradient(135deg, rgba(16, 185, 129, 0.15) 0%, rgba(139, 92, 246, 0.1) 100%)'
                : 'linear-gradient(135deg, rgba(139, 92, 246, 0.2) 0%, rgba(139, 92, 246, 0.1) 100%)',
              padding: '0.1rem 0.3rem',
              borderRadius: '5px',
              fontSize: isMobile ? '0.6rem' : '0.65rem',
              fontWeight: '700',
              color: proteinPercent >= 90 ? '#10b981' : proteinPercent >= 70 ? '#84cc16' : '#8b5cf6',
              border: `1px solid ${proteinPercent >= 90 ? 'rgba(16, 185, 129, 0.3)' : 'rgba(139, 92, 246, 0.2)'}`,
              backdropFilter: 'blur(10px)'
            }}>
              {proteinPercent}%
            </div>
          </div>
          
          {/* Middle Row - Horizontal layout COMPACT */}
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: isMobile ? '0.5rem' : '0.75rem'
          }}>
            {/* Icon */}
            <div style={{
              width: isMobile ? '28px' : '36px',
              height: isMobile ? '28px' : '36px',
              borderRadius: '8px',
              background: proteinPercent >= 90
                ? 'linear-gradient(135deg, rgba(16, 185, 129, 0.2) 0%, rgba(16, 185, 129, 0.1) 100%)'
                : 'linear-gradient(135deg, rgba(139, 92, 246, 0.12) 0%, rgba(16, 185, 129, 0.05) 100%)',
              border: `1px solid ${proteinPercent >= 90 ? 'rgba(16, 185, 129, 0.25)' : 'rgba(139, 92, 246, 0.15)'}`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0,
              backdropFilter: 'blur(10px)',
              boxShadow: 'inset 0 1px 0 rgba(255, 255, 255, 0.05)'
            }}>
              <Zap size={isMobile ? 14 : 18} color={proteinPercent >= 90 ? '#10b981' : '#8b5cf6'} />
            </div>
            
            {/* Numbers */}
            <div style={{ flex: 1 }}>
              <div style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '0.1rem'
              }}>
                <span style={{
                  fontSize: isMobile ? '1.3rem' : '1.75rem',
                  fontWeight: '800',
                  color: proteinPercent >= 90 ? '#10b981' : '#8b5cf6',
                  lineHeight: 1,
                  letterSpacing: '-0.02em'
                }}>
                  {dailyTotals?.consumed?.protein || 0}
                </span>
                <span style={{
                  fontSize: isMobile ? '0.65rem' : '0.75rem',
                  color: 'rgba(255, 255, 255, 0.25)',
                  fontWeight: '500'
                }}>
                  / {dailyTotals?.targets?.protein || 165} g
                </span>
              </div>
            </div>
          </div>
          
          {/* Progress Bar */}
          <div style={{
            marginTop: isMobile ? '0.5rem' : '0.625rem',
            height: '6px',
            background: 'rgba(0, 0, 0, 0.5)',
            borderRadius: '3px',
            overflow: 'hidden',
            border: '1px solid rgba(16, 185, 129, 0.1)'
          }}>
            <div style={{
              height: '100%',
              width: `${proteinPercent}%`,
              background: proteinPercent >= 90
                ? 'linear-gradient(90deg, #10b981 0%, #34d399 100%)'
                : proteinPercent >= 70
                ? 'linear-gradient(90deg, #8b5cf6 0%, #10b981 100%)'
                : 'linear-gradient(90deg, #8b5cf6 0%, #a78bfa 100%)',
              transition: 'width 0.5s cubic-bezier(0.4, 0, 0.2, 1)',
              boxShadow: proteinPercent >= 90 
                ? '0 0 15px rgba(16, 185, 129, 0.5)'
                : '0 0 10px rgba(139, 92, 246, 0.4)'
            }} />
          </div>
        </div>
      </div>
      
      {/* Action Bar - Premium Glass with green accents */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '2fr 1fr 1fr',
        gap: isMobile ? '0.5rem' : '0.75rem'
      }}>
        {/* Water Intake - 50% */}
        <button
          onClick={handleWaterClick}
          style={{
            background: waterPercent >= 80
              ? 'linear-gradient(135deg, rgba(16, 185, 129, 0.08) 0%, rgba(16, 185, 129, 0.03) 100%)'
              : 'linear-gradient(135deg, rgba(59, 130, 246, 0.06) 0%, rgba(59, 130, 246, 0.02) 100%)',
            borderRadius: '14px',
            padding: isMobile ? '0.75rem' : '0.875rem',
            border: waterPercent >= 80
              ? '1px solid rgba(16, 185, 129, 0.15)'
              : '1px solid rgba(59, 130, 246, 0.12)',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
            touchAction: 'manipulation',
            WebkitTapHighlightColor: 'transparent',
            minHeight: '48px',
            backdropFilter: 'blur(20px)',
            boxShadow: '0 4px 16px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.03)',
            position: 'relative',
            overflow: 'hidden'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = 'translateY(-1px)'
            e.currentTarget.style.boxShadow = '0 6px 20px rgba(0, 0, 0, 0.15), inset 0 1px 0 rgba(255, 255, 255, 0.05)'
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'translateY(0)'
            e.currentTarget.style.boxShadow = '0 4px 16px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.03)'
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <Droplets size={16} color={waterPercent >= 80 ? '#10b981' : '#3b82f6'} />
            <div style={{ textAlign: 'left' }}>
              <div style={{
                fontSize: '0.6rem',
                color: 'rgba(255, 255, 255, 0.35)',
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
                marginBottom: '0.1rem'
              }}>
                Water
              </div>
              <div style={{
                fontSize: isMobile ? '0.95rem' : '1.05rem',
                fontWeight: '700',
                color: waterPercent >= 80 ? '#10b981' : '#3b82f6'
              }}>
                {(waterIntake / 1000).toFixed(1)}L
              </div>
            </div>
          </div>
          
          {/* Mini circular progress */}
          <div style={{
            width: '36px',
            height: '36px',
            position: 'relative'
          }}>
            <svg width="36" height="36" style={{ transform: 'rotate(-90deg)' }}>
              <circle
                cx="18" cy="18" r="15"
                fill="none"
                stroke="rgba(59, 130, 246, 0.08)"
                strokeWidth="2"
              />
              <circle
                cx="18" cy="18" r="15"
                fill="none"
                stroke={waterPercent >= 80 ? '#10b981' : '#3b82f6'}
                strokeWidth="2"
                strokeDasharray={`${waterPercent * 0.94} 94`}
                strokeLinecap="round"
                style={{ transition: 'all 0.5s cubic-bezier(0.4, 0, 0.2, 1)' }}
              />
            </svg>
            <div style={{
              position: 'absolute',
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              fontSize: '0.6rem',
              fontWeight: '700',
              color: waterPercent >= 80 ? '#10b981' : '#3b82f6'
            }}>
              {waterPercent}%
            </div>
          </div>
        </button>
        
        {/* Mood Log - 25% ALWAYS CLICKABLE */}
        <button
          onClick={() => setShowMoodSelector(true)}
          style={{
            background: selectedMoodScore 
              ? 'linear-gradient(135deg, rgba(16, 185, 129, 0.08) 0%, rgba(16, 185, 129, 0.03) 100%)'
              : 'linear-gradient(135deg, rgba(255, 255, 255, 0.03) 0%, rgba(255, 255, 255, 0.01) 100%)',
            borderRadius: '14px',
            padding: isMobile ? '0.75rem 0.5rem' : '0.875rem 0.625rem',
            border: '1px solid ' + (selectedMoodScore ? 'rgba(16, 185, 129, 0.15)' : 'rgba(255, 255, 255, 0.06)'),
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexDirection: 'column',
            gap: '0.2rem',
            transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
            touchAction: 'manipulation',
            WebkitTapHighlightColor: 'transparent',
            minHeight: '48px',
            backdropFilter: 'blur(20px)',
            boxShadow: '0 4px 16px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.03)',
            position: 'relative'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = 'translateY(-1px)'
            e.currentTarget.style.boxShadow = '0 6px 20px rgba(0, 0, 0, 0.15), inset 0 1px 0 rgba(255, 255, 255, 0.05)'
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'translateY(0)'
            e.currentTarget.style.boxShadow = '0 4px 16px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.03)'
          }}
        >
          {selectedMoodScore ? (
            React.createElement(moodIcons[selectedMoodScore - 1].icon, {
              size: isMobile ? 20 : 22,
              color: moodIcons[selectedMoodScore - 1].color
            })
          ) : (
            <SmilePlus size={isMobile ? 20 : 22} color="rgba(255, 255, 255, 0.4)" />
          )}
          <div style={{
            fontSize: '0.6rem',
            color: selectedMoodScore ? 'rgba(16, 185, 129, 0.8)' : 'rgba(255, 255, 255, 0.35)',
            textTransform: 'uppercase',
            letterSpacing: '0.05em'
          }}>
            {selectedMoodScore ? moodIcons[selectedMoodScore - 1].label : 'Mood?'}
          </div>
        </button>
        
        {/* Quick Log - 25% always green */}
        <button
          onClick={() => setShowIntakeModal(true)}
          style={{
            background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.08) 0%, rgba(16, 185, 129, 0.03) 100%)',
            borderRadius: '14px',
            padding: isMobile ? '0.75rem 0.5rem' : '0.875rem 0.625rem',
            border: '1px solid rgba(16, 185, 129, 0.15)',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexDirection: 'column',
            gap: '0.2rem',
            transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
            touchAction: 'manipulation',
            WebkitTapHighlightColor: 'transparent',
            minHeight: '48px',
            backdropFilter: 'blur(20px)',
            boxShadow: '0 4px 16px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.03)'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.background = 'linear-gradient(135deg, rgba(16, 185, 129, 0.12) 0%, rgba(16, 185, 129, 0.05) 100%)'
            e.currentTarget.style.transform = 'translateY(-1px)'
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.background = 'linear-gradient(135deg, rgba(16, 185, 129, 0.08) 0%, rgba(16, 185, 129, 0.03) 100%)'
            e.currentTarget.style.transform = 'translateY(0)'
          }}
        >
          <Plus size={isMobile ? 18 : 20} color="#10b981" />
          <div style={{
            fontSize: '0.6rem',
            color: 'rgba(16, 185, 129, 0.8)',
            textTransform: 'uppercase',
            letterSpacing: '0.05em'
          }}>
            Quick
          </div>
        </button>
      </div>
      
      {/* Mood Selector Popup - Shows current mood highlighted */}
      {showMoodSelector && (
        <div style={{
          position: 'fixed',
          bottom: '80px',
          left: '50%',
          transform: 'translateX(-50%)',
          background: 'linear-gradient(135deg, rgba(17, 17, 17, 0.98) 0%, rgba(10, 10, 10, 0.98) 100%)',
          backdropFilter: 'blur(30px)',
          borderRadius: '20px',
          border: '1px solid rgba(255, 255, 255, 0.1)',
          padding: '1.25rem',
          zIndex: 100,
          boxShadow: '0 20px 40px rgba(0, 0, 0, 0.6), inset 0 1px 0 rgba(255, 255, 255, 0.05)',
          display: 'flex',
          gap: '0.75rem'
        }}>
          {moodIcons.map((mood, index) => (
            <button
              key={index}
              onClick={() => handleMoodSelect(index + 1)}
              style={{
                background: selectedMoodScore === (index + 1)
                  ? `${mood.color}20`
                  : 'rgba(255, 255, 255, 0.03)',
                border: selectedMoodScore === (index + 1)
                  ? `2px solid ${mood.color}`
                  : '1px solid rgba(255, 255, 255, 0.08)',
                cursor: 'pointer',
                padding: '0.75rem',
                borderRadius: '12px',
                transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
                touchAction: 'manipulation',
                WebkitTapHighlightColor: 'transparent',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                backdropFilter: 'blur(10px)',
                transform: selectedMoodScore === (index + 1) ? 'scale(1.1)' : 'scale(1)',
                boxShadow: selectedMoodScore === (index + 1) ? `0 8px 20px ${mood.color}30` : 'none'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'scale(1.1) translateY(-2px)'
                e.currentTarget.style.background = `${mood.color}15`
                e.currentTarget.style.borderColor = mood.color
                e.currentTarget.style.boxShadow = `0 8px 20px ${mood.color}30`
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = selectedMoodScore === (index + 1) ? 'scale(1.1)' : 'scale(1)'
                e.currentTarget.style.background = selectedMoodScore === (index + 1) 
                  ? `${mood.color}20`
                  : 'rgba(255, 255, 255, 0.03)'
                e.currentTarget.style.borderColor = selectedMoodScore === (index + 1)
                  ? mood.color
                  : 'rgba(255, 255, 255, 0.08)'
                e.currentTarget.style.boxShadow = selectedMoodScore === (index + 1) ? `0 8px 20px ${mood.color}30` : 'none'
              }}
            >
              {React.createElement(mood.icon, {
                size: 24,
                color: mood.color
              })}
            </button>
          ))}
          
          {/* Close button */}
          <button
            onClick={() => setShowMoodSelector(false)}
            style={{
              position: 'absolute',
              top: '-10px',
              right: '-10px',
              width: '28px',
              height: '28px',
              borderRadius: '50%',
              background: 'rgba(255, 255, 255, 0.1)',
              border: '1px solid rgba(255, 255, 255, 0.2)',
              color: 'rgba(255, 255, 255, 0.6)',
              fontSize: '18px',
              fontWeight: '300',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              transition: 'all 0.2s ease'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = 'rgba(255, 255, 255, 0.15)'
              e.currentTarget.style.color = 'rgba(255, 255, 255, 0.9)'
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = 'rgba(255, 255, 255, 0.1)'
              e.currentTarget.style.color = 'rgba(255, 255, 255, 0.6)'
            }}
          >
            ×
          </button>
        </div>
      )}
      
      {/* Quick Intake Modal */}
      {showIntakeModal && (
        <QuickIntakeModal
          onClose={() => setShowIntakeModal(false)}
          onSave={onQuickIntake}
          targets={dailyTotals?.targets}
          isMobile={isMobile}
        />
      )}
    </div>
  )
}

// Quick Intake Modal - Premium Glass with green theme
function QuickIntakeModal({ onClose, onSave, targets, isMobile }) {
  const [selectedType, setSelectedType] = useState('percentage')
  const [percentage, setPercentage] = useState(null)
  const [exactValues, setExactValues] = useState({ calories: '', protein: '' })
  
  const percentageOptions = [
    { value: 100, label: '100%', color: '#10b981' },
    { value: 80, label: '80%', color: '#84cc16' },
    { value: 60, label: '60%', color: '#fbbf24' },
    { value: 40, label: '40%', color: '#f97316' }
  ]
  
  const handleSave = () => {
    if (selectedType === 'percentage' && percentage) {
      onSave({
        type: 'percentage',
        percentage: percentage,
        calories: Math.round((targets?.calories || 2200) * (percentage / 100)),
        protein: Math.round((targets?.protein || 165) * (percentage / 100)),
        carbs: Math.round((targets?.carbs || 220) * (percentage / 100)),
        fat: Math.round((targets?.fat || 73) * (percentage / 100))
      })
    } else if (selectedType === 'exact' && exactValues.calories) {
      onSave({
        type: 'exact',
        calories: parseInt(exactValues.calories),
        protein: parseInt(exactValues.protein) || 0,
        carbs: parseInt(exactValues.carbs) || 0,
        fat: parseInt(exactValues.fat) || 0
      })
    }
    onClose()
  }
  
  return (
    <div style={{
      position: 'fixed',
      inset: 0,
      background: 'rgba(0, 0, 0, 0.85)',
      backdropFilter: 'blur(20px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 1000,
      padding: '1rem'
    }}>
      <div style={{
        background: 'linear-gradient(135deg, rgba(26, 26, 26, 0.98) 0%, rgba(15, 15, 15, 0.98) 100%)',
        borderRadius: isMobile ? '20px' : '24px',
        padding: isMobile ? '1.5rem' : '2rem',
        width: '100%',
        maxWidth: '500px',
        border: '1px solid rgba(255, 255, 255, 0.08)',
        boxShadow: '0 30px 60px rgba(0, 0, 0, 0.6), inset 0 1px 0 rgba(255, 255, 255, 0.05)',
        backdropFilter: 'blur(30px)'
      }}>
        <h3 style={{
          fontSize: isMobile ? '1.25rem' : '1.5rem',
          fontWeight: '700',
          background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
          backgroundClip: 'text',
          marginBottom: '1.5rem'
        }}>
          Quick Intake Log
        </h3>
        
        {/* Type Selector */}
        <div style={{
          display: 'flex',
          gap: '0.5rem',
          marginBottom: '1.5rem'
        }}>
          <button
            onClick={() => setSelectedType('percentage')}
            style={{
              flex: 1,
              padding: '0.75rem',
              background: selectedType === 'percentage' 
                ? 'linear-gradient(135deg, rgba(16, 185, 129, 0.15) 0%, rgba(16, 185, 129, 0.08) 100%)'
                : 'rgba(255, 255, 255, 0.03)',
              border: '1px solid ' + (selectedType === 'percentage' ? 'rgba(16, 185, 129, 0.3)' : 'rgba(255, 255, 255, 0.08)'),
              borderRadius: '12px',
              color: selectedType === 'percentage' ? '#10b981' : 'rgba(255, 255, 255, 0.5)',
              fontWeight: '600',
              cursor: 'pointer',
              transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
              backdropFilter: 'blur(10px)'
            }}
          >
            Percentage
          </button>
          <button
            onClick={() => setSelectedType('exact')}
            style={{
              flex: 1,
              padding: '0.75rem',
              background: selectedType === 'exact' 
                ? 'linear-gradient(135deg, rgba(16, 185, 129, 0.15) 0%, rgba(16, 185, 129, 0.08) 100%)'
                : 'rgba(255, 255, 255, 0.03)',
              border: '1px solid ' + (selectedType === 'exact' ? 'rgba(16, 185, 129, 0.3)' : 'rgba(255, 255, 255, 0.08)'),
              borderRadius: '12px',
              color: selectedType === 'exact' ? '#10b981' : 'rgba(255, 255, 255, 0.5)',
              fontWeight: '600',
              cursor: 'pointer',
              transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
              backdropFilter: 'blur(10px)'
            }}
          >
            Exacte Waardes
          </button>
        </div>
        
        {/* Content */}
        {selectedType === 'percentage' ? (
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(2, 1fr)',
            gap: '1rem'
          }}>
            {percentageOptions.map(option => (
              <button
                key={option.value}
                onClick={() => setPercentage(option.value)}
                style={{
                  padding: isMobile ? '1.25rem' : '1.5rem',
                  background: percentage === option.value 
                    ? `linear-gradient(135deg, ${option.color}15 0%, ${option.color}08 100%)`
                    : 'rgba(255, 255, 255, 0.03)',
                  border: `1.5px solid ${percentage === option.value ? option.color : 'rgba(255, 255, 255, 0.08)'}`,
                  borderRadius: '16px',
                  cursor: 'pointer',
                  transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
                  transform: percentage === option.value ? 'scale(1.02)' : 'scale(1)',
                  touchAction: 'manipulation',
                  WebkitTapHighlightColor: 'transparent',
                  backdropFilter: 'blur(10px)',
                  boxShadow: percentage === option.value ? `0 8px 20px ${option.color}20` : 'none'
                }}
              >
                <div style={{
                  fontSize: isMobile ? '1.5rem' : '1.75rem',
                  fontWeight: '800',
                  color: percentage === option.value ? option.color : 'rgba(255, 255, 255, 0.7)',
                  marginBottom: '0.25rem'
                }}>
                  {option.label}
                </div>
                <div style={{
                  fontSize: '0.75rem',
                  color: 'rgba(255, 255, 255, 0.4)'
                }}>
                  {Math.round((targets?.calories || 2200) * (option.value / 100))} kcal
                </div>
              </button>
            ))}
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <input
              type="number"
              value={exactValues.calories}
              onChange={(e) => setExactValues(prev => ({ ...prev, calories: e.target.value }))}
              placeholder="Calorieën"
              style={{
                width: '100%',
                padding: '0.875rem',
                background: 'rgba(255, 255, 255, 0.03)',
                border: '1px solid rgba(255, 255, 255, 0.08)',
                borderRadius: '10px',
                color: 'white',
                fontSize: '1rem',
                outline: 'none',
                backdropFilter: 'blur(10px)'
              }}
            />
            <input
              type="number"
              value={exactValues.protein}
              onChange={(e) => setExactValues(prev => ({ ...prev, protein: e.target.value }))}
              placeholder="Eiwitten (g)"
              style={{
                width: '100%',
                padding: '0.875rem',
                background: 'rgba(255, 255, 255, 0.03)',
                border: '1px solid rgba(255, 255, 255, 0.08)',
                borderRadius: '10px',
                color: 'white',
                fontSize: '1rem',
                outline: 'none',
                backdropFilter: 'blur(10px)'
              }}
            />
          </div>
        )}
        
        {/* Actions */}
        <div style={{
          display: 'flex',
          gap: '1rem',
          marginTop: '1.5rem'
        }}>
          <button
            onClick={onClose}
            style={{
              flex: 1,
              padding: '0.875rem',
              background: 'rgba(255, 255, 255, 0.03)',
              border: '1px solid rgba(255, 255, 255, 0.08)',
              borderRadius: '12px',
              color: 'rgba(255, 255, 255, 0.5)',
              fontWeight: '600',
              cursor: 'pointer',
              backdropFilter: 'blur(10px)',
              transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)'
            }}
          >
            Annuleren
          </button>
          <button
            onClick={handleSave}
            disabled={selectedType === 'percentage' ? !percentage : !exactValues.calories}
            style={{
              flex: 1,
              padding: '0.875rem',
              background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.9) 0%, rgba(5, 150, 105, 0.9) 100%)',
              border: '1px solid rgba(16, 185, 129, 0.3)',
              borderRadius: '12px',
              color: 'white',
              fontWeight: '600',
              cursor: 'pointer',
              opacity: (selectedType === 'percentage' ? !percentage : !exactValues.calories) ? 0.5 : 1,
              boxShadow: '0 4px 15px rgba(16, 185, 129, 0.3)',
              transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)'
            }}
          >
            Opslaan
          </button>
        </div>
      </div>
    </div>
  )
}
