// src/modules/shopping/ShoppingHub.jsx
import React, { useState, useEffect } from 'react'
import ShoppingService from './ShoppingService'
import { 
  ShoppingCart, Package, BookOpen, Sparkles, 
  ChevronRight, TrendingUp
} from 'lucide-react'

// Tab Components
import WeekShoppingTab from './tabs/WeekShoppingTab'
import TemplatesTab from './tabs/TemplatesTab'
import KnowledgeTab from './tabs/KnowledgeTab'
import BuilderTab from './tabs/BuilderTab'

export default function ShoppingHub({ client, db, onNavigate }) {
  const [service] = useState(() => new ShoppingService(db))
  const isMobile = window.innerWidth <= 768
  const [activeTab, setActiveTab] = useState('week')
  const [loading, setLoading] = useState(true)
  const [shoppingData, setShoppingData] = useState(null)
  
  // Load shopping data on mount
  useEffect(() => {
    if (client?.id) {
      loadShoppingData()
    }
  }, [client])
  
  const loadShoppingData = async () => {
    setLoading(true)
    try {
      // Get active meal plan with shopping list
      const activePlan = await service.getActiveMealPlan(client.id)
      
      // Parse shopping list if exists
      let shoppingList = null
      if (activePlan?.shopping_list) {
        shoppingList = typeof activePlan.shopping_list === 'string' 
          ? JSON.parse(activePlan.shopping_list)
          : activePlan.shopping_list
      }
      
      // Get any saved progress
      const progress = await service.getShoppingProgress(client.id, activePlan?.id)
      
      setShoppingData({
        activePlan,
        shoppingList,
        progress,
        weekStructure: activePlan?.week_structure
      })
    } catch (error) {
      console.error('Failed to load shopping data:', error)
      setShoppingData({
        activePlan: null,
        shoppingList: null,
        progress: null
      })
    } finally {
      setLoading(false)
    }
  }
  
  // Tab configuration
  const tabs = [
    {
      id: 'week',
      label: 'Week Boodschappen',
      icon: ShoppingCart,
      color: '#10b981',
      gradient: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
      available: true
    },
    {
      id: 'templates',
      label: 'Smart Templates',
      icon: Package,
      color: '#8b5cf6',
      gradient: 'linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%)',
      available: false,
      comingSoon: true
    },
    {
      id: 'knowledge',
      label: 'Shopping Tips',
      icon: BookOpen,
      color: '#f59e0b',
      gradient: 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)',
      available: true
    },
    {
      id: 'builder',
      label: 'Custom Builder',
      icon: Sparkles,
      color: '#ec4899',
      gradient: 'linear-gradient(135deg, #ec4899 0%, #db2777 100%)',
      available: false,
      comingSoon: true
    }
  ]
  
  const activeTabConfig = tabs.find(t => t.id === activeTab)
  
  if (loading) {
    return (
      <div style={{
        minHeight: '100vh',
        background: 'linear-gradient(180deg, #0a0a0a 0%, #171717 100%)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{
            width: '60px',
            height: '60px',
            border: '3px solid rgba(16, 185, 129, 0.2)',
            borderTopColor: '#10b981',
            borderRadius: '50%',
            animation: 'spin 1s linear infinite',
            margin: '0 auto 1.5rem'
          }} />
          <div style={{
            color: '#fff',
            fontSize: '1.1rem',
            fontWeight: '500'
          }}>
            Shopping laden...
          </div>
        </div>
        <style>{`
          @keyframes spin { 
            to { transform: rotate(360deg); }
          }
        `}</style>
      </div>
    )
  }
  
  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(180deg, #0a0a0a 0%, #171717 100%)',
      paddingBottom: isMobile ? '6rem' : '2rem'
    }}>
      {/* Premium Header */}
      <div style={{
        padding: isMobile ? '1rem' : '1.5rem',
        borderBottom: '1px solid rgba(16, 185, 129, 0.08)',
        background: 'linear-gradient(180deg, rgba(16, 185, 129, 0.05) 0%, transparent 100%)',
        marginBottom: '1rem'
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: '1rem'
        }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '0.75rem'
          }}>
            <div style={{
              width: '40px',
              height: '40px',
              background: activeTabConfig.gradient,
              borderRadius: '12px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: `0 8px 20px ${activeTabConfig.color}30`
            }}>
              <ShoppingCart size={22} color="white" />
            </div>
            <div>
              <h1 style={{
                fontSize: isMobile ? '1.25rem' : '1.5rem',
                fontWeight: '800',
                background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text',
                letterSpacing: '-0.02em',
                margin: 0
              }}>
                Smart Shopping
              </h1>
              {shoppingData?.activePlan && (
                <p style={{
                  fontSize: isMobile ? '0.75rem' : '0.825rem',
                  color: 'rgba(16, 185, 129, 0.7)',
                  margin: '0.125rem 0 0 0',
                  fontWeight: '500'
                }}>
                  {shoppingData.activePlan.template_name || 'Week Plan'}
                </p>
              )}
            </div>
          </div>
          
          {/* Stats Badge */}
          {shoppingData?.shoppingList && (
            <div style={{
              padding: '0.5rem 1rem',
              background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.12) 0%, rgba(16, 185, 129, 0.04) 100%)',
              borderRadius: '10px',
              border: '1px solid rgba(16, 185, 129, 0.15)'
            }}>
              <div style={{
                fontSize: '0.75rem',
                color: 'rgba(16, 185, 129, 0.5)',
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
                fontWeight: '700'
              }}>
                Items
              </div>
              <div style={{
                fontSize: '1.25rem',
                fontWeight: '800',
                color: '#10b981'
              }}>
                {shoppingData.shoppingList?.items?.length || 0}
              </div>
            </div>
          )}
        </div>
        
        {/* Tab Navigation */}
        <div style={{
          display: 'flex',
          gap: '0.5rem',
          overflowX: 'auto',
          paddingBottom: '0.25rem'
        }}>
          {tabs.map(tab => {
            const Icon = tab.icon
            const isActive = activeTab === tab.id
            
            return (
              <button
                key={tab.id}
                onClick={() => tab.available && setActiveTab(tab.id)}
                disabled={!tab.available}
                style={{
                  flex: isMobile ? '0 0 auto' : 1,
                  minWidth: isMobile ? '120px' : 'auto',
                  padding: isMobile ? '0.75rem 1rem' : '0.875rem 1.25rem',
                  background: isActive
                    ? `linear-gradient(135deg, ${tab.color}20 0%, ${tab.color}10 100%)`
                    : 'rgba(17, 17, 17, 0.5)',
                  backdropFilter: 'blur(10px)',
                  border: `1px solid ${isActive ? tab.color + '30' : 'rgba(16, 185, 129, 0.08)'}`,
                  borderRadius: '12px',
                  color: isActive ? tab.color : tab.available ? 'rgba(255, 255, 255, 0.7)' : 'rgba(255, 255, 255, 0.3)',
                  fontSize: isMobile ? '0.875rem' : '0.95rem',
                  fontWeight: '600',
                  cursor: tab.available ? 'pointer' : 'not-allowed',
                  transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.5rem',
                  position: 'relative',
                  touchAction: 'manipulation',
                  WebkitTapHighlightColor: 'transparent',
                  opacity: tab.available ? 1 : 0.5
                }}
                onMouseEnter={(e) => {
                  if (tab.available && !isActive) {
                    e.currentTarget.style.background = `linear-gradient(135deg, ${tab.color}15 0%, ${tab.color}08 100%)`
                    e.currentTarget.style.transform = 'translateY(-2px)'
                  }
                }}
                onMouseLeave={(e) => {
                  if (tab.available && !isActive) {
                    e.currentTarget.style.background = 'rgba(17, 17, 17, 0.5)'
                    e.currentTarget.style.transform = 'translateY(0)'
                  }
                }}
              >
                <Icon size={18} />
                <span>{tab.label}</span>
                {tab.comingSoon && (
                  <span style={{
                    position: 'absolute',
                    top: '-8px',
                    right: '-8px',
                    padding: '0.125rem 0.375rem',
                    background: tab.gradient,
                    borderRadius: '6px',
                    fontSize: '0.65rem',
                    fontWeight: '700',
                    color: 'white',
                    textTransform: 'uppercase',
                    letterSpacing: '0.05em'
                  }}>
                    Soon
                  </span>
                )}
              </button>
            )
          })}
        </div>
      </div>
      
      {/* Tab Content */}
      <div style={{ 
        animation: 'fadeIn 0.3s ease',
        minHeight: '60vh'
      }}>
        {activeTab === 'week' && (
          <WeekShoppingTab
            shoppingData={shoppingData}
            service={service}
            client={client}
            onRefresh={loadShoppingData}
            db={db}
          />
        )}
        
        {activeTab === 'templates' && (
          <TemplatesTab />
        )}
        
        {activeTab === 'knowledge' && (
          <KnowledgeTab
            db={db}
            client={client}
          />
        )}
        
        {activeTab === 'builder' && (
          <BuilderTab />
        )}
      </div>
      
      {/* CSS */}
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  )
}
