// src/modules/shopping/tabs/WeekShoppingTab.jsx
import React, { useState, useEffect } from 'react'
import { 
  ShoppingCart, Check, Share2, Download, 
  Package, TrendingUp, AlertCircle, RefreshCw,
  ChevronDown, ChevronUp, DollarSign, Loader
} from 'lucide-react'

export default function WeekShoppingTab({ shoppingData, service, client, onRefresh, db }) {
  const isMobile = window.innerWidth <= 768
  const [checkedItems, setCheckedItems] = useState({})
  const [expandedCategories, setExpandedCategories] = useState({})
  const [showExportMenu, setShowExportMenu] = useState(false)
  const [shoppingList, setShoppingList] = useState(null)
  const [generating, setGenerating] = useState(false)
  const [copySuccess, setCopySuccess] = useState(false)
  
  // Load or generate shopping list
  useEffect(() => {
    if (shoppingData?.shoppingList) {
      setShoppingList(shoppingData.shoppingList)
    } else if (shoppingData?.weekStructure && !generating && !shoppingList) {
      generateShoppingList()
    }
    
    // Load saved progress
    if (shoppingData?.progress?.purchased_items) {
      setCheckedItems(shoppingData.progress.purchased_items)
    }
  }, [shoppingData])
  
  const generateShoppingList = async () => {
    if (!shoppingData?.weekStructure) return
    
    setGenerating(true)
    try {
      const list = await service.generateShoppingList(shoppingData.weekStructure)
      setShoppingList(list)
      
      // Save to database
      if (shoppingData.activePlan?.id && list.items.length > 0) {
        await db.supabase
          .from('client_meal_plans')
          .update({ shopping_list: list })
          .eq('id', shoppingData.activePlan.id)
      }
    } catch (error) {
      console.error('Failed to generate shopping list:', error)
    } finally {
      setGenerating(false)
    }
  }
  
  const handleCheckItem = async (itemId) => {
    const newCheckedItems = {
      ...checkedItems,
      [itemId]: !checkedItems[itemId]
    }
    setCheckedItems(newCheckedItems)
    
    // Save progress
    if (shoppingData?.activePlan?.id) {
      await service.saveShoppingProgress(
        client.id,
        shoppingData.activePlan.id,
        { checkedItems: newCheckedItems }
      )
    }
  }
  
  const toggleCategory = (category) => {
    setExpandedCategories(prev => ({
      ...prev,
      [category]: !prev[category]
    }))
  }
  
  const handleShare = () => {
    if (!shoppingList) return
    const text = service.generateExportText(shoppingList)
    service.shareViaWhatsApp(text)
    setShowExportMenu(false)
  }
  
  const handleCopy = async () => {
    if (!shoppingList) return
    const text = service.generateExportText(shoppingList)
    const success = await service.copyToClipboard(text)
    if (success) {
      setCopySuccess(true)
      setTimeout(() => setCopySuccess(false), 2000)
    }
    setShowExportMenu(false)
  }
  
  // Group items by category
  const groupedItems = shoppingList?.items?.reduce((acc, item) => {
    const category = item.category || 'other'
    if (!acc[category]) {
      acc[category] = []
    }
    acc[category].push(item)
    return acc
  }, {}) || {}
  
  // Category display names
  const categoryNames = {
    'protein': '🥩 Eiwitten',
    'carbs': '🌾 Koolhydraten',
    'vegetables': '🥬 Groenten',
    'fats': '🥑 Vetten',
    'dairy': '🥛 Zuivel',
    'fruit': '🍎 Fruit',
    'other': '📦 Overig'
  }
  
  // Calculate progress
  const totalItems = shoppingList?.items?.length || 0
  const checkedCount = Object.values(checkedItems).filter(Boolean).length
  const progress = totalItems > 0 ? Math.round((checkedCount / totalItems) * 100) : 0
  
  // No plan state
  if (!shoppingData?.activePlan) {
    return (
      <div style={{
        padding: isMobile ? '2rem 1rem' : '3rem 2rem',
        textAlign: 'center'
      }}>
        <div style={{
          width: '80px',
          height: '80px',
          background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.15) 0%, rgba(16, 185, 129, 0.08) 100%)',
          borderRadius: '20px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          margin: '0 auto 1.5rem'
        }}>
          <ShoppingCart size={32} color="#10b981" />
        </div>
        
        <h3 style={{
          fontSize: isMobile ? '1.25rem' : '1.5rem',
          fontWeight: '700',
          color: 'white',
          marginBottom: '0.75rem'
        }}>
          Geen actief meal plan
        </h3>
        
        <p style={{
          fontSize: isMobile ? '0.95rem' : '1.05rem',
          color: 'rgba(255, 255, 255, 0.6)',
          lineHeight: 1.6
        }}>
          Je hebt een actief AI meal plan nodig om de boodschappenlijst te gebruiken.
        </p>
      </div>
    )
  }
  
  // Loading/Generating state
  if (generating) {
    return (
      <div style={{
        padding: '3rem',
        textAlign: 'center'
      }}>
        <div style={{
          width: '48px',
          height: '48px',
          border: '3px solid rgba(16, 185, 129, 0.15)',
          borderTopColor: '#10b981',
          borderRadius: '50%',
          animation: 'spin 1s linear infinite',
          margin: '0 auto 1.5rem'
        }} />
        <p style={{ color: 'rgba(255, 255, 255, 0.7)' }}>
          Boodschappenlijst genereren...
        </p>
        <style>{`
          @keyframes spin {
            to { transform: rotate(360deg); }
          }
        `}</style>
      </div>
    )
  }
  
  // Empty list state
  if (!shoppingList || shoppingList.items.length === 0) {
    return (
      <div style={{
        padding: isMobile ? '2rem 1rem' : '3rem 2rem',
        textAlign: 'center'
      }}>
        <div style={{
          width: '80px',
          height: '80px',
          background: 'linear-gradient(135deg, rgba(251, 191, 36, 0.15) 0%, rgba(251, 191, 36, 0.08) 100%)',
          borderRadius: '20px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          margin: '0 auto 1.5rem'
        }}>
          <AlertCircle size={32} color="#fbbf24" />
        </div>
        
        <h3 style={{
          fontSize: isMobile ? '1.25rem' : '1.5rem',
          fontWeight: '700',
          color: 'white',
          marginBottom: '0.75rem'
        }}>
          Geen items gevonden
        </h3>
        
        <p style={{
          fontSize: isMobile ? '0.95rem' : '1.05rem',
          color: 'rgba(255, 255, 255, 0.6)',
          lineHeight: 1.6,
          marginBottom: '1.5rem'
        }}>
          Er konden geen ingrediënten gevonden worden voor je meal plan.
        </p>
        
        <button
          onClick={onRefresh}
          style={{
            padding: isMobile ? '0.75rem 1.5rem' : '0.875rem 2rem',
            background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
            border: '1px solid rgba(16, 185, 129, 0.25)',
            borderRadius: '12px',
            color: 'white',
            fontSize: isMobile ? '0.9rem' : '0.95rem',
            fontWeight: '600',
            cursor: 'pointer',
            display: 'inline-flex',
            alignItems: 'center',
            gap: '0.5rem',
            transition: 'all 0.3s ease'
          }}
        >
          <RefreshCw size={18} />
          Opnieuw proberen
        </button>
      </div>
    )
  }
  
  return (
    <div style={{ padding: isMobile ? '0 0.75rem' : '0 1.5rem' }}>
      {/* Stats Bar */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(3, 1fr)',
        gap: isMobile ? '0.75rem' : '1rem',
        marginBottom: '1.5rem'
      }}>
        {/* Progress Card */}
        <div style={{
          background: `linear-gradient(135deg, rgba(16, 185, 129, ${progress >= 90 ? '0.15' : '0.12'}) 0%, rgba(16, 185, 129, 0.04) 100%)`,
          backdropFilter: 'blur(10px)',
          borderRadius: '14px',
          padding: isMobile ? '0.875rem' : '1rem',
          border: `1px solid rgba(16, 185, 129, ${progress >= 90 ? '0.15' : '0.08'})`,
          transition: 'all 0.3s ease'
        }}>
          <div style={{
            fontSize: isMobile ? '0.6rem' : '0.65rem',
            color: 'rgba(16, 185, 129, 0.5)',
            textTransform: 'uppercase',
            letterSpacing: '0.05em',
            fontWeight: '700',
            marginBottom: '0.375rem'
          }}>
            Progress
          </div>
          <div style={{
            fontSize: isMobile ? '1.25rem' : '1.5rem',
            fontWeight: '800',
            color: progress >= 90 ? '#10b981' : '#f97316',
            letterSpacing: '-0.02em',
            transition: 'color 0.3s ease'
          }}>
            {progress}%
          </div>
          <div style={{
            fontSize: isMobile ? '0.75rem' : '0.825rem',
            color: 'rgba(255, 255, 255, 0.5)',
            marginTop: '0.125rem'
          }}>
            {checkedCount}/{totalItems}
          </div>
        </div>
        
        {/* Items Card */}
        <div style={{
          background: 'rgba(17, 17, 17, 0.5)',
          backdropFilter: 'blur(10px)',
          borderRadius: '14px',
          padding: isMobile ? '0.875rem' : '1rem',
          border: '1px solid rgba(16, 185, 129, 0.08)'
        }}>
          <div style={{
            fontSize: isMobile ? '0.6rem' : '0.65rem',
            color: 'rgba(255, 255, 255, 0.35)',
            textTransform: 'uppercase',
            letterSpacing: '0.05em',
            fontWeight: '700',
            marginBottom: '0.375rem'
          }}>
            Items
          </div>
          <div style={{
            fontSize: isMobile ? '1.25rem' : '1.5rem',
            fontWeight: '800',
            color: 'white',
            letterSpacing: '-0.02em'
          }}>
            {totalItems}
          </div>
          <div style={{
            fontSize: isMobile ? '0.75rem' : '0.825rem',
            color: 'rgba(255, 255, 255, 0.5)',
            marginTop: '0.125rem'
          }}>
            Uniek
          </div>
        </div>
        
        {/* Cost Card */}
        <div style={{
          background: 'rgba(17, 17, 17, 0.5)',
          backdropFilter: 'blur(10px)',
          borderRadius: '14px',
          padding: isMobile ? '0.875rem' : '1rem',
          border: '1px solid rgba(16, 185, 129, 0.08)'
        }}>
          <div style={{
            fontSize: isMobile ? '0.6rem' : '0.65rem',
            color: 'rgba(255, 255, 255, 0.35)',
            textTransform: 'uppercase',
            letterSpacing: '0.05em',
            fontWeight: '700',
            marginBottom: '0.375rem'
          }}>
            Geschat
          </div>
          <div style={{
            fontSize: isMobile ? '1.25rem' : '1.5rem',
            fontWeight: '800',
            color: 'white',
            letterSpacing: '-0.02em'
          }}>
            €{shoppingList?.totalCost?.toFixed(0) || '0'}
          </div>
          <div style={{
            fontSize: isMobile ? '0.75rem' : '0.825rem',
            color: 'rgba(255, 255, 255, 0.5)',
            marginTop: '0.125rem'
          }}>
            Totaal
          </div>
        </div>
      </div>
      
      {/* Action Buttons */}
      <div style={{
        display: 'flex',
        gap: '0.75rem',
        marginBottom: '1.5rem',
        position: 'relative'
      }}>
        <button
          onClick={() => setShowExportMenu(!showExportMenu)}
          style={{
            flex: 1,
            padding: isMobile ? '0.75rem' : '0.875rem',
            background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
            border: '1px solid rgba(16, 185, 129, 0.25)',
            borderRadius: '12px',
            color: 'white',
            fontSize: isMobile ? '0.9rem' : '0.95rem',
            fontWeight: '600',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '0.5rem',
            transition: 'all 0.3s ease',
            touchAction: 'manipulation',
            WebkitTapHighlightColor: 'transparent'
          }}
        >
          <Share2 size={18} />
          Delen
        </button>
        
        <button
          onClick={() => {
            setShoppingList(null)
            generateShoppingList()
          }}
          style={{
            padding: isMobile ? '0.75rem 1rem' : '0.875rem 1.25rem',
            background: 'rgba(17, 17, 17, 0.5)',
            border: '1px solid rgba(16, 185, 129, 0.08)',
            borderRadius: '12px',
            color: 'rgba(255, 255, 255, 0.7)',
            fontSize: isMobile ? '0.9rem' : '0.95rem',
            fontWeight: '600',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '0.5rem',
            transition: 'all 0.3s ease'
          }}
        >
          <RefreshCw size={18} />
        </button>
        
        {/* Copy Success Indicator */}
        {copySuccess && (
          <div style={{
            position: 'absolute',
            top: '-40px',
            left: '50%',
            transform: 'translateX(-50%)',
            background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
            padding: '0.5rem 1rem',
            borderRadius: '8px',
            color: 'white',
            fontSize: '0.875rem',
            fontWeight: '600',
            boxShadow: '0 4px 12px rgba(16, 185, 129, 0.4)',
            animation: 'slideDown 0.3s ease'
          }}>
            ✓ Gekopieerd!
          </div>
        )}
      </div>
      
      {/* Export Menu */}
      {showExportMenu && (
        <div style={{
          marginBottom: '1rem',
          padding: '0.75rem',
          background: 'rgba(17, 17, 17, 0.5)',
          borderRadius: '12px',
          border: '1px solid rgba(16, 185, 129, 0.08)',
          animation: 'slideDown 0.3s ease'
        }}>
          <button
            onClick={handleShare}
            style={{
              width: '100%',
              padding: '0.75rem',
              background: 'linear-gradient(135deg, rgba(37, 211, 102, 0.15) 0%, rgba(37, 211, 102, 0.08) 100%)',
              border: '1px solid rgba(37, 211, 102, 0.2)',
              borderRadius: '10px',
              color: '#25d366',
              fontSize: '0.95rem',
              fontWeight: '600',
              cursor: 'pointer',
              marginBottom: '0.5rem',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '0.5rem'
            }}
          >
            📱 WhatsApp
          </button>
          <button
            onClick={handleCopy}
            style={{
              width: '100%',
              padding: '0.75rem',
              background: 'rgba(17, 17, 17, 0.5)',
              border: '1px solid rgba(255, 255, 255, 0.1)',
              borderRadius: '10px',
              color: 'rgba(255, 255, 255, 0.7)',
              fontSize: '0.95rem',
              fontWeight: '600',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '0.5rem'
            }}
          >
            📋 Kopieer tekst
          </button>
        </div>
      )}
      
      {/* Shopping List */}
      <div style={{ marginBottom: '2rem' }}>
        {Object.entries(groupedItems).map(([category, items]) => (
          <CategorySection
            key={category}
            category={category}
            categoryName={categoryNames[category] || category}
            items={items}
            checkedItems={checkedItems}
            expanded={expandedCategories[category] !== false}
            onToggle={() => toggleCategory(category)}
            onCheckItem={handleCheckItem}
            service={service}
            isMobile={isMobile}
          />
        ))}
      </div>
      
      {/* Bulk Deals Alert */}
      {shoppingList?.items?.some(item => item.totalAmount > 500) && (
        <div style={{
          padding: isMobile ? '1rem' : '1.25rem',
          background: 'linear-gradient(135deg, rgba(251, 191, 36, 0.12) 0%, rgba(251, 191, 36, 0.04) 100%)',
          borderRadius: '14px',
          border: '1px solid rgba(251, 191, 36, 0.15)',
          marginBottom: '2rem'
        }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '0.75rem'
          }}>
            <TrendingUp size={20} color="#fbbf24" />
            <div>
              <p style={{
                fontSize: isMobile ? '0.9rem' : '0.95rem',
                fontWeight: '600',
                color: '#fbbf24',
                marginBottom: '0.25rem'
              }}>
                Bulk Tip
              </p>
              <p style={{
                fontSize: isMobile ? '0.8rem' : '0.85rem',
                color: 'rgba(255, 255, 255, 0.6)'
              }}>
                Overweeg grootverpakkingen voor items boven 500g
              </p>
            </div>
          </div>
        </div>
      )}
      
      <style>{`
        @keyframes slideDown {
          from {
            opacity: 0;
            transform: translateY(-10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  )
}

// Category Section Component
function CategorySection({ category, categoryName, items, checkedItems, expanded, onToggle, onCheckItem, service, isMobile }) {
  const checkedCount = items.filter(item => checkedItems[item.id]).length
  const categoryTotal = items.reduce((sum, item) => sum + (item.estimatedCost || 0), 0)
  const allChecked = checkedCount === items.length
  
  return (
    <div style={{
      marginBottom: '1rem',
      background: 'rgba(17, 17, 17, 0.3)',
      borderRadius: '14px',
      border: `1px solid rgba(16, 185, 129, ${allChecked ? '0.15' : '0.08'})`,
      overflow: 'hidden',
      transition: 'all 0.3s ease'
    }}>
      {/* Category Header */}
      <button
        onClick={onToggle}
        style={{
          width: '100%',
          padding: isMobile ? '1rem' : '1.25rem',
          background: allChecked 
            ? 'linear-gradient(135deg, rgba(16, 185, 129, 0.12) 0%, rgba(16, 185, 129, 0.04) 100%)'
            : 'linear-gradient(135deg, rgba(16, 185, 129, 0.08) 0%, rgba(16, 185, 129, 0.02) 100%)',
          border: 'none',
          borderBottom: expanded ? '1px solid rgba(16, 185, 129, 0.08)' : 'none',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          cursor: 'pointer',
          transition: 'all 0.3s ease'
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <div style={{ textAlign: 'left' }}>
            <h3 style={{
              fontSize: isMobile ? '1rem' : '1.125rem',
              fontWeight: '700',
              color: allChecked ? '#10b981' : 'white',
              margin: 0,
              transition: 'color 0.3s ease'
            }}>
              {categoryName}
            </h3>
            <p style={{
              fontSize: isMobile ? '0.75rem' : '0.825rem',
              color: 'rgba(255, 255, 255, 0.5)',
              margin: '0.125rem 0 0 0'
            }}>
              {checkedCount}/{items.length} items • €{categoryTotal.toFixed(2)}
            </p>
          </div>
        </div>
        
        {expanded ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
      </button>
      
      {/* Items List */}
      {expanded && (
        <div style={{ padding: isMobile ? '0.5rem' : '0.75rem' }}>
          {items.map(item => (
            <ShoppingItem
              key={item.id}
              item={item}
              checked={checkedItems[item.id]}
              onCheck={() => onCheckItem(item.id)}
              service={service}
              isMobile={isMobile}
            />
          ))}
        </div>
      )}
    </div>
  )
}

// Shopping Item Component
function ShoppingItem({ item, checked, onCheck, service, isMobile }) {
  return (
    <button
      onClick={onCheck}
      style={{
        width: '100%',
        padding: isMobile ? '0.75rem' : '0.875rem',
        marginBottom: '0.5rem',
        background: checked
          ? 'linear-gradient(135deg, rgba(16, 185, 129, 0.15) 0%, rgba(16, 185, 129, 0.08) 100%)'
          : 'rgba(17, 17, 17, 0.5)',
        border: `1px solid ${checked ? 'rgba(16, 185, 129, 0.25)' : 'rgba(16, 185, 129, 0.08)'}`,
        borderRadius: '10px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        cursor: 'pointer',
        transition: 'all 0.2s ease',
        opacity: checked ? 0.7 : 1,
        textDecoration: checked ? 'line-through' : 'none',
        touchAction: 'manipulation',
        WebkitTapHighlightColor: 'transparent'
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
        <div style={{
          width: '24px',
          height: '24px',
          borderRadius: '8px',
          background: checked 
            ? 'linear-gradient(135deg, #10b981 0%, #059669 100%)'
            : 'rgba(255, 255, 255, 0.1)',
          border: checked ? 'none' : '2px solid rgba(255, 255, 255, 0.2)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexShrink: 0,
          transition: 'all 0.2s ease'
        }}>
          {checked && <Check size={16} color="white" strokeWidth={3} />}
        </div>
        
        <div style={{ textAlign: 'left' }}>
          <p style={{
            fontSize: isMobile ? '0.9rem' : '0.95rem',
            fontWeight: '600',
            color: checked ? 'rgba(255, 255, 255, 0.5)' : 'white',
            margin: 0
          }}>
            {item.name}
          </p>
          <p style={{
            fontSize: isMobile ? '0.75rem' : '0.825rem',
            color: 'rgba(16, 185, 129, 0.6)',
            margin: '0.125rem 0 0 0'
          }}>
            {service.formatAmount(item.totalAmount, item.unit)}
          </p>
        </div>
      </div>
      
      {item.estimatedCost > 0 && (
        <span style={{
          fontSize: isMobile ? '0.875rem' : '0.925rem',
          fontWeight: '600',
          color: 'rgba(255, 255, 255, 0.5)'
        }}>
          €{item.estimatedCost.toFixed(2)}
        </span>
      )}
    </button>
  )
}
