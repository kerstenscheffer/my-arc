export default function ClientProfile({ client, user }) {
  return (
    <div className="myarc-animate-in">
      <h2 className="myarc-card-title">👤 Profile</h2>
      <p className="myarc-text-gray">Coming soon...</p>
    </div>
  )
}
