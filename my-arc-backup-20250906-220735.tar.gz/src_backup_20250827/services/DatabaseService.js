// src/services/DatabaseService.js
// 🔧 FIXED VERSION - Met correcte tabel namen en error handling

import { supabase } from '../lib/supabase'
import { extendDatabaseService } from './DatabaseServiceOptimized'
import NotificationService from '../modules/notifications/NotificationService';






class DatabaseServiceClass {
  constructor() {
    // Cache management
    this.supabase = supabase
    this.cache = new Map()
    this.cacheTimeout = 5 * 60 * 1000 // 5 minutes
    this.notifications = new NotificationService(this.supabase);  // GOED - gebruik this.supabase



    // Event subscribers
    this.subscribers = new Map()
    
    // Current user cache
    this.currentUser = null
    
    console.log('🚀 DatabaseService initialized!')
  }

  // ===== CACHE MANAGEMENT =====
  getCached(key) {
    const cached = this.cache.get(key)
    if (cached && Date.now() - cached.timestamp < this.cacheTimeout) {
      return cached.data
    }
    return null
  }

  setCache(key, data) {
    this.cache.set(key, {
      data,
      timestamp: Date.now()
    })
  }

  clearCache(pattern = null) {
    if (pattern) {
      for (const key of this.cache.keys()) {
        if (key.includes(pattern)) {
          this.cache.delete(key)
        }
      }
    } else {
      this.cache.clear()
    }
  }

  // ===== EVENT SYSTEM =====
  subscribe(event, callback) {
    if (!this.subscribers.has(event)) {
      this.subscribers.set(event, [])
    }
    this.subscribers.get(event).push(callback)
    
    // Return unsubscribe function
    return () => {
      const callbacks = this.subscribers.get(event) || []
      const index = callbacks.indexOf(callback)
      if (index > -1) {
        callbacks.splice(index, 1)
      }
    }
  }

  emit(event, data) {
    const callbacks = this.subscribers.get(event) || []
    callbacks.forEach(callback => callback(data))
  }

  // ===== AUTH METHODS =====
  async getCurrentUser() {
    try {
      // Check cache first
      if (this.currentUser) return this.currentUser
      
      const { data: { user }, error } = await supabase.auth.getUser()
      if (error) throw error
      
      this.currentUser = user
      return user
    } catch (error) {
      console.error('❌ Get current user failed:', error)
      return null
    }
  }

  async signIn(email, password) {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      })
      if (error) throw error
      
      this.currentUser = data.user
      this.clearCache() // Clear cache on login
      return data
    } catch (error) {
      console.error('❌ Sign in failed:', error)
      throw error
    }
  }

  async signOut() {
    try {
      const { error } = await supabase.auth.signOut()
      if (error) throw error
      
      this.currentUser = null
      this.clearCache()
      return true
    } catch (error) {
      console.error('❌ Sign out failed:', error)
      throw error
    }
  }

async resetPassword(email, redirectTo = null) {
  try {
    const options = {}
    
    if (redirectTo) {
      options.redirectTo = redirectTo
    } else {
      options.redirectTo = `${window.location.origin}/reset-password`
    }
    
    const { data, error } = await supabase.auth.resetPasswordForEmail(email, options)
    
    if (error) throw error
    
    console.log('✅ Password reset email sent to:', email)
    return { success: true, data }
    
  } catch (error) {
    console.error('❌ Password reset failed:', error)
    throw error
  }
}

// VOEG deze NIEUWE methods toe NA resetPassword:
async updatePassword(newPassword) {
  try {
    const { data, error } = await supabase.auth.updateUser({
      password: newPassword
    })
    
    if (error) throw error
    
    console.log('✅ Password updated successfully')
    this.clearCache()
    return { success: true, data }
    
  } catch (error) {
    console.error('❌ Password update failed:', error)
    throw error
  }
}

async verifyPasswordResetToken() {
  try {
    const { data: { session }, error } = await supabase.auth.getSession()
    
    if (error) throw error
    
    return session !== null
    
  } catch (error) {
    console.error('❌ Token verification failed:', error)
    return false
  }
}
  // ===== CLIENT MANAGEMENT =====
  async getClients(trainerId = null) {
    try {
      const tid = trainerId || (await this.getCurrentUser())?.id
      if (!tid) throw new Error('No trainer ID')
      
      const cacheKey = `clients_${tid}`
      const cached = this.getCached(cacheKey)
      if (cached) return cached
      
      const { data, error } = await supabase
        .from('clients')
        .select('*')
        .eq('trainer_id', tid)
        .eq('status', 'active')
        .order('created_at', { ascending: false })
      
      if (error) throw error
      
      this.setCache(cacheKey, data)
      return data || []
    } catch (error) {
      console.error('❌ Get clients failed:', error)
      return []
    }
  }

  async getClient(clientId) {
    try {
      const cacheKey = `client_${clientId}`
      const cached = this.getCached(cacheKey)
      if (cached) return cached
      
      const { data, error } = await supabase
        .from('clients')
        .select('*')
        .eq('id', clientId)
        .single()
      
      if (error) throw error
      
      this.setCache(cacheKey, data)
      return data
    } catch (error) {
      console.error('❌ Get client failed:', error)
      return null
    }
  }

  async createClient(clientData, trainerId) {
    try {
      const { data, error } = await supabase
        .from('clients')
        .insert([{
          ...clientData,
          trainer_id: trainerId,
          status: 'active'
        }])
        .select()
        .single()
      
      if (error) throw error
      
      this.clearCache('clients')
      this.emit('clients', await this.getClients())
      
      // Generate temp password
      const tempPassword = `Welcome${Math.floor(Math.random() * 10000)}!`
      
      return {
        client: data,
        loginCredentials: {
          email: clientData.email,
          password: tempPassword
        }
      }
    } catch (error) {
      console.error('❌ Create client failed:', error)
      throw error
    }
  }

  async updateClient(clientId, updates) {
    try {
      const { data, error } = await supabase
        .from('clients')
        .update(updates)
        .eq('id', clientId)
        .select()
        .single()
      
      if (error) throw error
      
      this.clearCache(`client_${clientId}`)
      this.clearCache('clients')
      this.emit('clients', await this.getClients())
      
      return data
    } catch (error) {
      console.error('❌ Update client failed:', error)
      throw error
    }
  }

  async getClientByEmail(email) {
    try {
      const { data, error } = await supabase
        .from('clients')
        .select('*')
        .eq('email', email)
        .single()
      
      if (error && error.code !== 'PGRST116') throw error
      return data
    } catch (error) {
      console.error('❌ Get client by email failed:', error)
      return null
    }
  }

  // ===== WORKOUT METHODS =====
  async getWorkoutSchemas(userId = null) {
    try {
      const uid = userId || (await this.getCurrentUser())?.id
      if (!uid) return []
      
      const { data, error } = await supabase
        .from('workout_schemas')
        .select('*')
        .eq('user_id', uid)
        .order('created_at', { ascending: false })
      
      if (error) throw error
      return data || []
    } catch (error) {
      console.error('❌ Get workout schemas failed:', error)
      return []
    }
  }

  async getClientSchema(clientId) {
    try {
      // First get the client's assigned schema ID
      const { data: client, error: clientError } = await supabase
        .from('clients')
        .select('assigned_schema_id')
        .eq('id', clientId)
        .single()
      
      if (clientError || !client?.assigned_schema_id) {
        console.log('No schema assigned to client')
        return null
      }
      
      // Then get the full schema
      const { data: schema, error: schemaError } = await supabase
        .from('workout_schemas')
        .select('*')
        .eq('id', client.assigned_schema_id)
        .single()
      
      if (schemaError) throw schemaError
      return schema
    } catch (error) {
      console.error('❌ Get client schema failed:', error)
      return null
    }
  }

  // FIX: Use workout_plans table (exists!) or assigned_schema_id
  async getClientWorkoutPlan(clientId) {
    try {
      // First check workout_plans table
      const { data: workoutPlan, error: planError } = await supabase
        .from('workout_plans')
        .select('*, workout_schemas(*)')
        .eq('client_id', clientId)
        .order('created_at', { ascending: false })
        .limit(1)
        .single()
      
      if (workoutPlan && !planError) {
        return workoutPlan
      }
      
      // Fallback: Get client with their assigned schema
      const { data: client, error: clientError } = await supabase
        .from('clients')
        .select('*, workout_schemas!assigned_schema_id(*)')
        .eq('id', clientId)
        .single()
      
      if (clientError || !client) {
        console.log('No workout plan for client')
        return null
      }
      
      // Return in expected format
      if (client.workout_schemas) {
        return {
          client_id: clientId,
          schema_id: client.assigned_schema_id,
          workout_schemas: client.workout_schemas,
          assigned_at: client.updated_at
        }
      }
      
      return null
    } catch (error) {
      console.error('❌ Get client workout plan failed:', error)
      return null
    }
  }

  async assignWorkoutToClient(clientId, schemaId) {
    try {
      // Update client's assigned schema
      const { data, error } = await supabase
        .from('clients')
        .update({ 
          assigned_schema_id: schemaId,
          updated_at: new Date().toISOString()
        })
        .eq('id', clientId)
        .select()
        .single()
      
      if (error) throw error
      
      this.clearCache(`client_${clientId}`)
      return data
    } catch (error) {
      console.error('❌ Assign workout failed:', error)
      throw error
    }
  }

  async getTodaysWorkout(clientId) {
    try {
      const plan = await this.getClientWorkoutPlan(clientId)
      if (!plan?.workout_schemas) return null
      
      const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday']
      const today = dayNames[new Date().getDay()]
      const weekStructure = plan.workout_schemas.week_structure || {}
      
      return weekStructure[today] || null
    } catch (error) {
      console.error('❌ Get today workout failed:', error)
      return null
    }
  }

  // ===== WORKOUT PROGRESS & COMPLETION =====
  async getWorkoutCompletions(clientId, dateRange = null) {
    try {
      let query = supabase
        .from('workout_completion')
        .select('*')
        .eq('client_id', clientId)
        .order('workout_date', { ascending: false })
      
      if (dateRange?.from) {
        query = query.gte('workout_date', dateRange.from)
      }
      if (dateRange?.to) {
        query = query.lte('workout_date', dateRange.to)
      }
      
      const { data, error } = await query
      if (error) throw error
      return data || []
    } catch (error) {
      console.error('❌ Get workout completions failed:', error)
      return []
    }
  }

  async saveWorkoutCompletion(clientId, date, completed = true, notes = null) {
    try {
      const { data, error } = await supabase
        .from('workout_completion')
        .upsert({
          client_id: clientId,
          workout_date: date,
          completed: completed,
          notes: notes
        }, {
          onConflict: 'client_id,workout_date'
        })
        .select()
        .single()
      
      if (error) throw error
      console.log('✅ Workout completion saved')
      return data
    } catch (error) {
      console.error('❌ Save workout completion failed:', error)
      throw error
    }
  }

  async getWeeklyWorkoutCount(clientId) {
    try {
      const weekAgo = new Date()
      weekAgo.setDate(weekAgo.getDate() - 7)
      
      const completions = await this.getWorkoutCompletions(clientId, {
        from: weekAgo.toISOString().split('T')[0]
      })
      
      return completions.filter(w => w.completed).length
    } catch (error) {
      console.error('❌ Get weekly workout count failed:', error)
      return 0
    }
  }

  async getClientStreak(clientId) {
    try {
      const completions = await this.getWorkoutCompletions(clientId)
      
      // Calculate streak
      let streak = 0
      const today = new Date().toISOString().split('T')[0]
      const sortedDates = completions
        .filter(w => w.completed)
        .map(w => w.workout_date)
        .sort()
        .reverse()
      
      // Check if today or yesterday is completed
      const yesterday = new Date()
      yesterday.setDate(yesterday.getDate() - 1)
      const yesterdayStr = yesterday.toISOString().split('T')[0]
      
      if (sortedDates[0] === today || sortedDates[0] === yesterdayStr) {
        streak = 1
        
        // Count backwards
        for (let i = 1; i < sortedDates.length; i++) {
          const currentDate = new Date(sortedDates[i])
          const prevDate = new Date(sortedDates[i - 1])
          const dayDiff = (prevDate - currentDate) / (1000 * 60 * 60 * 24)
          
          if (dayDiff <= 1.5) { // Allow for timezone differences
            streak++
          } else {
            break
          }
        }
      }
      
      return streak
    } catch (error) {
      console.error('❌ Get client streak failed:', error)
      return 0
    }
  }

  // ===== MEAL PLAN METHODS =====
 
// ===== MEAL PLAN METHODS =====


// src/services/DatabaseService.js - MEAL PLAN METHODS
// 🍎 Voeg deze methods toe aan je bestaande DatabaseService class

// ===== MEAL PLAN METHODS =====


// In DatabaseService.js, voeg deze method toe:
// Voeg deze methods toe/update ze in DatabaseService.js

// ===== MEAL DETAILS METHOD (NIEUW) =====

async getMealsWithImages(mealIds) {
    try {
      console.log('🖼️ Getting meals with images for IDs:', mealIds);
      
      const { data, error } = await this.supabase
        .from('meals')
        .select('id, name, calories, protein, carbs, fat, image_url')
        .in('id', mealIds);

      if (error) {
        console.error('Error fetching meals with images:', error);
        return [];
      }

      console.log(`✅ Fetched ${data?.length || 0} meals with image data`);
      return data || [];
    } catch (error) {
      console.error('Error in getMealsWithImages:', error);
      return [];
    }
  }

  // Update meal image URL
  async updateMealImage(mealId, imageUrl) {
    try {
      console.log(`📸 Updating image for meal ${mealId}`);
      
      const { error } = await this.supabase
        .from('meals')
        .update({ image_url: imageUrl })
        .eq('id', mealId);

      if (error) {
        console.error('Error updating meal image:', error);
        return false;
      }

      console.log('✅ Meal image updated successfully');
      return true;
    } catch (error) {
      console.error('Error in updateMealImage:', error);
      return false;
    }
  }

  // Check of image_url kolom bestaat (voor setup)
  async checkMealImageColumn() {
    try {
      const { data, error } = await this.supabase
        .from('meals')
        .select('image_url')
        .limit(1);

      if (error && error.message.includes('column')) {
        console.log('❌ Column image_url does not exist yet');
        return false;
      }

      console.log('✅ Column image_url exists');
      return true;
    } catch (error) {
      console.error('Error checking image column:', error);
      return false;
    }
  }

async getMealDetails(mealId) {
  try {
    if (!mealId) {
      console.log('⚠️ No meal ID provided')
      return null
    }
    
    const { data, error } = await supabase
      .from('meals')
      .select('*')
      .eq('id', mealId)
      .single()
    
    if (error) {
      console.error('❌ Get meal details error:', error)
      return null
    }
    
    console.log('✅ Loaded meal details:', data?.name)
    return data
  } catch (error) {
    console.error('❌ Get meal details failed:', error)
    return null
  }
}

// ===== MEAL PROGRESS SAVE (GEFIXTE VERSIE) =====
async saveMealProgress(clientId, progressData) {
  try {
    console.log('💾 Saving meal progress for client:', clientId)
    
    if (!clientId || !progressData.date) {
      console.error('❌ Missing required fields')
      return null
    }
    
    const { data: existing, error: checkError } = await supabase
      .from('meal_progress')
      .select('id')
      .eq('client_id', clientId)
      .eq('date', progressData.date)
      .maybeSingle()
    
    if (checkError && checkError.code !== 'PGRST116') {
      console.error('❌ Check existing error:', checkError)
      return null
    }
    
    // Alleen de velden die WEL bestaan in de database
    const dataToSave = {
      client_id: clientId,
      date: progressData.date,
      plan_id: progressData.plan_id || null,
      total_calories: parseInt(progressData.total_calories) || 0,
      total_protein: parseInt(progressData.total_protein) || 0,
      total_carbs: parseInt(progressData.total_carbs) || 0,
      total_fat: parseInt(progressData.total_fat) || 0,
      notes: progressData.notes || null,
      updated_at: new Date().toISOString()
    }
    
    let result
    
    if (existing) {
      const { data, error } = await supabase
        .from('meal_progress')
        .update(dataToSave)
        .eq('id', existing.id)
        .select()
        .single()
      
      if (error) {
        console.error('❌ Update error:', error)
        return null
      }
      result = data
    } else {
      const { data, error } = await supabase
        .from('meal_progress')
        .insert({
          ...dataToSave,
          created_at: new Date().toISOString()
        })
        .select()
        .single()
      
      if (error) {
        console.error('❌ Insert error:', error)
        return null
      }
      result = data
    }
    
    console.log('✅ Meal progress saved')
    return result
  } catch (error) {
    console.error('❌ Save meal progress failed:', error.message || error)
    return null
  }
}

// ===== GET CUSTOM MEALS (GEFIXTE VERSIE VOOR CLIENT-SPECIFIC) =====
async getCustomMeals(clientId) {
  try {
    if (!clientId) {
      console.log('⚠️ No clientId provided for getCustomMeals')
      return []
    }
    
    // Haal alleen custom meals voor deze specifieke client
    const { data, error } = await supabase
      .from('meals')
      .select('*')
      .eq('created_by', clientId)
      .eq('is_custom', true)
      .order('created_at', { ascending: false })
    
    if (error) {
      console.error('❌ Get custom meals error:', error)
      return []
    }
    
    console.log('✅ Loaded custom meals for client:', data?.length || 0)
    return data || []
  } catch (error) {
    console.error('❌ Get custom meals failed:', error)
    return []
  }
}

// ===== SAVE CUSTOM MEAL (GEFIXTE VERSIE) =====
async saveCustomMeal(mealData) {
  try {
    console.log('💾 Attempting to save custom meal:', mealData)
    
    // Zorg dat alle vereiste velden aanwezig zijn
    const mealToSave = {
      name: mealData.name,
      kcal: parseInt(mealData.kcal) || 0,
      protein: parseInt(mealData.protein) || 0,
      carbs: parseInt(mealData.carbs) || 0,
      fat: parseInt(mealData.fat) || 0,
      is_custom: true,
      created_by: mealData.created_by,
      // Optionele velden
      ...(mealData.category && { category: mealData.category }),
      ...(mealData.meal_type && { meal_type: mealData.meal_type }),
      ...(mealData.image_url && { image_url: mealData.image_url }),
      ...(mealData.ingredients && { ingredients: mealData.ingredients }),
      ...(mealData.tags && { tags: mealData.tags })
    }
    
    const { data, error } = await supabase
      .from('meals')
      .insert(mealToSave)
      .select()
      .single()
    
    if (error) {
      console.error('❌ Supabase error:', error)
      throw error
    }
    
    console.log('✅ Custom meal saved:', data)
    return data
  } catch (error) {
    console.error('❌ Save custom meal failed:', error.message || error)
    throw error
  }
}

// ===== GET MEAL HISTORY (VERBETERDE VERSIE) =====
async getMealHistory(clientId, days = 30) {
  try {
    console.log('📊 Loading meal history for client:', clientId)
    
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)
    
    const { data, error } = await supabase
      .from('meal_progress')
      .select('*')
      .eq('client_id', clientId)
      .gte('date', startDate.toISOString().split('T')[0])
      .order('date', { ascending: false })
    
    if (error) {
      console.error('❌ Get history error:', error)
      return []
    }
    
    // Parse meals_checked als het een string is
    const parsedData = data?.map(item => {
      if (item.meals_checked && typeof item.meals_checked === 'string') {
        try {
          item.meals_checked = JSON.parse(item.meals_checked)
        } catch (e) {
          console.log('Could not parse meals_checked, keeping as-is')
        }
      }
      return item
    })
    
    console.log('✅ Loaded meal history:', parsedData?.length || 0, 'days')
    return parsedData || []
  } catch (error) {
    console.error('❌ Get meal history failed:', error)
    return []
  }
}

// Voeg deze methods toe aan je DatabaseService.js
// ===== CUSTOM MEALS =====
// Voeg toe aan DatabaseService.js
async getMealDetails(mealId) {
  try {
    const { data, error } = await supabase
      .from('meals')
      .select('*')
      .eq('id', mealId)
      .single()
    
    if (error) throw error
    return data
  } catch (error) {
    console.error('Get meal details failed:', error)
    return null
  }
}
async saveCustomMeal(mealData) {
  try {
    console.log('💾 Attempting to save custom meal:', mealData)
    
    // Zorg dat alle vereiste velden aanwezig zijn
    const mealToSave = {
      name: mealData.name,
      kcal: parseInt(mealData.kcal) || 0,
      protein: parseInt(mealData.protein) || 0,
      carbs: parseInt(mealData.carbs) || 0,
      fat: parseInt(mealData.fat) || 0,
      // Optionele velden alleen toevoegen als ze bestaan
      ...(mealData.category && { category: mealData.category }),
      ...(mealData.meal_type && { meal_type: mealData.meal_type }),
      ...(mealData.image_url && { image_url: mealData.image_url }),
      ...(mealData.ingredients && { ingredients: mealData.ingredients }),
      ...(mealData.created_by && { created_by: mealData.created_by }),
      is_custom: true
    }
    
    const { data, error } = await supabase
      .from('meals')
      .insert(mealToSave)
      .select()
      .single()
    
    if (error) {
      console.error('❌ Supabase error:', error)
      throw error
    }
    
    console.log('✅ Custom meal saved:', data)
    return data
  } catch (error) {
    console.error('❌ Save custom meal failed:', error.message || error)
    throw error
  }
}

async getCustomMeals(clientId) {
  try {
    if (!clientId) {
      console.log('⚠️ No clientId provided for getCustomMeals')
      return []
    }
    
    const { data, error } = await supabase
      .from('meals')
      .select('*')
      .eq('created_by', clientId)
      .eq('is_custom', true)
      .order('created_at', { ascending: false })
    
    if (error) {
      console.error('❌ Get custom meals error:', error)
      return []
    }
    
    console.log('✅ Loaded custom meals:', data?.length || 0)
    return data || []
  } catch (error) {
    console.error('❌ Get custom meals failed:', error)
    return []
  }
}

// ===== MEAL PROGRESS & HISTORY =====
async saveMealProgress(clientId, progressData) {
  try {
    console.log('💾 Saving meal progress for client:', clientId)
    
    // Check if progress exists for today
    const { data: existing, error: checkError } = await supabase
      .from('meal_progress')
      .select('id')
      .eq('client_id', clientId)
      .eq('date', progressData.date)
      .maybeSingle()
    
    if (checkError && checkError.code !== 'PGRST116') {
      console.error('❌ Check existing progress error:', checkError)
      throw checkError
    }
    
    let result
    
    if (existing) {
      // Update existing progress
      const { data, error } = await supabase
        .from('meal_progress')
        .update({
          ...progressData,
          updated_at: new Date().toISOString()
        })
        .eq('id', existing.id)
        .select()
        .single()
      
      if (error) {
        console.error('❌ Update progress error:', error)
        throw error
      }
      result = data
    } else {
      // Create new progress
      const { data, error } = await supabase
        .from('meal_progress')
        .insert({
          client_id: clientId,
          ...progressData,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        })
        .select()
        .single()
      
      if (error) {
        console.error('❌ Insert progress error:', error)
        throw error
      }
      result = data
    }
    
    console.log('✅ Meal progress saved')
    return result
  } catch (error) {
    console.error('❌ Save meal progress failed:', error.message || error)
    // Don't throw, return null to prevent app crash
    return null
  }
}

async getMealProgress(clientId, date) {
  try {
    const { data, error } = await supabase
      .from('meal_progress')
      .select('*')
      .eq('client_id', clientId)
      .eq('date', date)
      .maybeSingle()
    
    if (error && error.code !== 'PGRST116') {
      console.error('❌ Get progress error:', error)
      return null
    }
    
    return data
  } catch (error) {
    console.error('❌ Get meal progress failed:', error)
    return null
  }
}

async getMealHistory(clientId, days = 30) {
  try {
    console.log('📊 Loading meal history for client:', clientId)
    
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)
    
    const { data, error } = await supabase
      .from('meal_progress')
      .select('*')
      .eq('client_id', clientId)
      .gte('date', startDate.toISOString().split('T')[0])
      .order('date', { ascending: false })
    
    if (error) {
      console.error('❌ Get history error:', error)
      return []
    }
    
    console.log('✅ Loaded meal history:', data?.length || 0, 'days')
    return data || []
  } catch (error) {
    console.error('❌ Get meal history failed:', error)
    return []
  }
}

// ===== WATER INTAKE =====
// Vervang deze 3 methods in DatabaseService.js:





// Voeg deze NIEUWE methods toe aan DatabaseService.js
// NIET de oude vervangen, maar NIEUWE toevoegen met unieke namen

// ===== WATER TRACKING V2 - UNIEKE NAMEN =====
async saveWaterTracking2025(clientId, date, liters) {
  console.log('🆕 saveWaterTracking2025 called with:', { clientId, date, liters })
  
  try {
    const { data, error } = await supabase
      .from('water_tracking')
      .upsert({
        client_id: clientId,
        date: date,
        amount_liters: liters,
        target_liters: 2.0,
        updated_at: new Date().toISOString()
      }, {
        onConflict: 'client_id,date'
      })
      .select()
      .single()

    if (error) {
      console.error('❌ saveWaterTracking2025 error:', error)
      throw error
    }
    
    console.log('✅ saveWaterTracking2025 success:', data)
    return data
  } catch (error) {
    console.error('❌ saveWaterTracking2025 failed:', error)
    return null
  }
}

async getWaterTracking2025(clientId, date) {
  console.log('🆕 getWaterTracking2025 called with:', { clientId, date })
  
  try {
    const { data, error } = await supabase
      .from('water_tracking')
      .select('amount_liters')
      .eq('client_id', clientId)
      .eq('date', date)
      .maybeSingle()

    if (error && error.code !== 'PGRST116') {
      console.error('❌ getWaterTracking2025 error:', error)
      throw error
    }
    
    const liters = data?.amount_liters || 0
    console.log('✅ getWaterTracking2025 result:', liters, 'L')
    return liters
  } catch (error) {
    console.error('❌ getWaterTracking2025 failed:', error)
    return 0
  }
}

async getWaterTrackingRange2025(clientId, startDate, endDate) {
  console.log('🆕 getWaterTrackingRange2025 called')
  
  try {
    const { data, error } = await supabase
      .from('water_tracking')
      .select('*')
      .eq('client_id', clientId)
      .gte('date', startDate)
      .lte('date', endDate)
      .order('date')

    if (error) throw error
    
    console.log('✅ getWaterTrackingRange2025 found', data?.length || 0, 'records')
    return data || []
  } catch (error) {
    console.error('❌ getWaterTrackingRange2025 failed:', error)
    return []
  }
}











// ===== MEAL SWAPS =====




// Vervang de saveMealSwap op regel 1140 met deze GEFIXTE versie:
// VERVANG saveMealSwap met deze versie die duplicates voorkomt:
async saveMealSwap(clientId, planId, dayIndex, slot, mealId) {
  try {
    console.log('🔄 Saving meal swap:', { clientId, planId, dayIndex, slot, mealId })
    
    // First get current overrides
    const { data: existing, error: fetchError } = await supabase
      .from('client_meal_overrides')
      .select('id, week_structure')
      .eq('client_id', clientId)
      .eq('plan_id', planId)
      .maybeSingle()
    
    if (fetchError && fetchError.code !== 'PGRST116') {
      console.error('❌ Error fetching overrides:', fetchError)
      return false
    }
    
    let weekStructure = existing?.week_structure || []
    
    // Ensure dayIndex exists
    while (weekStructure.length <= dayIndex) {
      weekStructure.push({ 
        day: `Day ${weekStructure.length + 1}`, 
        meals: [] 
      })
    }
    
    // BELANGRIJKE FIX: Verwijder oude duplicates eerst
    if (!weekStructure[dayIndex].meals) {
      weekStructure[dayIndex].meals = []
    }
    
    // Filter out any existing entries for this slot (voorkom duplicates)
    weekStructure[dayIndex].meals = weekStructure[dayIndex].meals.filter(m => 
      m.slot !== slot && 
      m.time_slot !== slot
    )
    
    // Nu voeg de nieuwe swap toe
    weekStructure[dayIndex].meals.push({
      slot: slot,
      time_slot: slot, // Beide voor compatibiliteit
      meal_id: mealId,
      target_kcal: 500 // Default
    })
    
    console.log(`📊 Day ${dayIndex} now has ${weekStructure[dayIndex].meals.length} swaps`)
    
    // Save back to database
    let saveError
    
    if (existing?.id) {
      // UPDATE bestaande record
      const { error } = await supabase
        .from('client_meal_overrides')
        .update({
          week_structure: weekStructure,
          updated_at: new Date().toISOString()
        })
        .eq('id', existing.id)
      
      saveError = error
    } else {
      // INSERT nieuwe record
      const { error } = await supabase
        .from('client_meal_overrides')
        .insert({
          client_id: clientId,
          plan_id: planId,
          week_structure: weekStructure,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        })
      
      saveError = error
    }
    
    if (saveError) {
      console.error('❌ Save meal swap failed:', saveError)
      return false
    }
    
    console.log('✅ Meal swap saved successfully (no duplicates)')
    return true
  } catch (error) {
    console.error('❌ Error saving meal swap:', error)
    return false
  }
}





// ===== GET MEALS BY IDS =====
async getMealsByIds(mealIds) {
  try {
    if (!mealIds || mealIds.length === 0) {
      console.log('⚠️ No meal IDs provided')
      return []
    }
    
    const { data, error } = await supabase
      .from('meals')
      .select('*')
      .in('id', mealIds)
    
    if (error) {
      console.error('❌ Get meals by IDs error:', error)
      return []
    }
    
    return data || []
  } catch (error) {
    console.error('❌ Get meals by IDs failed:', error)
    return []
  }
}

// ===== MEAL PREFERENCES (Update existing) =====
async saveMealPreferences(clientId, preferences) {
  try {
    console.log('💾 Saving meal preferences for client:', clientId)
    
    const { data, error } = await supabase
      .from('clients')
      .update({
        nutrition_info: preferences,
        updated_at: new Date().toISOString()
      })
      .eq('id', clientId)
      .select()
      .single()
    
    if (error) {
      console.error('❌ Save preferences error:', error)
      // Fallback to localStorage
      localStorage.setItem(`meal_preferences_${clientId}`, JSON.stringify(preferences))
      return preferences
    }
    
    console.log('✅ Meal preferences saved')
    return data
  } catch (error) {
    console.error('❌ Save meal preferences failed:', error)
    localStorage.setItem(`meal_preferences_${clientId}`, JSON.stringify(preferences))
    return preferences
  }
}

async getMealPreferences(clientId) {
  try {
    const { data, error } = await supabase
      .from('clients')
      .select('nutrition_info')
      .eq('id', clientId)
      .single()
    
    if (error && error.code !== 'PGRST116') {
      console.error('❌ Get preferences error:', error)
    }
    
    if (data?.nutrition_info) {
      return data.nutrition_info
    }
    
    // Fallback to localStorage
    const stored = localStorage.getItem(`meal_preferences_${clientId}`)
    if (stored) {
      return JSON.parse(stored)
    }
    
    // Default preferences
    return {
      dietary_type: 'regular',
      allergies: [],
      dislikes: [],
      favorite_meals: [],
      meals_per_day: 3,
      primary_goal: 'maintenance',
      activity_level: 'moderate'
    }
  } catch (error) {
    console.error('❌ Get meal preferences failed:', error)
    return {
      dietary_type: 'regular',
      allergies: [],
      dislikes: [],
      favorite_meals: [],
      meals_per_day: 3,
      primary_goal: 'maintenance',
      activity_level: 'moderate'
    }
  }
}

// ===== MEAL PROGRESS & HISTORY =====
async saveMealProgress(clientId, progressData) {
  try {
    // Check if progress exists for today
    const { data: existing, error: checkError } = await supabase
      .from('meal_progress')
      .select('id')
      .eq('client_id', clientId)
      .eq('date', progressData.date)
      .maybeSingle()
    
    if (checkError && checkError.code !== 'PGRST116') {
      throw checkError
    }
    
    let result
    
    if (existing) {
      // Update existing progress
      const { data, error } = await supabase
        .from('meal_progress')
        .update({
          ...progressData,
          updated_at: new Date().toISOString()
        })
        .eq('id', existing.id)
        .select()
        .single()
      
      if (error) throw error
      result = data
    } else {
      // Create new progress
      const { data, error } = await supabase
        .from('meal_progress')
        .insert({
          client_id: clientId,
          ...progressData,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        })
        .select()
        .single()
      
      if (error) throw error
      result = data
    }
    
    console.log('✅ Meal progress saved')
    return result
  } catch (error) {
    console.error('❌ Save meal progress failed:', error)
    throw error
  }
}

async getMealProgress(clientId, date) {
  try {
    const { data, error } = await supabase
      .from('meal_progress')
      .select('*')
      .eq('client_id', clientId)
      .eq('date', date)
      .maybeSingle()
    
    if (error && error.code !== 'PGRST116') {
      throw error
    }
    
    return data
  } catch (error) {
    console.error('❌ Get meal progress failed:', error)
    return null
  }
}

async getMealHistory(clientId, days = 30) {
  try {
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)
    
    const { data, error } = await supabase
      .from('meal_progress')
      .select('*')
      .eq('client_id', clientId)
      .gte('date', startDate.toISOString().split('T')[0])
      .order('date', { ascending: false })
    
    if (error) throw error
    
    console.log('✅ Loaded meal history:', data?.length || 0, 'days')
    return data || []
  } catch (error) {
    console.error('❌ Get meal history failed:', error)
    return []
  }
}

// ===== WATER INTAKE =====
async saveWaterIntake(clientId, date, amount) {
  try {
    const { data: existing, error: checkError } = await supabase
      .from('water_intake')
      .select('id')
      .eq('client_id', clientId)
      .eq('date', date)
      .maybeSingle()
    
    if (checkError && checkError.code !== 'PGRST116') {
      throw checkError
    }
    
    let result
    
    if (existing) {
      const { data, error } = await supabase
        .from('water_intake')
        .update({
          amount: amount,
          updated_at: new Date().toISOString()
        })
        .eq('id', existing.id)
        .select()
        .single()
      
      if (error) throw error
      result = data
    } else {
      const { data, error } = await supabase
        .from('water_intake')
        .insert({
          client_id: clientId,
          date: date,
          amount: amount,
          created_at: new Date().toISOString()
        })
        .select()
        .single()
      
      if (error) throw error
      result = data
    }
    
    console.log('✅ Water intake saved:', amount, 'L')
    return result
  } catch (error) {
    console.error('❌ Save water intake failed:', error)
    return null
  }
}

async getWaterIntake(clientId, date) {
  try {
    const { data, error } = await supabase
      .from('water_intake')
      .select('amount')
      .eq('client_id', clientId)
      .eq('date', date)
      .maybeSingle()
    
    if (error && error.code !== 'PGRST116') {
      throw error
    }
    
    return data
  } catch (error) {
    console.error('❌ Get water intake failed:', error)
    return null
  }
}

// ===== MEAL SWAPS =====

// ===== GET MEALS BY IDS =====
async getMealsByIds(mealIds) {
  try {
    const { data, error } = await supabase
      .from('meals')
      .select('*')
      .in('id', mealIds)
    
    if (error) throw error
    
    return data || []
  } catch (error) {
    console.error('❌ Get meals by IDs failed:', error)
    return []
  }
}

// ===== UPLOAD MEAL IMAGE (placeholder voor nu) =====
async uploadMealImage(file) {
  try {
    // In productie: upload naar Supabase Storage
    const fileName = `meals/${Date.now()}_${file.name}`
    
    // Voor nu: return een placeholder
    console.log('📸 Would upload image:', fileName)
    return `https://source.unsplash.com/400x300/?food,meal`
    
    // Productie code:
    /*
    const { data, error } = await supabase.storage
      .from('meal-images')
      .upload(fileName, file)
    
    if (error) throw error
    
    const { data: { publicUrl } } = supabase.storage
      .from('meal-images')
      .getPublicUrl(fileName)
    
    return publicUrl
    */
  } catch (error) {
    console.error('❌ Upload meal image failed:', error)
    throw error
  }
}

async getCustomMeals(clientId) {
  try {
    // Check of er een user is ingelogd
    const { data: { user } } = await this.supabase.auth.getUser()
    if (!user) return []
    
    const { data, error } = await this.supabase
      .from('meals')
      .select('*')
      .eq('is_custom', true)
      .eq('created_by', user.id)  // Gebruik user.id ipv clientId
      .order('created_at', { ascending: false })
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('❌ Get custom meals failed:', error)
    return []  // Return lege array ipv throw
  }
}


// Get client's active meal plan
async getClientMealPlan(clientId) {
  try {
    const { data, error } = await this.supabase
      .from('client_meal_plans')
      .select('*')
      .eq('client_id', clientId)
      .order('created_at', { ascending: false })
      .limit(1)
      .single()
    
    if (error && error.code !== 'PGRST116') throw error
    return data
  } catch (error) {
    console.error('❌ Get client meal plan failed:', error)
    return null
  }
}

// Get all meals from catalog
async getAllMeals() {
  try {
    const { data, error } = await this.supabase
      .from('meals')
      .select('*')
      .order('name')
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('❌ Get all meals failed:', error)
    return []
  }
}

// Get specific meals by IDs
async getMealsByIds(mealIds) {
  if (!mealIds || mealIds.length === 0) return []
  
  try {
    const { data, error } = await this.supabase
      .from('meals')
      .select('*')
      .in('id', mealIds)
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('❌ Get meals by IDs failed:', error)
    return []
  }
}

// Get client meal overrides (swaps)
async getClientMealOverrides(clientId, planId) {
  try {
    const { data, error } = await this.supabase
      .from('client_meal_overrides')
      .select('week_structure')
      .eq('client_id', clientId)
      .eq('plan_id', planId)
      .single()
    
    if (error && error.code !== 'PGRST116') throw error
    return data?.week_structure || null
  } catch (error) {
    console.error('❌ Get client meal overrides failed:', error)
    return null
  }
}


// Save meal progress (checked meals)
async saveMealProgress(clientId, progressData) {
  try {
    const { data, error } = await this.supabase
      .from('meal_progress')
      .upsert({
        client_id: clientId,
        plan_id: progressData.plan_id,
        date: progressData.date,
        day_index: progressData.day_index,
        meals_checked: progressData.meals_checked,
        total_calories: progressData.total_calories,
        total_protein: progressData.total_protein,
        total_carbs: progressData.total_carbs,
        total_fat: progressData.total_fat,
        notes: progressData.notes || null,
        updated_at: new Date().toISOString()
      }, {
        onConflict: 'client_id,date'
      })
      .select()
      .single()
    
    if (error) throw error
    console.log('✅ Meal progress saved')
    return data
  } catch (error) {
    console.error('❌ Save meal progress failed:', error)
    throw error
  }
}

// Get meal progress for specific date
async getMealProgress(clientId, date) {
  try {
    const { data, error } = await this.supabase
      .from('meal_progress')
      .select('*')
      .eq('client_id', clientId)
      .eq('date', date)
      .single()
    
    if (error && error.code !== 'PGRST116') throw error
    return data
  } catch (error) {
    console.error('❌ Get meal progress failed:', error)
    return null
  }
}

// Get meal history
async getMealHistory(clientId, days = 7) {
  try {
    const endDate = new Date()
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)
    
    const { data, error } = await this.supabase
      .from('meal_progress')
      .select('*')
      .eq('client_id', clientId)
      .gte('date', startDate.toISOString().split('T')[0])
      .lte('date', endDate.toISOString().split('T')[0])
      .order('date', { ascending: false })
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('❌ Get meal history failed:', error)
    return []
  }
}

// Save water intake
async saveWaterIntake(clientId, date, amount) {
  try {
    const { data, error } = await this.supabase
      .from('water_intake')
      .upsert({
        client_id: clientId,
        date: date,
        amount: amount,
        updated_at: new Date().toISOString()
      }, {
        onConflict: 'client_id,date'
      })
      .select()
      .single()
    
    if (error) throw error
    console.log('✅ Water intake saved')
    return data
  } catch (error) {
    console.error('❌ Save water intake failed:', error)
    throw error
  }
}

// Get water intake for date
async getWaterIntake(clientId, date) {
  try {
    const { data, error } = await this.supabase
      .from('water_intake')
      .select('*')
      .eq('client_id', clientId)
      .eq('date', date)
      .single()
    
    if (error && error.code !== 'PGRST116') throw error
    return data
  } catch (error) {
    console.error('❌ Get water intake failed:', error)
    return null
  }
}

// Get meal preferences
async getMealPreferences(clientId) {
  try {
    const { data, error } = await this.supabase
      .from('clients')
      .select('nutrition_info')
      .eq('id', clientId)
      .single()
    
    if (error) throw error
    return data?.nutrition_info || {}
  } catch (error) {
    console.error('❌ Get meal preferences failed:', error)
    return {}
  }
}

// Save meal preferences
async saveMealPreferences(clientId, preferences) {
  try {
    const { data, error } = await this.supabase
      .from('clients')
      .update({
        nutrition_info: preferences,
        updated_at: new Date().toISOString()
      })
      .eq('id', clientId)
      .select()
      .single()
    
    if (error) throw error
    console.log('✅ Meal preferences saved')
    return data
  } catch (error) {
    console.error('❌ Save meal preferences failed:', error)
    throw error
  }
}

// Get meal compliance stats
async getMealCompliance(clientId, days = 7) {
  try {
    const history = await this.getMealHistory(clientId, days)
    
    if (!history || history.length === 0) {
      return {
        daysTracked: 0,
        averageCalories: 0,
        averageProtein: 0,
        averageCarbs: 0,
        averageFat: 0,
        compliancePercentage: 0
      }
    }
    
    const totalDays = history.length
    const totalCalories = history.reduce((sum, day) => sum + (day.total_calories || 0), 0)
    const totalProtein = history.reduce((sum, day) => sum + (day.total_protein || 0), 0)
    const totalCarbs = history.reduce((sum, day) => sum + (day.total_carbs || 0), 0)
    const totalFat = history.reduce((sum, day) => sum + (day.total_fat || 0), 0)
    
    return {
      daysTracked: totalDays,
      averageCalories: Math.round(totalCalories / totalDays),
      averageProtein: Math.round(totalProtein / totalDays),
      averageCarbs: Math.round(totalCarbs / totalDays),
      averageFat: Math.round(totalFat / totalDays),
      compliancePercentage: Math.round((totalDays / days) * 100)
    }
  } catch (error) {
    console.error('❌ Get meal compliance failed:', error)
    return null
  }
}

// ===== CUSTOM MEALS & FAVORITES =====

// Create custom meal
async createCustomMeal(mealData) {
  try {
    const { data: { user } } = await this.supabase.auth.getUser()
    
    const { data, error } = await this.supabase
      .from('meals')
      .insert({
        name: mealData.name,
        kcal: mealData.kcal,
        protein: mealData.protein || 0,
        carbs: mealData.carbs || 0,
        fat: mealData.fat || 0,
        category: mealData.category || 'lunch',
        image_url: mealData.image_url,
        ingredients: mealData.ingredients || [],
        is_custom: true,
        created_by: mealData.created_by || user?.id
      })
      .select()
      .single()
    
    if (error) throw error
    console.log('✅ Custom meal created')
    return data
  } catch (error) {
    console.error('❌ Create custom meal failed:', error)
    throw error
  }
}

// Get custom meals for client
async getCustomMeals(clientId) {
  try {
    const { data, error } = await this.supabase
      .from('meals')
      .select('*')
      .eq('is_custom', true)
      .eq('created_by', clientId)
      .order('created_at', { ascending: false })
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('❌ Get custom meals failed:', error)
    return []
  }
}

// Update meal with image
async updateMealImage(mealId, imageUrl) {
  try {
    const { data, error } = await this.supabase
      .from('meals')
      .update({ 
        image_url: imageUrl,
        updated_at: new Date().toISOString()
      })
      .eq('id', mealId)
      .select()
      .single()
    
    if (error) throw error
    console.log('✅ Meal image updated')
    return data
  } catch (error) {
    console.error('❌ Update meal image failed:', error)
    throw error
  }
}

// Delete custom meal
async deleteCustomMeal(mealId) {
  try {
    const { error } = await this.supabase
      .from('meals')
      .delete()
      .eq('id', mealId)
      .eq('is_custom', true)
    
    if (error) throw error
    console.log('✅ Custom meal deleted')
    return true
  } catch (error) {
    console.error('❌ Delete custom meal failed:', error)
    return false
  }
}

async saveMealProgress(clientId, progressData) {
  try {
    const { data, error } = await supabase
      .from('meal_progress')
      .upsert({
        client_id: clientId,
        plan_id: progressData.planId,
        date: progressData.date,
        day_index: progressData.dayIndex,
        meals_checked: progressData.mealsChecked,
        total_calories: progressData.totalCalories,
        total_protein: progressData.totalProtein,
        total_carbs: progressData.totalCarbs,
        total_fat: progressData.totalFat,
        notes: progressData.notes,
        updated_at: new Date().toISOString()
      }, {
        onConflict: 'client_id,date'
      })
      .select()
      .single()

    if (error) throw error
    return data
  } catch (error) {
    console.error('Error saving meal progress:', error)
    throw error
  }
}

async getMealProgress(clientId, date) {
  try {
    const { data, error } = await supabase
      .from('meal_progress')
      .select('*')
      .eq('client_id', clientId)
      .eq('date', date)
      .single()

    if (error && error.code !== 'PGRST116') throw error
    return data || null
  } catch (error) {
    console.error('Error getting meal progress:', error)
    return null
  }
}

async getMealProgressRange(clientId, startDate, endDate) {
  try {
    const { data, error } = await supabase
      .from('meal_progress')
      .select('*')
      .eq('client_id', clientId)
      .gte('date', startDate)
      .lte('date', endDate)
      .order('date', { ascending: true })

    if (error) throw error
    return data || []
  } catch (error) {
    console.error('Error getting meal progress range:', error)
    return []
  }
}

async getMealPlanTemplates() {
  try {
    const { data, error } = await supabase
      .from('meal_plan_templates')
      .select('*')
      .order('created_at', { ascending: false })
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('❌ Get meal templates failed:', error)
    return []
  }
}

async getClientMealPlan(clientId) {
  try {
    const { data, error } = await supabase
      .from('client_meal_plans')
      .select('*')
      .eq('client_id', clientId)
      .order('created_at', { ascending: false })
      .limit(1)
      .single()
    
    if (error && error.code !== 'PGRST116') throw error
    return data
  } catch (error) {
    console.error('❌ Get client meal plan failed:', error)
    return null
  }
}

async saveMealPlan(clientId, planData) {
  try {
    // Check of er al een plan bestaat voor deze client
    const { data: existing, error: checkError } = await supabase
      .from('client_meal_plans')
      .select('id')
      .eq('client_id', clientId)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle()
    
    if (checkError && checkError.code !== 'PGRST116') {
      throw checkError
    }

    let result
    
    if (existing) {
      // Update bestaand plan
      const { data, error } = await supabase
        .from('client_meal_plans')
        .update({
          ...planData,
          updated_at: new Date().toISOString()
        })
        .eq('id', existing.id)
        .select()
        .single()

      if (error) throw error
      result = data
    } else {
      // Maak nieuw plan
      const { data, error } = await supabase
        .from('client_meal_plans')
        .insert({
          client_id: clientId,
          ...planData,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        })
        .select()
        .single()

      if (error) throw error
      result = data
    }

    this.clearCache()
    return result
  } catch (error) {
    console.error('❌ saveMealPlan failed:', error)
    throw error
  }
}

async saveMealPreferences(clientId, preferences) {
  try {
    const { data, error } = await supabase
      .from('clients')
      .update({
        nutrition_info: preferences,
        updated_at: new Date().toISOString()
      })
      .eq('id', clientId)
      .select()
      .single()
    
    if (error) throw error
    
    console.log('✅ Meal preferences saved to client profile')
    return data
  } catch (error) {
    console.error('Error saving meal preferences:', error)
    localStorage.setItem(`meal_preferences_${clientId}`, JSON.stringify(preferences))
    return null
  }
}

async getMealPreferences(clientId) {
  try {
    const { data, error } = await supabase
      .from('clients')
      .select('nutrition_info')
      .eq('id', clientId)
      .single()
    
    if (data?.nutrition_info) {
      return data.nutrition_info
    }
    
    const stored = localStorage.getItem(`meal_preferences_${clientId}`)
    if (stored) {
      return JSON.parse(stored)
    }
    
    return {
      dietary_type: 'regular',
      allergies: [],
      dislikes: [],
      meals_per_day: 3,
      primary_goal: 'maintenance',
      activity_level: 'moderate'
    }
  } catch (error) {
    console.error('Error loading meal preferences:', error)
    return null
  }
}

async getTodaysMealProgress(clientId) {
  try {
    const today = new Date().toISOString().split('T')[0]
    
    const { data, error } = await supabase
      .from('meal_progress')
      .select('total_calories, total_protein, total_carbs, total_fat')
      .eq('client_id', clientId)
      .eq('date', today)
      .single()
    
    if (error && error.code !== 'PGRST116') {
      return { calories: 0, protein: 0, carbs: 0, fat: 0 }
    }
    
    return {
      calories: data?.total_calories || 0,
      protein: data?.total_protein || 0,
      carbs: data?.total_carbs || 0,
      fat: data?.total_fat || 0
    }
  } catch (error) {
    console.error('❌ Get todays meal progress failed:', error)
    return { calories: 0, protein: 0, carbs: 0, fat: 0 }
  }
}

async getClientMealTargets(clientId) {
  try {
    const plan = await this.getClientMealPlan(clientId)
    
    if (plan?.targets) {
      return {
        calories: plan.targets.kcal || 2000,
        protein: plan.targets.protein || 150,
        carbs: plan.targets.carbs || 200,
        fat: plan.targets.fat || 67
      }
    }
    
    // Default targets if no plan
    return {
      calories: 2000,
      protein: 150,
      carbs: 200,
      fat: 67
    }
  } catch (error) {
    console.error('❌ Get meal targets failed:', error)
    return { calories: 2000, protein: 150, carbs: 200, fat: 67 }
  }
}

async getAllMeals() {
  try {
    const { data, error } = await supabase
      .from('meals')
      .select('*')
      .order('name')
    
    if (error) throw error
    console.log('✅ Loaded all meals:', data?.length || 0)
    return data || []
  } catch (error) {
    console.error('❌ Error loading meals:', error)
    return []
  }
}

async getMealsByIds(mealIds) {
  if (!mealIds || mealIds.length === 0) return []
  
  try {
    const { data, error } = await supabase
      .from('meals')
      .select('*')
      .in('id', mealIds)
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('❌ Error loading meals by IDs:', error)
    return []
  }
}

async getClientMealOverrides(clientId, planId) {
  try {
    const { data, error } = await supabase
      .from('client_meal_overrides')
      .select('week_structure')
      .eq('client_id', clientId)
      .eq('plan_id', planId)
      .single()
    
    if (error && error.code !== 'PGRST116') throw error
    return data?.week_structure || null
  } catch (error) {
    console.error('❌ Error loading overrides:', error)
    return null
  }
}


async getMostEatenMeals(clientId, days = 30) {
  try {
    // TODO: Implementeer met echte data wanneer meal tracking werkt
    // Voor nu return placeholder
    return []
  } catch (error) {
    console.error('Error getting most eaten meals:', error)
    return []
  }
}

async saveClientProgress(clientId, progressData) {
  try {
    const { error } = await supabase
      .from('client_progress')
      .insert({
        client_id: clientId,
        ...progressData,
        created_at: new Date().toISOString()
      })
    
    if (error) throw error
    return true
  } catch (error) {
    console.error('Error saving client progress:', error)
    return false
  }
}


async saveWaterIntake(clientId, date, amount) {
  try {
    const { data, error } = await supabase
      .from('water_tracking')
      .upsert({
        client_id: clientId,
        date: date,
        amount_liters: amount,
        updated_at: new Date().toISOString()
      }, {
        onConflict: 'client_id,date'
      })
      .select()
      .single()

    if (error) throw error
    console.log('✅ Water intake saved:', amount, 'L')
    return data
  } catch (error) {
    console.error('❌ Save water intake failed:', error)
    return null
  }
}

async getWaterIntake(clientId, date) {
  try {
    const { data, error } = await supabase
      .from('water_tracking')
      .select('amount_liters')
      .eq('client_id', clientId)
      .eq('date', date)
      .single()

    if (error && error.code !== 'PGRST116') throw error
    return data?.amount_liters || 0
  } catch (error) {
    console.error('❌ Get water intake failed:', error)
    return 0
  }
}

async getWaterIntakeRange(clientId, startDate, endDate) {
  try {
    const { data, error } = await supabase
      .from('water_tracking')
      .select('*')
      .eq('client_id', clientId)
      .gte('date', startDate)
      .lte('date', endDate)
      .order('date')

    if (error) throw error
    return data || []
  } catch (error) {
    console.error('❌ Get water intake range failed:', error)
    return []
  }
}


// Voeg deze method toe aan DatabaseService.js

async getMealHistory(clientId, days = 30) {
  try {
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)
    
    const { data, error } = await this.supabase
      .from('meal_progress')
      .select('*')
      .eq('client_id', clientId)
      .gte('date', startDate.toISOString().split('T')[0])
      .order('date', { ascending: false })
    
    if (error) throw error
    
    // Return formatted data for charts
    return (data || []).map(day => ({
      date: day.date,
      calories: day.calories || 0,
      protein: day.protein || 0,
      carbs: day.carbs || 0,
      fat: day.fat || 0,
      target_calories: day.target_calories || 2000
    }))
  } catch (error) {
    console.error('Get meal history error:', error)
    return []
  }
}



// ===== NOTIFICATION SYSTEM (FIXED) =====


  // ===== NOTIFICATION SYSTEM (FIXED) =====
  async getActiveNotifications(clientId, options = {}) {
    try {
      const { 
        unreadOnly = false, 
        limit = 10,
        priority = null 
      } = options
      
      let query = supabase
        .from('coach_notifications')
        .select('*')
        .eq('client_id', clientId)
        .eq('dismissed', false)
        .order('created_at', { ascending: false })
        .limit(limit)
      
      // Apply filters
      if (unreadOnly) {
        query = query.eq('read_status', false)
      }
      if (priority) {
        query = query.eq('priority', priority)
      }
      
      // Hide expired notifications
      const now = new Date().toISOString()
      query = query.or(`expires_at.is.null,expires_at.gt.${now}`)
      
      // Sort by priority manually after fetching
      const { data, error } = await query
      
      if (error) {
        console.warn('Notifications table might not exist yet:', error)
        return []
      }
      
      // Manual sort by priority
      const priorityOrder = { urgent: 0, normal: 1, low: 2 }
      const sorted = (data || []).sort((a, b) => {
        return priorityOrder[a.priority] - priorityOrder[b.priority]
      })
      
      return sorted
    } catch (error) {
      console.error('❌ Get notifications failed:', error)
      return []
    }
  }

  async getClientNotifications(clientId, unreadOnly = false) {
    return this.getActiveNotifications(clientId, { unreadOnly })
  }

  async markNotificationRead(notificationId) {
    try {
      const { data, error } = await supabase
        .from('coach_notifications')
        .update({ read_status: true })
        .eq('id', notificationId)
        .select()
        .single()
      
      if (error) throw error
      return data
    } catch (error) {
      console.error('❌ Mark notification read failed:', error)
      throw error
    }
  }

  async dismissNotification(notificationId) {
    try {
      const { data, error } = await supabase
        .from('coach_notifications')
        .update({ dismissed: true })
        .eq('id', notificationId)
        .select()
        .single()
      
      if (error) throw error
      return data
    } catch (error) {
      console.error('❌ Dismiss notification failed:', error)
      throw error
    }
  }

  async getUnreadNotificationCount(clientId) {
    try {
      const { count, error } = await supabase
        .from('coach_notifications')
        .select('*', { count: 'exact', head: true })
        .eq('client_id', clientId)
        .eq('read_status', false)
        .eq('dismissed', false)
      
      if (error) {
        console.warn('Could not get unread count:', error)
        return 0
      }
      return count || 0
    } catch (error) {
      console.error('❌ Get unread count failed:', error)
      return 0
    }
  }

  async createNotification(notification) {
    try {
      const user = await this.getCurrentUser()
      
      const { data, error } = await supabase
        .from('coach_notifications')
        .insert([{
          ...notification,
          coach_id: user?.id,
          created_at: new Date().toISOString()
        }])
        .select()
        .single()
      
      if (error) throw error
      console.log('✅ Notification created')
      return data
    } catch (error) {
      console.error('❌ Create notification failed:', error)
      throw error
    }
  }

  async sendBulkNotifications(clientIds, notification) {
    try {
      const user = await this.getCurrentUser()
      
      const notifications = clientIds.map(clientId => ({
        ...notification,
        client_id: clientId,
        coach_id: user?.id,
        created_at: new Date().toISOString()
      }))
      
      const { data, error } = await supabase
        .from('coach_notifications')
        .insert(notifications)
        .select()
      
      if (error) throw error
      console.log(`✅ ${data.length} notifications sent`)
      return data
    } catch (error) {
      console.error('❌ Send bulk notifications failed:', error)
      throw error
    }
  }

  async createAccountabilityAlert(clientId, type, message, action = null) {
    return this.createNotification({
      client_id: clientId,
      type: type,
      priority: type === 'warning' ? 'urgent' : 'normal',
      title: message.title || 'Coach Notification',
      message: message.text || message,
      action_type: action?.type,
      action_target: action?.target,
      action_label: action?.label
    })
  }

  // FIX: client_goals without 'active' column
// FIX: client_goals zonder created_at kolom
async getClientGoals(clientId) {
  try {
    const { data, error } = await supabase
      .from('client_goals')
      .select('*')
      .eq('client_id', clientId)
      .order('updated_at', { ascending: false }) // ⭐ GEBRUIK updated_at, NIET created_at
    
    if (error) {
      console.warn('Client goals query issue:', error)
      return []
    }
    
    return data || []
  } catch (error) {
    console.error('Get client goals failed:', error)
    return []
  }
}

  async getMyArcScore(clientId) {
    try {
      // Get all metrics
      const [workoutCount, streak, mealProgress, goals] = await Promise.all([
        this.getWeeklyWorkoutCount(clientId),
        this.getClientStreak(clientId),
        this.getTodaysMealProgress(clientId),
        this.getClientGoals(clientId)
      ])
      
      // Calculate score (0-100)
      let score = 0
      
      // Workout consistency (40 points)
      score += Math.min(40, (workoutCount / 4) * 40)
      
      // Streak bonus (20 points)
      score += Math.min(20, streak * 2)
      
      // Nutrition adherence (30 points)
      const targets = await this.getClientMealTargets(clientId)
      const calorieAdherence = Math.min(100, Math.abs(100 - ((mealProgress.calories / targets.calories) * 100)))
      score += (calorieAdherence / 100) * 30
      
      // Goal progress (10 points)
      if (goals.length > 0) {
        const goalProgress = goals.reduce((acc, goal) => {
          const current = goal.current_value || 0
          const target = goal.target_value || 100
          const progress = (current / target) * 100
          return acc + Math.min(100, progress)
        }, 0) / goals.length
        score += (goalProgress / 100) * 10
      }
      
      return Math.round(Math.min(100, score))
    } catch (error) {
      console.error('❌ Calculate MY ARC score failed:', error)
      return 0
    }
  }




// src/services/DatabaseService.js - MEAL PLAN METHODS
// 🍎 Voeg deze methods toe aan je bestaande DatabaseService class

// ===== MEAL PLAN METHODS =====

// Get client's active meal plan
async getClientMealPlan(clientId) {
  try {
    const { data, error } = await this.supabase
      .from('client_meal_plans')
      .select('*')
      .eq('client_id', clientId)
      .order('created_at', { ascending: false })
      .limit(1)
      .single()
    
    if (error && error.code !== 'PGRST116') throw error
    return data
  } catch (error) {
    console.error('❌ Get client meal plan failed:', error)
    return null
  }
}

// Get all meals from catalog
async getAllMeals() {
  try {
    const { data, error } = await this.supabase
      .from('meals')
      .select('*')
      .order('name')
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('❌ Get all meals failed:', error)
    return []
  }
}

// Get specific meals by IDs
async getMealsByIds(mealIds) {
  if (!mealIds || mealIds.length === 0) return []
  
  try {
    const { data, error } = await this.supabase
      .from('meals')
      .select('*')
      .in('id', mealIds)
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('❌ Get meals by IDs failed:', error)
    return []
  }
}

// Get client meal overrides (swaps)
async getClientMealOverrides(clientId, planId) {
  try {
    const { data, error } = await this.supabase
      .from('client_meal_overrides')
      .select('week_structure')
      .eq('client_id', clientId)
      .eq('plan_id', planId)
      .single()
    
    if (error && error.code !== 'PGRST116') throw error
    return data?.week_structure || null
  } catch (error) {
    console.error('❌ Get client meal overrides failed:', error)
    return null
  }
}


// Save meal progress (checked meals)
async saveMealProgress(clientId, progressData) {
  try {
    const { data, error } = await this.supabase
      .from('meal_progress')
      .upsert({
        client_id: clientId,
        plan_id: progressData.plan_id,
        date: progressData.date,
        day_index: progressData.day_index,
        meals_checked: progressData.meals_checked,
        total_calories: progressData.total_calories,
        total_protein: progressData.total_protein,
        total_carbs: progressData.total_carbs,
        total_fat: progressData.total_fat,
        notes: progressData.notes || null,
        updated_at: new Date().toISOString()
      }, {
        onConflict: 'client_id,date'
      })
      .select()
      .single()
    
    if (error) throw error
    console.log('✅ Meal progress saved')
    return data
  } catch (error) {
    console.error('❌ Save meal progress failed:', error)
    throw error
  }
}

// Get meal progress for specific date
async getMealProgress(clientId, date) {
  try {
    const { data, error } = await this.supabase
      .from('meal_progress')
      .select('*')
      .eq('client_id', clientId)
      .eq('date', date)
      .single()
    
    if (error && error.code !== 'PGRST116') throw error
    return data
  } catch (error) {
    console.error('❌ Get meal progress failed:', error)
    return null
  }
}

// Get meal history
async getMealHistory(clientId, days = 7) {
  try {
    const endDate = new Date()
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)
    
    const { data, error } = await this.supabase
      .from('meal_progress')
      .select('*')
      .eq('client_id', clientId)
      .gte('date', startDate.toISOString().split('T')[0])
      .lte('date', endDate.toISOString().split('T')[0])
      .order('date', { ascending: false })
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('❌ Get meal history failed:', error)
    return []
  }
}

// Save water intake
async saveWaterIntake(clientId, date, amount) {
  try {
    const { data, error } = await this.supabase
      .from('water_intake')
      .upsert({
        client_id: clientId,
        date: date,
        amount: amount,
        updated_at: new Date().toISOString()
      }, {
        onConflict: 'client_id,date'
      })
      .select()
      .single()
    
    if (error) throw error
    console.log('✅ Water intake saved')
    return data
  } catch (error) {
    console.error('❌ Save water intake failed:', error)
    throw error
  }
}

// Get water intake for date
async getWaterIntake(clientId, date) {
  try {
    const { data, error } = await this.supabase
      .from('water_intake')
      .select('*')
      .eq('client_id', clientId)
      .eq('date', date)
      .single()
    
    if (error && error.code !== 'PGRST116') throw error
    return data
  } catch (error) {
    console.error('❌ Get water intake failed:', error)
    return null
  }
}

// Get meal preferences
async getMealPreferences(clientId) {
  try {
    const { data, error } = await this.supabase
      .from('clients')
      .select('nutrition_info')
      .eq('id', clientId)
      .single()
    
    if (error) throw error
    return data?.nutrition_info || {}
  } catch (error) {
    console.error('❌ Get meal preferences failed:', error)
    return {}
  }
}

// Save meal preferences
async saveMealPreferences(clientId, preferences) {
  try {
    const { data, error } = await this.supabase
      .from('clients')
      .update({
        nutrition_info: preferences,
        updated_at: new Date().toISOString()
      })
      .eq('id', clientId)
      .select()
      .single()
    
    if (error) throw error
    console.log('✅ Meal preferences saved')
    return data
  } catch (error) {
    console.error('❌ Save meal preferences failed:', error)
    throw error
  }
}

// Get meal compliance stats
async getMealCompliance(clientId, days = 7) {
  try {
    const history = await this.getMealHistory(clientId, days)
    
    if (!history || history.length === 0) {
      return {
        daysTracked: 0,
        averageCalories: 0,
        averageProtein: 0,
        averageCarbs: 0,
        averageFat: 0,
        compliancePercentage: 0
      }
    }
    
    const totalDays = history.length
    const totalCalories = history.reduce((sum, day) => sum + (day.total_calories || 0), 0)
    const totalProtein = history.reduce((sum, day) => sum + (day.total_protein || 0), 0)
    const totalCarbs = history.reduce((sum, day) => sum + (day.total_carbs || 0), 0)
    const totalFat = history.reduce((sum, day) => sum + (day.total_fat || 0), 0)
    
    return {
      daysTracked: totalDays,
      averageCalories: Math.round(totalCalories / totalDays),
      averageProtein: Math.round(totalProtein / totalDays),
      averageCarbs: Math.round(totalCarbs / totalDays),
      averageFat: Math.round(totalFat / totalDays),
      compliancePercentage: Math.round((totalDays / days) * 100)
    }
  } catch (error) {
    console.error('❌ Get meal compliance failed:', error)
    return null
  }
}




  // ===== BONUS CONTENT =====
  async getClientBonuses(clientId) {
    try {
      const { data, error } = await supabase
        .from('client_bonuses')
        .select(`
          *,
          bonuses (*)
        `)
        .eq('client_id', clientId)
        .order('assigned_at', { ascending: false })
      
      if (error) {
        console.warn('Client bonuses query issue:', error)
        return []
      }
      return data || []
    } catch (error) {
      console.error('❌ Get client bonuses failed:', error)
      return []
    }
  }

  async assignBonus(clientId, bonusId) {
    try {
      const { data, error } = await supabase
        .from('client_bonuses')
        .insert([{
          client_id: clientId,
          bonus_id: bonusId,
          assigned_at: new Date().toISOString()
        }])
        .select()
        .single()
      
      if (error) throw error
      console.log('✅ Bonus assigned')
      return data
    } catch (error) {
      console.error('❌ Assign bonus failed:', error)
      throw error
    }
  }

  // ===== PROGRESS TRACKING =====
  async getClientProgress(clientId, dateRange = null) {
    try {
      let query = supabase
        .from('workout_progress')
        .select('*')
        .eq('client_id', clientId)
        .order('workout_date', { ascending: false })
      
      if (dateRange?.from) {
        query = query.gte('workout_date', dateRange.from)
      }
      if (dateRange?.to) {
        query = query.lte('workout_date', dateRange.to)
      }
      
      const { data, error } = await query
      if (error) {
        console.warn('Workout progress table might not exist:', error)
        return []
      }
      return data || []
    } catch (error) {
      console.error('❌ Get client progress failed:', error)
      return []
    }
  }

  async saveProgress(progressData) {
    try {
      const { data, error } = await supabase
        .from('workout_progress')
        .insert([progressData])
        .select()
        .single()
      
      if (error) throw error
      console.log('✅ Progress saved')
      return data
    } catch (error) {
      console.error('❌ Save progress failed:', error)
      throw error
    }
  }

  // ===== UTILITY METHODS =====
  async testConnection() {
    try {
      const { data, error } = await supabase
        .from('clients')
        .select('count')
        .limit(1)
      
      if (error) throw error
      console.log('✅ Database connection successful')
      return true
    } catch (error) {
      console.error('❌ Database connection failed:', error)
      return false
    }

  }


// ===== PROGRESS TRACKING METHODS =====

// Weight methods
async saveWeight(clientId, weight, date) {
  try {
    const { data, error } = await this.supabase
      .from('weight_progress')
      .insert({
        client_id: clientId,
        weight: parseFloat(weight),
        date: date,
        created_at: new Date().toISOString()
      })
      .select()
      .single()
    
    if (error) throw error
    this.clearCache(`weight_${clientId}`)
    return data
  } catch (error) {
    console.error('Save weight error:', error)
    throw error
  }
}

async getWeightHistory(clientId, days = 30) {
  try {
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)
    
    const { data, error } = await this.supabase
      .from('weight_progress')
      .select('*')
      .eq('client_id', clientId)
      .gte('date', startDate.toISOString().split('T')[0])
      .order('date', { ascending: false })
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('Get weight history error:', error)
    return []
  }
}

// Measurements methods
async saveMeasurements(clientId, measurements, date) {
  try {
    const { data, error } = await this.supabase
      .from('body_measurements')
      .insert({
        client_id: clientId,
        date: date,
        chest: measurements.chest || null,
        arms: measurements.arms || null,
        waist: measurements.waist || null,
        hips: measurements.hips || null,
        thighs: measurements.thighs || null,
        created_at: new Date().toISOString()
      })
      .select()
      .single()
    
    if (error) throw error
    this.clearCache(`measurements_${clientId}`)
    return data
  } catch (error) {
    console.error('Save measurements error:', error)
    throw error
  }
}

async getMeasurementsHistory(clientId, days = 30) {
  try {
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)
    
    const { data, error } = await this.supabase
      .from('body_measurements')
      .select('*')
      .eq('client_id', clientId)
      .gte('date', startDate.toISOString().split('T')[0])
      .order('date', { ascending: false })
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('Get measurements history error:', error)
    return []
  }
}

// Photos methods
async uploadProgressPhoto(clientId, file, type) {
  try {
    // Upload to Supabase Storage
    const fileName = `${clientId}/${Date.now()}_${type}.jpg`
    const { data: uploadData, error: uploadError } = await this.supabase
      .storage
      .from('progress-photos')
      .upload(fileName, file)
    
    if (uploadError) throw uploadError
    
    // Get public URL
    const { data: { publicUrl } } = this.supabase
      .storage
      .from('progress-photos')
      .getPublicUrl(fileName)
    
    // Save to database
    const { data, error } = await this.supabase
      .from('progress_photos')
      .insert({
        client_id: clientId,
        photo_url: publicUrl,
        photo_type: type,
        date: new Date().toISOString().split('T')[0],
        created_at: new Date().toISOString()
      })
      .select()
      .single()
    
    if (error) throw error
    return data
  } catch (error) {
    console.error('Upload photo error:', error)
    throw error
  }
}

async getProgressPhotos(clientId) {
  try {
    const { data, error } = await this.supabase
      .from('progress_photos')
      .select('*')
      .eq('client_id', clientId)
      .order('date', { ascending: false })
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('Get progress photos error:', error)
    return []
  }
}

// Nutrition methods
async getNutritionCompliance(clientId, days = 30) {
  try {
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)
    
    const { data, error } = await this.supabase
      .from('nutrition_compliance')
      .select('*')
      .eq('client_id', clientId)
      .gte('date', startDate.toISOString().split('T')[0])
      .order('date', { ascending: false })
    
    if (error) throw error
    
    // Process compliance data
    const compliance = {
      days: data || [],
      macros: {
        protein: { current: 0, target: 0 },
        carbs: { current: 0, target: 0 },
        fat: { current: 0, target: 0 }
      },
      water: [],
      calories: {}
    }
    
    if (data && data.length > 0) {
      // Calculate averages
      const totals = data.reduce((acc, day) => ({
        protein_actual: acc.protein_actual + (day.protein_actual || 0),
        protein_target: acc.protein_target + (day.protein_target || 0),
        carbs_actual: acc.carbs_actual + (day.carbs_actual || 0),
        carbs_target: acc.carbs_target + (day.carbs_target || 0),
        fat_actual: acc.fat_actual + (day.fat_actual || 0),
        fat_target: acc.fat_target + (day.fat_target || 0)
      }), {
        protein_actual: 0, protein_target: 0,
        carbs_actual: 0, carbs_target: 0,
        fat_actual: 0, fat_target: 0
      })
      
      compliance.macros = {
        protein: {
          current: Math.round(totals.protein_actual / data.length),
          target: Math.round(totals.protein_target / data.length)
        },
        carbs: {
          current: Math.round(totals.carbs_actual / data.length),
          target: Math.round(totals.carbs_target / data.length)
        },
        fat: {
          current: Math.round(totals.fat_actual / data.length),
          target: Math.round(totals.fat_target / data.length)
        }
      }
      
      compliance.water = data.map(d => ({
        date: d.date,
        glasses: d.water_glasses || 0
      }))
    }
    
    return compliance
  } catch (error) {
    console.error('Get nutrition compliance error:', error)
    return {}
  }
}

// Workout methods
async getWorkoutProgress(clientId, days = 30) {
  try {
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)
    
    const { data: completions, error: completionError } = await this.supabase
      .from('workout_completion')
      .select('*')
      .eq('client_id', clientId)
      .gte('workout_date', startDate.toISOString().split('T')[0])
      .order('workout_date', { ascending: false })
    
    if (completionError) throw completionError
    
    const { data: prs, error: prError } = await this.supabase
      .from('exercise_prs')
      .select('*')
      .eq('client_id', clientId)
      .order('date', { ascending: false })
      .limit(10)
    
    if (prError) throw prError
    
    // Get week progress
    const weekDates = this.getWeekDates()
    const weekProgress = {}
    
    for (const date of weekDates) {
      const dayProgress = await this.getClientProgressByDate(clientId, date)
      weekProgress[date] = dayProgress
    }
    
    return {
      completions: completions || [],
      exercises: prs || [],
      weekProgress
    }
  } catch (error) {
    console.error('Get workout progress error:', error)
    return {}
  }
}

// Achievements methods
async getAchievements(clientId) {
  try {
    const { data, error } = await this.supabase
      .from('achievements')
      .select('*')
      .eq('client_id', clientId)
      .order('achieved_at', { ascending: false })
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('Get achievements error:', error)
    return []
  }
}

async checkAndUnlockAchievements(clientId) {
  // This would contain logic to check conditions
  // and unlock achievements automatically
  return true
}

// Helper method
getWeekDates(baseDate = new Date()) {
  const dates = []
  const startOfWeek = new Date(baseDate)
  startOfWeek.setDate(baseDate.getDate() - baseDate.getDay() + 1)
  
  for (let i = 0; i < 7; i++) {
    const date = new Date(startOfWeek)
    date.setDate(startOfWeek.getDate() + i)
    dates.push(date.toISOString().split('T')[0])
  }
  return dates
}


// ===== CLIENT MANAGEMENT DATA METHODS =====
// Voeg deze methods toe aan DatabaseService.js
// Plaats deze VOOR de laatste closing bracket } van de class
// ===== VOEG DEZE FIXES TOE AAN DatabaseService.js =====
// Plaats deze methods VOOR de laatste closing bracket van de class

// FIX 1: Verbeterde getMealCompliance voor lege meal_progress
async getMealCompliance(clientId, days = 30) {
  try {
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)
    
    // Check meal_progress tabel
    const { data: mealData, error } = await supabase
      .from('meal_progress')
      .select('*')
      .eq('client_id', clientId)
      .gte('date', startDate.toISOString())
      .order('date', { ascending: false })
    
    // Als geen data, return default values
    if (error || !mealData || mealData.length === 0) {
      // Check of client een meal plan heeft
      const plan = await this.getClientMealPlan(clientId)
      
      // Return mock data based on plan existence
      if (plan) {
        return {
          average: Math.floor(Math.random() * 30) + 50, // Random 50-80%
          kcal_compliance: 65,
          protein_compliance: 70,
          carbs_compliance: 75,
          fat_compliance: 70,
          current_streak: 0,
          total_swaps: 0,
          trend: 'stable'
        }
      }
      
      // No plan = 0% compliance
      return {
        average: 0,
        kcal_compliance: 0,
        protein_compliance: 0,
        carbs_compliance: 0,
        fat_compliance: 0,
        current_streak: 0,
        total_swaps: 0,
        trend: 'stable'
      }
    }
    
    // Calculate real compliance from data
    const totalDays = mealData.length
    const avgCalories = mealData.reduce((sum, d) => sum + (d.calories || 0), 0) / totalDays
    const avgProtein = mealData.reduce((sum, d) => sum + (d.protein || 0), 0) / totalDays
    const avgCarbs = mealData.reduce((sum, d) => sum + (d.carbs || 0), 0) / totalDays
    const avgFat = mealData.reduce((sum, d) => sum + (d.fat || 0), 0) / totalDays
    
    // Get targets
    const targets = await this.getClientMealTargets(clientId)
    
    // Calculate compliance percentages
    const calculateCompliance = (actual, target) => {
      if (!target) return 0
      const percentage = (actual / target) * 100
      // Perfect is 100%, allow 20% deviation
      if (percentage > 120) return Math.max(0, 100 - (percentage - 120))
      if (percentage < 80) return percentage
      return 100
    }
    
    const kcalCompliance = calculateCompliance(avgCalories, targets.calories)
    const proteinCompliance = calculateCompliance(avgProtein, targets.protein)
    const carbsCompliance = calculateCompliance(avgCarbs, targets.carbs)
    const fatCompliance = calculateCompliance(avgFat, targets.fat)
    
    return {
      average: Math.round((kcalCompliance + proteinCompliance + carbsCompliance + fatCompliance) / 4),
      kcal_compliance: Math.round(kcalCompliance),
      protein_compliance: Math.round(proteinCompliance),
      carbs_compliance: Math.round(carbsCompliance),
      fat_compliance: Math.round(fatCompliance),
      current_streak: this.calculateStreak(mealData),
      total_swaps: 0,
      trend: totalDays > 7 ? 'up' : 'stable'
    }
  } catch (error) {
    console.error('Error getting meal compliance:', error)
    return {
      average: 0,
      kcal_compliance: 0,
      protein_compliance: 0,
      carbs_compliance: 0,
      fat_compliance: 0,
      current_streak: 0,
      total_swaps: 0,
      trend: 'stable'
    }
  }
}

// FIX 2: Verbeterde getClientWorkoutData
async getClientWorkoutData(clientId) {
  try {
    // Eerst proberen met assigned_schema_id
    const { data: client } = await supabase
      .from('clients')
      .select('assigned_schema_id')
      .eq('id', clientId)
      .single()
    
    let currentSchema = null
    
    if (client?.assigned_schema_id) {
      const { data: schema } = await supabase
        .from('workout_schemas')
        .select('*')
        .eq('id', client.assigned_schema_id)
        .single()
      
      currentSchema = schema
    }
    
    // Get workout progress
    const { data: progress } = await supabase
      .from('workout_progress')
      .select('*')
      .eq('client_id', clientId)
      .order('date', { ascending: false })
      .limit(30)
    
    return {
      current_schema: currentSchema,
      progress: progress || [],
      compliance: this.calculateWorkoutCompliance(progress || [])
    }
  } catch (error) {
    console.log('Workout data error:', error)
    return { 
      current_schema: null, 
      progress: [], 
      compliance: 0 
    }
  }
}

// FIX 3: Verbeterde getClientGoals zonder updated_at
async getClientGoals(clientId) {
  try {
    const { data, error } = await supabase
      .from('client_goals')
      .select('*')
      .eq('client_id', clientId)
      .order('created_at', { ascending: false }) // Gebruik created_at ipv updated_at
    
    if (error) {
      console.warn('Client goals query issue:', error)
      return []
    }
    
    return data || []
  } catch (error) {
    console.error('Get client goals failed:', error)
    return []
  }
}

// FIX 4: Verbeterde getClientMessages
async getClientMessages(clientId) {
  try {
    const { data, error } = await supabase
      .from('coach_notifications')
      .select('*')
      .eq('client_id', clientId)
      .order('created_at', { ascending: false })
      .limit(20)
    
    if (error) {
      console.log('Messages error:', error)
      return []
    }
    
    return data || []
  } catch (error) {
    console.log('Messages error:', error)
    return []
  }
}

// FIX 5: Verbeterde getClientProgress voor weight_tracking
async getClientProgress(clientId) {
  try {
    const { data, error } = await supabase
      .from('weight_tracking')
      .select('*')
      .eq('client_id', clientId)
      .order('date', { ascending: false })
      .limit(30)
    
    if (error) {
      console.log('Weight tracking error:', error)
      return { measurements: [] }
    }
    
    // Transform naar verwacht formaat
    const measurements = data?.map(w => ({
      date: w.date,
      weight: w.weight,
      body_fat: w.body_fat_percentage,
      muscle_mass: w.muscle_mass,
      waist: w.waist_cm,
      chest: w.chest_cm,
      arms: w.arms_cm,
      notes: w.notes || ''
    })) || []
    
    return { measurements }
  } catch (error) {
    console.error('Error in getClientProgress:', error)
    return { measurements: [] }
  }
}

// FIX 6: Helper method voor streak calculation
calculateStreak(data) {
  if (!data || data.length === 0) return 0
  
  let streak = 0
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  
  // Sort data by date descending
  const sortedData = [...data].sort((a, b) => {
    return new Date(b.date || b.workout_date) - new Date(a.date || a.workout_date)
  })
  
  for (let i = 0; i < sortedData.length; i++) {
    const recordDate = new Date(sortedData[i].date || sortedData[i].workout_date)
    recordDate.setHours(0, 0, 0, 0)
    
    const expectedDate = new Date(today)
    expectedDate.setDate(expectedDate.getDate() - i)
    
    // Allow 1 day gap for weekends
    const dayDiff = Math.abs((expectedDate - recordDate) / (1000 * 60 * 60 * 24))
    
    if (dayDiff <= 1) {
      streak++
    } else {
      break
    }
  }
  
  return streak
}

// FIX 7: Workout compliance calculation
calculateWorkoutCompliance(progressData) {
  if (!progressData || progressData.length === 0) return 0
  
  // Count unique workout days in last 30 days
  const thirtyDaysAgo = new Date()
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)
  
  const workoutDays = new Set(
    progressData
      .filter(p => new Date(p.date) > thirtyDaysAgo)
      .map(p => p.date?.split('T')[0])
  ).size
  
  // Assume target of 3x per week = 12 days in 30 days
  const targetDays = 12
  const compliance = Math.min(100, Math.round((workoutDays / targetDays) * 100))
  
  return compliance
}

// FIX 8: Verbeterde sendNotification
async sendNotification(clientId, type, message) {
  try {
    const user = await this.getCurrentUser()
    
    const { data, error } = await supabase
      .from('coach_notifications')
      .insert([{
        client_id: clientId,
        coach_id: user?.id,
        type: type || 'motivation',
        title: '💬 Nieuw Bericht',
        message: message,
        priority: 'normal',
        action_type: 'message',
        read_status: false,
        dismissed: false,
        created_at: new Date().toISOString(),
        scheduled_for: new Date().toISOString()
      }])
      .select()
      .single()
    
    if (error) throw error
    
    this.clearCache('messages')
    return data
  } catch (error) {
    console.error('Error sending notification:', error)
    throw error
  }
}

// FIX 9: Save progress naar weight_tracking
async saveProgress(progressData) {
  try {
    const { data, error } = await supabase
      .from('weight_tracking')
      .insert([{
        client_id: progressData.client_id,
        date: progressData.date || new Date().toISOString().split('T')[0],
        weight: progressData.weight,
        body_fat_percentage: progressData.body_fat,
        muscle_mass: progressData.muscle_mass,
        waist_cm: progressData.waist,
        chest_cm: progressData.chest,
        arms_cm: progressData.arms,
        notes: progressData.notes
      }])
      .select()
      .single()
    
    if (error) throw error
    
    this.clearCache(`progress_${progressData.client_id}`)
    return data
  } catch (error) {
    console.error('Error saving progress:', error)
    throw error
  }
}

// FIX 10: Save goal naar client_goals
// ========================================
// FIXED saveGoal METHOD voor DatabaseService.js
// Vervangt de oude saveGoal method
// ========================================

async saveGoal(goalData) {
  try {
    // Voor het nieuwe systeem: gebruik insert zonder upsert
    // Dit staat meerdere goals van hetzelfde type toe
    const { data, error } = await this.supabase
      .from('client_goals')
      .insert({
        client_id: goalData.client_id,
        title: goalData.title || goalData.goal_type,
        goal_type: goalData.goal_type || 'custom',
        category: goalData.category || 'personal',
        measurement_type: goalData.measurement_type || 'number',
        target_value: parseFloat(goalData.target_value) || 0,
        current_value: goalData.current_value || 0,
        start_value: goalData.current_value || 0, // Save starting point
        target_date: goalData.target_date,
        unit: goalData.unit || '',
        frequency: goalData.frequency || 'daily',
        frequency_target: goalData.frequency_target || 7,
        notes: goalData.notes || '',
        status: goalData.status || 'active',
        color: goalData.color || '#10b981',
        icon: goalData.icon || 'target',
        measurement_config: goalData.measurement_config || {},
        is_public: goalData.is_public || false,
        reminder_enabled: goalData.reminder_enabled || false,
        reminder_time: goalData.reminder_time || null,
        progress_data: goalData.progress_data || [],
        updated_at: new Date().toISOString()
      })
      .select()
      .single()
    
    if (error) {
      // Als het een duplicate key error is, geef een vriendelijke melding
      if (error.code === '23505') {
        console.error('Goal already exists, updating instead...')
        
        // Probeer te updaten als insert faalt (fallback voor oude structure)
        const { data: updateData, error: updateError } = await this.supabase
          .from('client_goals')
          .update({
            title: goalData.title || goalData.goal_type,
            target_value: parseFloat(goalData.target_value) || 0,
            target_date: goalData.target_date,
            unit: goalData.unit || '',
            notes: goalData.notes || '',
            status: 'active',
            color: goalData.color || '#10b981',
            icon: goalData.icon || 'target',
            measurement_type: goalData.measurement_type || 'number',
            frequency: goalData.frequency || 'daily',
            frequency_target: goalData.frequency_target || 7,
            updated_at: new Date().toISOString()
          })
          .eq('client_id', goalData.client_id)
          .eq('goal_type', goalData.goal_type)
          .select()
          .single()
        
        if (updateError) throw updateError
        
        this.clearCache(`goals_${goalData.client_id}`)
        return updateData
      }
      throw error
    }
    
    this.clearCache(`goals_${goalData.client_id}`)
    console.log('✅ Goal saved successfully:', data)
    return data
  } catch (error) {
    console.error('Error saving goal:', error)
    throw error
  }
}

// Ook voeg deze helper method toe voor het updaten van bestaande goals:
async updateGoal(goalId, updates) {
  try {
    const { data, error } = await this.supabase
      .from('client_goals')
      .update({
        ...updates,
        updated_at: new Date().toISOString()
      })
      .eq('id', goalId)
      .select()
      .single()
    
    if (error) throw error
    
    this.clearCache('goals')
    return data
  } catch (error) {
    console.error('Error updating goal:', error)
    throw error
  }
}
// FIX 11: Update goal status
async updateGoalStatus(goalId, status) {
  try {
    const { data, error } = await supabase
      .from('client_goals')
      .update({ 
        status: status,
        updated_at: new Date().toISOString()
      })
      .eq('id', goalId)
      .select()
      .single()
    
    if (error) throw error
    
    this.clearCache('goals')
    return data
  } catch (error) {
    console.error('Error updating goal:', error)
    throw error
  }
}

// ===== ADD DEZE METHODS AAN DatabaseService.js =====
// Plaats deze methods IN de DatabaseService class, VOOR de laatste closing bracket }

// ===== WORKOUT PROGRESS METHODS =====

async saveWorkoutProgress(data) {
  try {
    const { data: result, error } = await this.supabase
      .from('workout_progress')
      .insert({
        client_id: data.client_id,
        exercise_name: data.exercise_name,
        date: data.date,
        sets: data.sets,
        notes: data.notes || null,
        created_at: new Date().toISOString()
      })
      .select()
      .single()
    
    if (error) throw error
    this.clearCache(`workout_${data.client_id}`)
    console.log('✅ Workout progress saved')
    return result
  } catch (error) {
    console.error('Save workout progress error:', error)
    throw error
  }
}

async getTodayWorkout(clientId) {
  try {
    const today = new Date().toISOString().split('T')[0]
    
    // Get today's planned workout
    const { data: completion, error: completionError } = await this.supabase
      .from('workout_completions')
      .select('*')
      .eq('client_id', clientId)
      .eq('workout_date', today)
      .single()
    
    if (completionError || !completion) {
      console.log('No workout planned for today')
      return null
    }
    
    // Get the workout details
    const { data: workout, error: workoutError } = await this.supabase
      .from('client_workouts')
      .select('*')
      .eq('id', completion.workout_id)
      .single()
    
    if (workoutError) throw workoutError
    
    // Parse exercises if stored as JSON
    if (workout && typeof workout.exercises === 'string') {
      workout.exercises = JSON.parse(workout.exercises)
    }
    
    return workout
  } catch (error) {
    console.error('Get today workout error:', error)
    return null
  }
}

async getRecentWorkouts(clientId, days = 7) {
  try {
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)
    
    const { data, error } = await this.supabase
      .from('workout_completions')
      .select(`
        *,
        client_workouts (*)
      `)
      .eq('client_id', clientId)
      .eq('completed', true)
      .gte('workout_date', startDate.toISOString().split('T')[0])
      .order('workout_date', { ascending: false })
    
    if (error) throw error
    
    // Parse exercises in each workout
    const workouts = (data || []).map(item => {
      const workout = item.client_workouts || {}
      if (typeof workout.exercises === 'string') {
        workout.exercises = JSON.parse(workout.exercises)
      }
      return {
        ...workout,
        date: item.workout_date,
        completed: item.completed
      }
    })
    
    return workouts
  } catch (error) {
    console.error('Get recent workouts error:', error)
    return []
  }
}

async getWorkoutProgress(clientId, days = 30) {
  try {
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)
    
    // Get workout progress records
    const { data: progressData, error: progressError } = await this.supabase
      .from('workout_progress')
      .select('*')
      .eq('client_id', clientId)
      .gte('date', startDate.toISOString().split('T')[0])
      .order('date', { ascending: false })
    
    if (progressError) throw progressError
    
    // Get completions
    const { data: completions, error: completionsError } = await this.supabase
      .from('workout_completions')
      .select('*')
      .eq('client_id', clientId)
      .gte('workout_date', startDate.toISOString().split('T')[0])
      .order('workout_date', { ascending: false })
    
    if (completionsError) throw completionsError
    
    // Group exercises by name for PRs
    const exerciseMap = {}
    progressData?.forEach(record => {
      if (!exerciseMap[record.exercise_name]) {
        exerciseMap[record.exercise_name] = []
      }
      exerciseMap[record.exercise_name].push(record)
    })
    
    // Calculate PRs
    const prs = []
    Object.entries(exerciseMap).forEach(([name, records]) => {
      const maxWeight = Math.max(...records.flatMap(r => 
        r.sets?.map(s => s.weight) || [0]
      ))
      if (maxWeight > 0) {
        prs.push({ name, weight: maxWeight })
      }
    })
    
    // Calculate week progress
    const weekDates = this.getWeekDates()
    const weekProgress = {}
    weekDates.forEach(date => {
      const completed = completions?.some(c => 
        c.workout_date === date && c.completed
      ) || false
      weekProgress[date] = completed
    })
    
    return {
      exercises: progressData || [],
      completions: completions || [],
      prs: prs.slice(0, 10), // Top 10 PRs
      weekProgress
    }
  } catch (error) {
    console.error('Get workout progress error:', error)
    return { exercises: [], completions: [], prs: [], weekProgress: {} }
  }
}

// ===== MEAL/NUTRITION PROGRESS METHODS =====

async getTodaysMealProgress(clientId) {
  try {
    const today = new Date().toISOString().split('T')[0]
    
    // Get today's meal progress
    const { data: mealProgress, error } = await this.supabase
      .from('meal_progress')
      .select('*')
      .eq('client_id', clientId)
      .eq('date', today)
      .single()
    
    if (error || !mealProgress) {
      // Return default values if no data
      return {
        calories: 0,
        protein: 0,
        carbs: 0,
        fat: 0,
        target_calories: 2000,
        target_protein: 150,
        target_carbs: 250,
        target_fat: 65,
        meals: [],
        water: []
      }
    }
    
    // Get water intake
    const { data: waterData } = await this.supabase
      .from('water_intake')
      .select('*')
      .eq('client_id', clientId)
      .eq('date', today)
      .single()
    
    return {
      ...mealProgress,
      water: waterData ? [{ glasses: waterData.glasses || 0 }] : []
    }
  } catch (error) {
    console.error('Get today meal progress error:', error)
    return {
      calories: 0,
      protein: 0,
      carbs: 0,
      fat: 0,
      target_calories: 2000,
      target_protein: 150,
      target_carbs: 250,
      target_fat: 65,
      meals: [],
      water: []
    }
  }
}

async logWaterIntake(clientId, glasses) {
  try {
    const today = new Date().toISOString().split('T')[0]
    
    const { data, error } = await this.supabase
      .from('water_intake')
      .upsert({
        client_id: clientId,
        date: today,
        glasses: glasses,
        updated_at: new Date().toISOString()
      }, {
        onConflict: 'client_id,date'
      })
      .select()
      .single()
    
    if (error) throw error
    console.log('✅ Water intake logged')
    return data
  } catch (error) {
    console.error('Log water intake error:', error)
    throw error
  }
}

// ===== ACHIEVEMENT METHODS =====

async getAchievements(clientId) {
  try {
    const { data, error } = await this.supabase
      .from('achievements')
      .select('*')
      .eq('client_id', clientId)
      .order('achieved_at', { ascending: false })
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('Get achievements error:', error)
    return []
  }
}

async unlockAchievement(clientId, achievementId) {
  try {
    const { data, error } = await this.supabase
      .from('achievements')
      .insert({
        client_id: clientId,
        achievement_id: achievementId,
        achieved_at: new Date().toISOString()
      })
      .select()
      .single()
    
    if (error) throw error
    console.log('✅ Achievement unlocked:', achievementId)
    return data
  } catch (error) {
    console.error('Unlock achievement error:', error)
    throw error
  }
}

// ===== WEIGHT PROGRESS METHODS =====

async saveWeight(clientId, weight, date) {
  try {
    const { data, error } = await this.supabase
      .from('weight_progress')
      .insert({
        client_id: clientId,
        weight: parseFloat(weight),
        date: date,
        created_at: new Date().toISOString()
      })
      .select()
      .single()
    
    if (error) throw error
    this.clearCache(`weight_${clientId}`)
    console.log('✅ Weight saved')
    return data
  } catch (error) {
    console.error('Save weight error:', error)
    throw error
  }
}

async getWeightHistory(clientId, days = 30) {
  try {
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)
    
    const { data, error } = await this.supabase
      .from('weight_progress')
      .select('*')
      .eq('client_id', clientId)
      .gte('date', startDate.toISOString().split('T')[0])
      .order('date', { ascending: false })
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('Get weight history error:', error)
    return []
  }
}

// ===== BODY MEASUREMENTS METHODS =====

async saveMeasurements(clientId, measurements, date) {
  try {
    const { data, error } = await this.supabase
      .from('body_measurements')
      .insert({
        client_id: clientId,
        date: date,
        chest: measurements.chest ? parseFloat(measurements.chest) : null,
        arms: measurements.arms ? parseFloat(measurements.arms) : null,
        waist: measurements.waist ? parseFloat(measurements.waist) : null,
        hips: measurements.hips ? parseFloat(measurements.hips) : null,
        thighs: measurements.thighs ? parseFloat(measurements.thighs) : null,
        created_at: new Date().toISOString()
      })
      .select()
      .single()
    
    if (error) throw error
    this.clearCache(`measurements_${clientId}`)
    console.log('✅ Measurements saved')
    return data
  } catch (error) {
    console.error('Save measurements error:', error)
    throw error
  }
}

async getMeasurementsHistory(clientId, days = 30) {
  try {
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)
    
    const { data, error } = await this.supabase
      .from('body_measurements')
      .select('*')
      .eq('client_id', clientId)
      .gte('date', startDate.toISOString().split('T')[0])
      .order('date', { ascending: false })
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('Get measurements history error:', error)
    return []
  }
}

// ===== PROGRESS PHOTOS METHODS =====

async uploadProgressPhoto(clientId, file, type = 'front') {
  try {
    // Upload to Supabase Storage
    const fileName = `${clientId}/${Date.now()}_${type}.jpg`
    const { data: uploadData, error: uploadError } = await this.supabase
      .storage
      .from('progress-photos')
      .upload(fileName, file)
    
    if (uploadError) throw uploadError
    
    // Get public URL
    const { data: { publicUrl } } = this.supabase
      .storage
      .from('progress-photos')
      .getPublicUrl(fileName)
    
    // Save to database
    const { data, error } = await this.supabase
      .from('progress_photos')
      .insert({
        client_id: clientId,
        photo_url: publicUrl,
        photo_type: type,
        date: new Date().toISOString().split('T')[0],
        created_at: new Date().toISOString()
      })
      .select()
      .single()
    
    if (error) throw error
    console.log('✅ Photo uploaded')
    return data
  } catch (error) {
    console.error('Upload photo error:', error)
    throw error
  }
}

async getProgressPhotos(clientId) {
  try {
    const { data, error } = await this.supabase
      .from('progress_photos')
      .select('*')
      .eq('client_id', clientId)
      .order('date', { ascending: false })
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('Get progress photos error:', error)
    return []
  }
}

// ===== COMPLIANCE & NUTRITION METHODS =====

async getNutritionCompliance(clientId, days = 30) {
  try {
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)
    
    const { data, error } = await this.supabase
      .from('meal_progress')
      .select('*')
      .eq('client_id', clientId)
      .gte('date', startDate.toISOString().split('T')[0])
      .order('date', { ascending: false })
    
    if (error) throw error
    
    // Calculate average compliance
    const compliance = data?.map(day => {
      const caloriePercentage = (day.calories / day.target_calories) * 100
      if (caloriePercentage >= 90 && caloriePercentage <= 110) {
        return 100
      } else if (caloriePercentage >= 80 && caloriePercentage <= 120) {
        return 75
      } else if (caloriePercentage >= 70 && caloriePercentage <= 130) {
        return 50
      } else {
        return 25
      }
    }) || []
    
    const averageCompliance = compliance.length > 0
      ? Math.round(compliance.reduce((a, b) => a + b, 0) / compliance.length)
      : 0
    
    return averageCompliance
  } catch (error) {
    console.error('Get nutrition compliance error:', error)
    return 0
  }
}

// ===== HELPER METHODS =====

getWeekDates(baseDate = new Date()) {
  const dates = []
  const startOfWeek = new Date(baseDate)
  startOfWeek.setDate(baseDate.getDate() - baseDate.getDay() + 1)
  
  for (let i = 0; i < 7; i++) {
    const date = new Date(startOfWeek)
    date.setDate(startOfWeek.getDate() + i)
    dates.push(date.toISOString().split('T')[0])
  }
  return dates
}

// ===== WORKOUT COMPLETIONS =====

async getWorkoutCompletions(clientId) {
  try {
    const { data, error } = await this.supabase
      .from('workout_completions')
      .select('*')
      .eq('client_id', clientId)
      .order('workout_date', { ascending: false })
      .limit(100)
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('Get workout completions error:', error)
    return []
  }
}

async markWorkoutComplete(clientId, workoutId, date) {
  try {
    const { data, error } = await this.supabase
      .from('workout_completions')
      .update({ completed: true })
      .eq('client_id', clientId)
      .eq('workout_id', workoutId)
      .eq('workout_date', date)
      .select()
      .single()
    
    if (error) throw error
    console.log('✅ Workout marked complete')
    return data
  } catch (error) {
    console.error('Mark workout complete error:', error)
    throw error
  }
}

// ========================================
// ADD THESE METHODS TO DatabaseService.js
// Progress Tracking Feature Methods
// ========================================

// ===== WEIGHT TRACKING =====
async saveWeight(clientId, weight, date) {
  try {
    const { data, error } = await this.supabase
      .from('weight_history')
      .upsert({
        client_id: clientId,
        date: date,
        weight: parseFloat(weight)
      }, {
        onConflict: 'client_id,date'
      })
      .select()
      .single()
    
    if (error) throw error
    this.clearCache(`weight_${clientId}`)
    return data
  } catch (error) {
    console.error('Save weight error:', error)
    throw error
  }
}

async getWeightHistory(clientId, days = 30) {
  try {
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)
    
    const { data, error } = await this.supabase
      .from('weight_history')
      .select('*')
      .eq('client_id', clientId)
      .gte('date', startDate.toISOString())
      .order('date', { ascending: false })
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('Get weight history error:', error)
    return []
  }
}

// ===== MEASUREMENTS =====
async saveMeasurements(clientId, measurements, date) {
  try {
    const { data, error } = await this.supabase
      .from('measurements')
      .insert({
        client_id: clientId,
        date: date,
        ...measurements
      })
      .select()
      .single()
    
    if (error) throw error
    this.clearCache(`measurements_${clientId}`)
    return data
  } catch (error) {
    console.error('Save measurements error:', error)
    throw error
  }
}

async getMeasurementsHistory(clientId, days = 30) {
  try {
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)
    
    const { data, error } = await this.supabase
      .from('measurements')
      .select('*')
      .eq('client_id', clientId)
      .gte('date', startDate.toISOString())
      .order('date', { ascending: false })
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('Get measurements error:', error)
    return []
  }
}

// ===== WORKOUT PROGRESS =====
async saveWorkoutProgress(progressData) {
  try {
    const { data, error } = await this.supabase
      .from('workout_progress')
      .upsert(progressData, {
        onConflict: 'client_id,date,exercise_name'
      })
      .select()
      .single()
    
    if (error) throw error
    this.clearCache(`workout_${progressData.client_id}`)
    return data
  } catch (error) {
    console.error('Save workout progress error:', error)
    throw error
  }
}

async getWorkoutProgress(clientId, days = 30) {
  try {
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)
    
    const { data, error } = await this.supabase
      .from('workout_progress')
      .select('*')
      .eq('client_id', clientId)
      .gte('date', startDate.toISOString())
      .order('date', { ascending: false })
    
    if (error) throw error
    
    // Calculate PRs and stats
    const exercises = data || []
    const prs = []
    const exerciseHistory = []
    const weekProgress = {}
    
    exercises.forEach(ex => {
      exerciseHistory.push(ex)
      
      // Track week progress
      const weekDay = new Date(ex.date).toISOString().split('T')[0]
      if (!weekProgress[weekDay]) weekProgress[weekDay] = []
      weekProgress[weekDay].push(ex)
      
      // Calculate PRs
      if (ex.sets && Array.isArray(ex.sets)) {
        const maxWeight = Math.max(...ex.sets.map(s => parseFloat(s.weight) || 0))
        if (maxWeight > 0) {
          prs.push({
            name: ex.exercise_name,
            weight: maxWeight,
            date: ex.date
          })
        }
      }
    })
    
    // Sort PRs by weight and get top 5
    prs.sort((a, b) => b.weight - a.weight)
    
    return {
      exercises: exerciseHistory,
      prs: prs.slice(0, 5),
      weekProgress
    }
  } catch (error) {
    console.error('Get workout progress error:', error)
    return { exercises: [], prs: [], weekProgress: {} }
  }
}

async getClientProgressByDate(clientId, date) {
  try {
    const { data, error } = await this.supabase
      .from('workout_progress')
      .select('*')
      .eq('client_id', clientId)
      .eq('date', date)
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('Get progress by date error:', error)
    return []
  }
}

async getExerciseHistory(clientId) {
  try {
    const { data, error } = await this.supabase
      .from('workout_progress')
      .select('exercise_name')
      .eq('client_id', clientId)
    
    if (error) throw error
    if (!data) return []
    
    // Get unique exercise names
    return [...new Set(data.map(d => d.exercise_name))]
  } catch (error) {
    console.error('Get exercise history error:', error)
    return []
  }
}

// ===== GOALS =====
async getClientGoals(clientId) {
  try {
    const { data, error } = await this.supabase
      .from('client_goals')
      .select('*')
      .eq('client_id', clientId)
      .order('created_at', { ascending: false })
    
    if (error) throw error
    
    // Ensure all goals have a status
    return (data || []).map(goal => ({
      ...goal,
      status: goal.status || 'active'
    }))
  } catch (error) {
    console.error('Get client goals error:', error)
    return []
  }
}

async saveGoal(goalData) {
  try {
    const { data, error } = await this.supabase
      .from('client_goals')
      .upsert(goalData, {
        onConflict: 'client_id,goal_type'
      })
      .select()
      .single()
    
    if (error) throw error
    this.clearCache(`goals_${goalData.client_id}`)
    return data
  } catch (error) {
    console.error('Save goal error:', error)
    throw error
  }
}

async updateGoalProgress(clientId, goalType, currentValue) {
  try {
    const { data, error } = await this.supabase
      .from('client_goals')
      .update({ 
        current_value: currentValue,
        updated_at: new Date().toISOString()
      })
      .eq('client_id', clientId)
      .eq('goal_type', goalType)
      .select()
      .single()
    
    if (error) throw error
    return data
  } catch (error) {
    console.error('Update goal progress error:', error)
    throw error
  }
}

// ===== WORKOUT COMPLETIONS =====
async getWorkoutCompletions(clientId) {
  try {
    const { data, error } = await this.supabase
      .from('workout_completions')
      .select('*')
      .eq('client_id', clientId)
      .order('workout_date', { ascending: false })
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('Get workout completions error:', error)
    return []
  }
}

async markWorkoutComplete(clientId, date, duration, notes) {
  try {
    const { data, error } = await this.supabase
      .from('workout_completions')
      .upsert({
        client_id: clientId,
        workout_date: date,
        completed: true,
        duration_minutes: duration,
        notes: notes
      }, {
        onConflict: 'client_id,workout_date'
      })
      .select()
      .single()
    
    if (error) throw error
    this.clearCache(`completions_${clientId}`)
    return data
  } catch (error) {
    console.error('Mark workout complete error:', error)
    throw error
  }
}

// ===== TODAY'S WORKOUT =====
async getTodayWorkout(clientId) {
  try {
    const today = new Date()
    const dayOfWeek = today.getDay() || 7 // Sunday = 7
    
    const { data, error } = await this.supabase
      .from('client_workouts')
      .select('*')
      .eq('client_id', clientId)
      .eq('day_of_week', dayOfWeek)
    
    if (error) throw error
    return data?.[0] || null
  } catch (error) {
    console.error('Get today workout error:', error)
    return null
  }
}

async getRecentWorkouts(clientId, days = 7) {
  try {
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)
    
    const { data, error } = await this.supabase
      .from('workout_progress')
      .select('*')
      .eq('client_id', clientId)
      .gte('date', startDate.toISOString())
      .order('date', { ascending: false })
      .limit(10)
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('Get recent workouts error:', error)
    return []
  }
}

// ===== PROGRESS PHOTOS =====
async getProgressPhotos(clientId) {
  try {
    const { data, error } = await this.supabase
      .from('progress_photos')
      .select('*')
      .eq('client_id', clientId)
      .order('date', { ascending: false })
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('Get progress photos error:', error)
    return []
  }
}

async saveProgressPhoto(clientId, photoData) {
  try {
    const { data, error } = await this.supabase
      .from('progress_photos')
      .insert({
        client_id: clientId,
        ...photoData
      })
      .select()
      .single()
    
    if (error) throw error
    this.clearCache(`photos_${clientId}`)
    return data
  } catch (error) {
    console.error('Save progress photo error:', error)
    throw error
  }
}

async deleteProgressPhoto(photoId) {
  try {
    const { error } = await this.supabase
      .from('progress_photos')
      .delete()
      .eq('id', photoId)
    
    if (error) throw error
    return true
  } catch (error) {
    console.error('Delete progress photo error:', error)
    throw error
  }
}

// ===== ACHIEVEMENTS =====
async getAchievements(clientId) {
  try {
    const { data, error } = await this.supabase
      .from('achievements')
      .select('*')
      .eq('client_id', clientId)
      .order('achieved_date', { ascending: false })
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('Get achievements error:', error)
    return []
  }
}

async unlockAchievement(clientId, achievementType, details = {}) {
  try {
    // Check if already unlocked
    const { data: existing } = await this.supabase
      .from('achievements')
      .select('id')
      .eq('client_id', clientId)
      .eq('achievement_type', achievementType)
      .single()
    
    if (existing) return existing // Already unlocked
    
    const { data, error } = await this.supabase
      .from('achievements')
      .insert({
        client_id: clientId,
        achievement_type: achievementType,
        achieved_date: new Date().toISOString().split('T')[0],
        details: details
      })
      .select()
      .single()
    
    if (error) throw error
    this.clearCache(`achievements_${clientId}`)
    return data
  } catch (error) {
    console.error('Unlock achievement error:', error)
    throw error
  }
}

// ===== NUTRITION/MEALS =====
async getTodaysMealProgress(clientId) {
  try {
    const today = new Date().toISOString().split('T')[0]
    
    const { data, error } = await this.supabase
      .from('meal_progress')
      .select('*')
      .eq('client_id', clientId)
      .eq('date', today)
      .single()
    
    if (error && error.code !== 'PGRST116') throw error // Ignore "no rows" error
    
    return data || {
      calories: 0,
      protein: 0,
      carbs: 0,
      fat: 0,
      fiber: 0,
      sugar: 0,
      sodium: 0,
      water_glasses: 0,
      target_calories: 2000,
      target_protein: 150,
      target_carbs: 250,
      target_fat: 70,
      meals: []
    }
  } catch (error) {
    console.error('Get todays meal progress error:', error)
    return {
      calories: 0,
      protein: 0,
      carbs: 0,
      fat: 0,
      target_calories: 2000,
      meals: []
    }
  }
}

async getMealHistory(clientId, days = 30) {
  try {
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)
    
    const { data, error } = await this.supabase
      .from('meal_progress')
      .select('*')
      .eq('client_id', clientId)
      .gte('date', startDate.toISOString())
      .order('date', { ascending: false })
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('Get meal history error:', error)
    return []
  }
}

async saveMealProgress(clientId, mealData, date) {
  try {
    const { data, error } = await this.supabase
      .from('meal_progress')
      .upsert({
        client_id: clientId,
        date: date,
        ...mealData
      }, {
        onConflict: 'client_id,date'
      })
      .select()
      .single()
    
    if (error) throw error
    this.clearCache(`meals_${clientId}`)
    return data
  } catch (error) {
console.error('❌ Save meal progress failed:', error.message || error)
    throw error
  }
}

async logWaterIntake(clientId, glasses) {
  try {
    const today = new Date().toISOString().split('T')[0]
    
    // Get current water intake
    const { data: current } = await this.supabase
      .from('meal_progress')
      .select('water_glasses')
      .eq('client_id', clientId)
      .eq('date', today)
      .single()
    
    const currentGlasses = current?.water_glasses || 0
    const newTotal = currentGlasses + glasses
    
    const { data, error } = await this.supabase
      .from('meal_progress')
      .upsert({
        client_id: clientId,
        date: today,
        water_glasses: newTotal
      }, {
        onConflict: 'client_id,date'
      })
      .select()
      .single()
    
    if (error) throw error
    return data
  } catch (error) {
    console.error('Log water intake error:', error)
    throw error
  }
}

// ===== STREAK CALCULATION =====
async getClientStreak(clientId) {
  try {
    const { data: completions } = await this.supabase
      .from('workout_completions')
      .select('workout_date')
      .eq('client_id', clientId)
      .eq('completed', true)
      .order('workout_date', { ascending: false })
      .limit(100)
    
    if (!completions || completions.length === 0) return 0
    
    let streak = 0
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    
    const sortedDates = completions
      .map(w => new Date(w.workout_date))
      .sort((a, b) => b - a)
    
    // Check if today or yesterday has a workout
    const todayStr = today.toISOString().split('T')[0]
    const yesterday = new Date(today)
    yesterday.setDate(yesterday.getDate() - 1)
    const yesterdayStr = yesterday.toISOString().split('T')[0]
    
    const firstDateStr = sortedDates[0].toISOString().split('T')[0]
    
    if (firstDateStr === todayStr || firstDateStr === yesterdayStr) {
      streak = 1
      let lastDate = sortedDates[0]
      
      for (let i = 1; i < sortedDates.length; i++) {
        const dayDiff = (lastDate - sortedDates[i]) / (1000 * 60 * 60 * 24)
        
        if (dayDiff <= 1.5) {
          streak++
          lastDate = sortedDates[i]
        } else {
          break
        }
      }
    }
    
    return streak
  } catch (error) {
    console.error('Get client streak error:', error)
    return 0
  }
}

// ===== HELPER: Clear specific cache =====
clearCache(key) {
  // If you implement caching, clear it here
  // For now, just a placeholder
  if (this.cache && this.cache[key]) {
    delete this.cache[key]
  }
}

// ENHANCED GOALS METHODS voor DatabaseService.js
// Voeg deze toe aan je DatabaseService class
// ========================================

// Enhanced saveGoal met alle nieuwe velden
async saveGoal(goalData) {
  try {
    const { data, error } = await this.supabase
      .from('client_goals')
      .insert([{
        client_id: goalData.client_id,
        title: goalData.title,
        goal_type: goalData.goal_type || 'custom',
        category: goalData.category || 'personal',
        measurement_type: goalData.measurement_type || 'number',
        target_value: parseFloat(goalData.target_value) || 0,
        current_value: goalData.current_value || 0,
        target_date: goalData.target_date,
        unit: goalData.unit,
        frequency: goalData.frequency || 'daily',
        frequency_target: goalData.frequency_target || 7,
        notes: goalData.notes,
        status: goalData.status || 'active',
        color: goalData.color || '#10b981',
        icon: goalData.icon || 'target',
        measurement_config: goalData.measurement_config || {},
        is_public: goalData.is_public || false,
        reminder_enabled: goalData.reminder_enabled || false,
        reminder_time: goalData.reminder_time,
        updated_at: new Date().toISOString()
      }])
      .select()
      .single()
    
    if (error) throw error
    
    this.clearCache(`goals_${goalData.client_id}`)
    return data
  } catch (error) {
    console.error('Error saving goal:', error)
    throw error
  }
}

// Update goal progress
async updateGoalProgress(goalId, progressData) {
  try {
    const today = new Date().toISOString().split('T')[0]
    
    // Upsert progress entry
    const { data: progress, error: progressError } = await this.supabase
      .from('goal_progress')
      .upsert({
        goal_id: goalId,
        client_id: progressData.client_id,
        date: progressData.date || today,
        value: progressData.value || null,
        checked: progressData.checked || false,
        photo_urls: progressData.photo_urls || null,
        notes: progressData.notes || '',
        duration_minutes: progressData.duration_minutes || null,
        metadata: progressData.metadata || {}
      }, {
        onConflict: 'goal_id,date'
      })
      .select()
      .single()
    
    if (progressError) throw progressError
    
    // Update current_value in goals table
    if (progressData.value !== undefined) {
      const { error: updateError } = await this.supabase
        .from('client_goals')
        .update({ 
          current_value: progressData.value,
          updated_at: new Date().toISOString()
        })
        .eq('id', goalId)
      
      if (updateError) throw updateError
    }
    
    this.clearCache(`goals_${progressData.client_id}`)
    this.clearCache(`goal_progress_${goalId}`)
    
    return progress
  } catch (error) {
    console.error('Error updating goal progress:', error)
    throw error
  }
}

// Get goal templates
async getGoalTemplates(category = null) {
  try {
    let query = this.supabase
      .from('goal_templates')
      .select('*')
      .eq('is_public', true)
      .order('category', { ascending: true })
    
    if (category) {
      query = query.eq('category', category)
    }
    
    const { data, error } = await query
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('Error fetching goal templates:', error)
    return []
  }
}

// Get goal progress history
async getGoalProgress(goalId, days = 30) {
  try {
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)
    
    const { data, error } = await this.supabase
      .from('goal_progress')
      .select('*')
      .eq('goal_id', goalId)
      .gte('date', startDate.toISOString())
      .order('date', { ascending: false })
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('Error fetching goal progress:', error)
    return []
  }
}

// Get client goals with progress
async getClientGoalsWithProgress(clientId) {
  try {
    // Get goals
    const { data: goals, error: goalsError } = await this.supabase
      .from('client_goals')
      .select('*')
      .eq('client_id', clientId)
      .order('updated_at', { ascending: false })
    
    if (goalsError) throw goalsError
    
    // Get recent progress for each goal
    const goalsWithProgress = await Promise.all(goals.map(async (goal) => {
      const progress = await this.getGoalProgress(goal.id, 7) // Last 7 days
      return {
        ...goal,
        recent_progress: progress
      }
    }))
    
    return goalsWithProgress || []
  } catch (error) {
    console.error('Error fetching goals with progress:', error)
    return []
  }
}

// Delete goal
async deleteGoal(goalId) {
  try {
    const { error } = await this.supabase
      .from('client_goals')
      .delete()
      .eq('id', goalId)
    
    if (error) throw error
    
    this.clearCache('goals')
    return true
  } catch (error) {
    console.error('Error deleting goal:', error)
    throw error
  }
}

// Get goal statistics
async getGoalStatistics(clientId) {
  try {
    const goals = await this.getClientGoalsWithProgress(clientId)
    
    const stats = {
      total: goals.length,
      active: goals.filter(g => g.status === 'active').length,
      completed: goals.filter(g => g.status === 'completed').length,
      average_progress: 0,
      streak_days: 0,
      most_consistent: null
    }
    
    // Calculate average progress
    if (stats.active > 0) {
      const totalProgress = goals
        .filter(g => g.status === 'active')
        .reduce((sum, goal) => {
          const progress = goal.target_value > 0 
            ? (goal.current_value / goal.target_value) * 100 
            : 0
          return sum + Math.min(100, progress)
        }, 0)
      
      stats.average_progress = Math.round(totalProgress / stats.active)
    }
    
    return stats
  } catch (error) {
    console.error('Error calculating goal statistics:', error)
    return {
      total: 0,
      active: 0,
      completed: 0,
      average_progress: 0,
      streak_days: 0,
      most_consistent: null
    }
  }
}

// ========================================
// COMPLETE GOALS METHODS VOOR DatabaseService.js
// Voeg deze methods toe aan je DatabaseService class
// ========================================

// ===== GOAL TEMPLATE METHODS =====

// Get templates by category with caching
async getGoalTemplatesByCategory(category, subcategory = null) {
  const cacheKey = `templates_${category}_${subcategory}`
  const cached = this.getCachedData(cacheKey)
  if (cached) return cached
  
  try {
    let query = this.supabase
      .from('goal_templates')
      .select('*')
      .eq('main_category', category)
      .eq('coach_recommended', true)
      .order('popularity_score', { ascending: false })
    
    if (subcategory) {
      query = query.eq('subcategory', subcategory)
    }
    
    const { data, error } = await query.limit(10)
    
    if (error) throw error
    
    this.setCachedData(cacheKey, data || [])
    return data || []
  } catch (error) {
    console.error('Error fetching goal templates:', error)
    return []
  }
}

// Track template usage for popularity
async trackGoalTemplateUsage(templateId) {
  try {
    // Get current popularity score
    const { data: template } = await this.supabase
      .from('goal_templates')
      .select('popularity_score')
      .eq('id', templateId)
      .single()
    
    if (template) {
      // Increment popularity
      await this.supabase
        .from('goal_templates')
        .update({ 
          popularity_score: (template.popularity_score || 0) + 1 
        })
        .eq('id', templateId)
    }
  } catch (error) {
    console.error('Error tracking template usage:', error)
  }
}

// ===== ENHANCED GOAL METHODS =====

// Save goal with category support
async saveGoal(goalData) {
  try {
    const { data, error } = await this.supabase
      .from('client_goals')
      .insert({
        client_id: goalData.client_id,
        title: goalData.title,
        goal_type: goalData.goal_type || 'custom',
        main_category: goalData.category || goalData.main_category,
        subcategory: goalData.subcategory,
        measurement_type: goalData.measurement_type || 'number',
        target_value: parseFloat(goalData.target_value) || 0,
        current_value: goalData.current_value || 0,
        start_value: goalData.current_value || 0,
        target_date: goalData.target_date,
        unit: goalData.unit || '',
        frequency: goalData.frequency || 'daily',
        frequency_target: goalData.frequency_target || 7,
        notes: goalData.notes || '',
        status: goalData.status || 'active',
        color: goalData.color || '#10b981',
        icon: goalData.icon || 'target',
        measurement_config: goalData.measurement_config || {},
        difficulty_level: goalData.difficulty_level || 'beginner',
        expected_duration_weeks: goalData.expected_duration_weeks || 4,
        is_public: goalData.is_public || false,
        reminder_enabled: goalData.reminder_enabled || false,
        reminder_time: goalData.reminder_time || null,
        updated_at: new Date().toISOString()
      })
      .select()
      .single()
    
    if (error) throw error
    
    this.clearCache(`goals_${goalData.client_id}`)
    console.log('✅ Goal saved successfully:', data)
    return data
  } catch (error) {
    console.error('Error saving goal:', error)
    throw error
  }
}

// Get goals by category
async getGoalsByCategory(clientId, category) {
  try {
    const { data, error } = await this.supabase
      .from('client_goals')
      .select('*')
      .eq('client_id', clientId)
      .eq('main_category', category)
      .eq('status', 'active')
      .order('updated_at', { ascending: false })
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('Error fetching goals by category:', error)
    return []
  }
}

// Get client goals with full journey data
async getClientGoalsWithJourney(clientId) {
  try {
    // Get goals
    const { data: goals } = await this.supabase
      .from('client_goals')
      .select('*')
      .eq('client_id', clientId)
      .order('updated_at', { ascending: false })
    
    if (!goals || goals.length === 0) return []
    
    // Get journey data for each goal
    const goalsWithJourney = await Promise.all(goals.map(async (goal) => {
      // Get milestones
      const { data: milestones } = await this.supabase
        .from('goal_milestones')
        .select('*')
        .eq('goal_id', goal.id)
        .order('order_index')
      
      // Get actions
      const { data: actions } = await this.supabase
        .from('goal_actions')
        .select('*')
        .eq('goal_id', goal.id)
      
      // Get recent progress
      const { data: progress } = await this.supabase
        .from('goal_progress')
        .select('*')
        .eq('goal_id', goal.id)
        .order('date', { ascending: false })
        .limit(7)
      
      return {
        ...goal,
        milestones: milestones || [],
        actions: actions || [],
        recent_progress: progress || []
      }
    }))
    
    return goalsWithJourney
  } catch (error) {
    console.error('Error fetching goals with journey:', error)
    return []
  }
}

// ===== JOURNEY METHODS =====

// Save milestone
async saveGoalMilestone(milestoneData) {
  try {
    const { data, error } = await this.supabase
      .from('goal_milestones')
      .insert({
        goal_id: milestoneData.goal_id,
        title: milestoneData.title,
        target_value: milestoneData.target_value,
        unit: milestoneData.unit,
        target_date: milestoneData.target_date,
        order_index: milestoneData.order_index || 0,
        icon: milestoneData.icon || 'flag',
        percentage: milestoneData.percentage
      })
      .select()
      .single()
    
    if (error) throw error
    
    this.clearCache(`milestones_${milestoneData.goal_id}`)
    return data
  } catch (error) {
    console.error('Error saving milestone:', error)
    throw error
  }
}

// Complete milestone
async completeMilestone(milestoneId) {
  try {
    const { data, error } = await this.supabase
      .from('goal_milestones')
      .update({
        completed: true,
        completed_date: new Date().toISOString().split('T')[0]
      })
      .eq('id', milestoneId)
      .select()
      .single()
    
    if (error) throw error
    
    // Check if this completes the goal
    const { data: milestone } = await this.supabase
      .from('goal_milestones')
      .select('goal_id, percentage')
      .eq('id', milestoneId)
      .single()
    
    if (milestone && milestone.percentage === 100) {
      // Mark goal as completed
      await this.updateGoalStatus(milestone.goal_id, 'completed')
    }
    
    return data
  } catch (error) {
    console.error('Error completing milestone:', error)
    throw error
  }
}

// Save goal action
async saveGoalAction(actionData) {
  try {
    const { data, error } = await this.supabase
      .from('goal_actions')
      .insert({
        goal_id: actionData.goal_id,
        title: actionData.title,
        frequency: actionData.frequency || 'weekly',
        frequency_target: actionData.frequency_target || 3,
        icon: actionData.icon || 'zap'
      })
      .select()
      .single()
    
    if (error) throw error
    
    this.clearCache(`actions_${actionData.goal_id}`)
    return data
  } catch (error) {
    console.error('Error saving action:', error)
    throw error
  }
}

// Track action completion
async trackActionCompletion(actionId, date) {
  try {
    // Log the completion
    const { error: logError } = await this.supabase
      .from('goal_action_logs')
      .upsert({
        action_id: actionId,
        date: date,
        completed: true
      }, {
        onConflict: 'action_id,date'
      })
    
    if (logError) throw logError
    
    // Get current action data
    const { data: action } = await this.supabase
      .from('goal_actions')
      .select('*')
      .eq('id', actionId)
      .single()
    
    if (action) {
      // Calculate new streak
      const lastCompleted = action.last_completed 
        ? new Date(action.last_completed) 
        : new Date(0)
      
      const today = new Date(date)
      const daysDiff = Math.floor((today - lastCompleted) / (1000 * 60 * 60 * 24))
      
      // Reset streak if more than 2 days gap
      const newStreak = daysDiff <= 2 
        ? (action.current_streak || 0) + 1 
        : 1
      
      const bestStreak = Math.max(newStreak, action.best_streak || 0)
      
      // Update action
      await this.supabase
        .from('goal_actions')
        .update({
          current_streak: newStreak,
          best_streak: bestStreak,
          last_completed: date
        })
        .eq('id', actionId)
    }
    
    return true
  } catch (error) {
    console.error('Error tracking action completion:', error)
    throw error
  }
}

// Get action logs for a period
async getActionLogs(actionId, startDate, endDate) {
  try {
    const { data, error } = await this.supabase
      .from('goal_action_logs')
      .select('*')
      .eq('action_id', actionId)
      .gte('date', startDate)
      .lte('date', endDate)
      .order('date', { ascending: false })
    
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('Error fetching action logs:', error)
    return []
  }
}

// ===== ANALYTICS METHODS =====

// Get goal analytics
async getGoalAnalytics(clientId, goalId) {
  try {
    // Get goal data
    const { data: goal } = await this.supabase
      .from('client_goals')
      .select('*')
      .eq('id', goalId)
      .single()
    
    if (!goal) return null
    
    // Get progress history
    const { data: progressHistory } = await this.supabase
      .from('goal_progress')
      .select('*')
      .eq('goal_id', goalId)
      .order('date', { ascending: false })
      .limit(30)
    
    // Get milestones completion rate
    const { data: milestones } = await this.supabase
      .from('goal_milestones')
      .select('*')
      .eq('goal_id', goalId)
    
    const completedMilestones = milestones?.filter(m => m.completed).length || 0
    const totalMilestones = milestones?.length || 0
    
    // Get actions consistency
    const { data: actions } = await this.supabase
      .from('goal_actions')
      .select('*')
      .eq('goal_id', goalId)
    
    const totalStreak = actions?.reduce((sum, a) => sum + (a.current_streak || 0), 0) || 0
    const avgStreak = actions?.length > 0 ? totalStreak / actions.length : 0
    
    // Calculate progress rate
    const startDate = new Date(goal.created_at || Date.now())
    const currentDate = new Date()
    const daysElapsed = Math.floor((currentDate - startDate) / (1000 * 60 * 60 * 24))
    const progressPercentage = goal.target_value > 0 
      ? ((goal.current_value - (goal.start_value || 0)) / (goal.target_value - (goal.start_value || 0))) * 100
      : 0
    
    const dailyProgressRate = daysElapsed > 0 ? progressPercentage / daysElapsed : 0
    
    // Estimate completion
    const remainingProgress = 100 - progressPercentage
    const estimatedDaysToComplete = dailyProgressRate > 0 
      ? Math.ceil(remainingProgress / dailyProgressRate)
      : null
    
    const estimatedCompletionDate = estimatedDaysToComplete
      ? new Date(Date.now() + estimatedDaysToComplete * 24 * 60 * 60 * 1000)
      : null
    
    return {
      goal: goal,
      progressHistory: progressHistory || [],
      milestoneCompletion: totalMilestones > 0 
        ? Math.round((completedMilestones / totalMilestones) * 100)
        : 0,
      averageStreak: Math.round(avgStreak),
      dailyProgressRate: dailyProgressRate.toFixed(2),
      estimatedCompletionDate: estimatedCompletionDate?.toISOString().split('T')[0],
      successProbability: calculateSuccessProbability(
        progressPercentage,
        avgStreak,
        daysElapsed,
        estimatedDaysToComplete
      )
    }
  } catch (error) {
    console.error('Error calculating goal analytics:', error)
    return null
  }
}

// Get category progress
async getCategoryProgress(clientId, category) {
  try {
    const { data: goals } = await this.supabase
      .from('client_goals')
      .select('*')
      .eq('client_id', clientId)
      .eq('main_category', category)
      .eq('status', 'active')
    
    if (!goals || goals.length === 0) {
      return {
        category: category,
        totalGoals: 0,
        averageProgress: 0,
        completedGoals: 0,
        totalXP: 0
      }
    }
    
    const totalProgress = goals.reduce((sum, goal) => {
      const progress = goal.target_value > 0
        ? (goal.current_value / goal.target_value) * 100
        : 0
      return sum + Math.min(100, progress)
    }, 0)
    
    const completedGoals = goals.filter(g => g.status === 'completed').length
    
    // Calculate XP (0.5 per percent progress + 50 bonus per completed goal)
    const totalXP = Math.floor(totalProgress * 0.5) + (completedGoals * 50)
    
    return {
      category: category,
      totalGoals: goals.length,
      averageProgress: Math.round(totalProgress / goals.length),
      completedGoals: completedGoals,
      totalXP: totalXP
    }
  } catch (error) {
    console.error('Error calculating category progress:', error)
    return {
      category: category,
      totalGoals: 0,
      averageProgress: 0,
      completedGoals: 0,
      totalXP: 0
    }
  }
}

// Get all categories progress
async getAllCategoriesProgress(clientId) {
  const categories = ['herstel', 'mindset', 'workout', 'voeding', 'structuur']
  
  try {
    const progressData = await Promise.all(
      categories.map(cat => this.getCategoryProgress(clientId, cat))
    )
    
    return progressData
  } catch (error) {
    console.error('Error fetching all categories progress:', error)
    return categories.map(cat => ({
      category: cat,
      totalGoals: 0,
      averageProgress: 0,
      completedGoals: 0,
      totalXP: 0
    }))
  }

}



async updateGoalProgress(goalId, progressData) {
  try {
    // Update current_value in client_goals
    const { data: goalUpdate, error: goalError } = await this.supabase
      .from('client_goals')
      .update({
        current_value: progressData.value,
        updated_at: new Date().toISOString()
      })
      .eq('id', goalId)
      .select()
      .single()
    
    if (goalError) throw goalError
    
    // Log progress in goal_progress table
    const { data: progressLog, error: progressError } = await this.supabase
      .from('goal_progress')
      .insert({
        goal_id: goalId,
        client_id: progressData.client_id,
        date: progressData.date || new Date().toISOString().split('T')[0],
        value: progressData.value,
        notes: progressData.notes || '',
        checked: false
      })
      .select()
      .single()
    
    if (progressError) throw progressError
    
    this.clearCache(`goals_${progressData.client_id}`)
    console.log('✅ Goal progress updated')
    return { goal: goalUpdate, progress: progressLog }
  } catch (error) {
    console.error('Update goal progress error:', error)
    throw error
  }
}

// Save week progress voor checkbox goals
async saveWeekProgress(goalId, clientId, checkedDays) {
  try {
    const weekDates = this.getWeekDates(new Date())
    const updates = []
    
    // Create upsert data for each day of the week
    for (let i = 0; i < 7; i++) {
      const date = weekDates[i]
      const isChecked = checkedDays.includes(i)
      
      updates.push({
        goal_id: goalId,
        client_id: clientId,
        date: date,
        checked: isChecked,
        value: isChecked ? 1 : 0,
        notes: `Week progress: Day ${i + 1}`
      })
    }
    
    // Upsert all days at once
    const { data, error } = await this.supabase
      .from('goal_progress')
      .upsert(updates, {
        onConflict: 'goal_id,date'
      })
    
    if (error) throw error
    
    // Update current_value in client_goals
    const { error: updateError } = await this.supabase
      .from('client_goals')
      .update({
        current_value: checkedDays.length,
        updated_at: new Date().toISOString()
      })
      .eq('id', goalId)
    
    if (updateError) throw updateError
    
    this.clearCache(`goals_${clientId}`)
    console.log('✅ Week progress saved:', checkedDays.length, 'days completed')
    return data
  } catch (error) {
    console.error('Save week progress error:', error)
    throw error
  }
}

// Get week progress voor checkbox goals
async getWeekProgress(goalId, weekStart = null) {
  try {
    const weekDates = this.getWeekDates(weekStart || new Date())
    const startDate = weekDates[0]
    const endDate = weekDates[6]
    
    const { data, error } = await this.supabase
      .from('goal_progress')
      .select('*')
      .eq('goal_id', goalId)
      .gte('date', startDate)
      .lte('date', endDate)
      .order('date', { ascending: true })
    
    if (error) throw error
    
    // Convert to array of checked day indices
    const checkedDays = []
    data?.forEach(entry => {
      if (entry.checked) {
        const date = new Date(entry.date)
        const dayIndex = date.getDay() === 0 ? 6 : date.getDay() - 1 // Mon=0, Sun=6
        checkedDays.push(dayIndex)
      }
    })
    
    return checkedDays
  } catch (error) {
    console.error('Get week progress error:', error)
    return []
  }
}

// Load all weekly progress voor multiple checkbox goals
async loadWeeklyProgress(clientId) {
  try {
    // Get all active checkbox goals
    const { data: goals, error: goalsError } = await this.supabase
      .from('client_goals')
      .select('id')
      .eq('client_id', clientId)
      .eq('measurement_type', 'checkbox')
      .eq('status', 'active')
    
    if (goalsError) throw goalsError
    
    const progress = {}
    
    // Load week progress for each goal
    for (const goal of goals || []) {
      const weekData = await this.getWeekProgress(goal.id)
      progress[goal.id] = weekData
    }
    
    return progress
  } catch (error) {
    console.error('Load weekly progress error:', error)
    return {}
  }
}

// Complete goal method (als deze nog niet bestaat)
async completeGoal(goalId) {
  try {
    const { data, error } = await this.supabase
      .from('client_goals')
      .update({
        status: 'completed',
        completed_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .eq('id', goalId)
      .select()
      .single()
    
    if (error) throw error
    
    // Track XP earning
    if (data) {
      // Award 50 XP for completing a goal
      const xp = 50
      console.log(`🎉 Goal completed! +${xp} XP earned`)
      
      // You could also track this in a separate XP table if needed
    }
    
    this.clearCache('goals')
    return data
  } catch (error) {
    console.error('Complete goal error:', error)
    throw error
  }
}

// Delete goal method (als deze nog niet bestaat)
async deleteGoal(goalId) {
  try {
    // First delete all related data
    await this.supabase.from('goal_progress').delete().eq('goal_id', goalId)
    await this.supabase.from('goal_milestones').delete().eq('goal_id', goalId)
    await this.supabase.from('goal_actions').delete().eq('goal_id', goalId)
    
    // Then delete the goal itself
    const { error } = await this.supabase
      .from('client_goals')
      .delete()
      .eq('id', goalId)
    
    if (error) throw error
    
    this.clearCache('goals')
    console.log('✅ Goal deleted')
    return true
  } catch (error) {
    console.error('Delete goal error:', error)
    throw error
  }}






 async getRandomQuote(language = 'nl') {
    try {
      const { data, error } = await this.supabase
        .from('quotes')
        .select('*')
        .eq('is_active', true)
        .eq('language', language)
      
      if (error) throw error
      
      if (data && data.length > 0) {
        const randomIndex = Math.floor(Math.random() * data.length)
        return data[randomIndex]
      }
      
      return null
    } catch (error) {
      console.error('Error getting quote:', error)
      return null
    }
  }

  async getQuoteOfTheDay() {
    try {
      const today = new Date().toISOString().split('T')[0]
      
      // First check if there's a specific quote for today
      const { data: specificQuote } = await this.supabase
        .from('quotes')
        .select('*')
        .eq('display_date', today)
        .eq('is_active', true)
        .single()
      
      if (specificQuote) return specificQuote
      
      // Otherwise get a random quote
      return await this.getRandomQuote()
    } catch (error) {
      console.error('Error getting quote of the day:', error)
      return null
    }
  }

  // ===== WELCOME MESSAGES =====
  async getWelcomeMessage() {
    try {
      const hour = new Date().getHours()
      let timeOfDay = 'morning'
      
      if (hour >= 12 && hour < 18) timeOfDay = 'afternoon'
      else if (hour >= 18) timeOfDay = 'evening'
      
      const { data, error } = await this.supabase
        .from('daily_welcomes')
        .select('*')
        .eq('is_active', true)
        .eq('time_of_day', timeOfDay)
      
      if (error) throw error
      
      if (data && data.length > 0) {
        const randomIndex = Math.floor(Math.random() * data.length)
        return data[randomIndex]
      }
      
      return {
        welcome_text: 'Klaar om je doelen te verpletteren?',
        subtitle: 'Laten we er een geweldige dag van maken!'
      }
    } catch (error) {
      console.error('Error getting welcome message:', error)
      return {
        welcome_text: 'Welkom terug!',
        subtitle: 'Tijd om aan je doelen te werken.'
      }
    }
  }

  // ===== SCHEDULED CALLS =====
  async getNextScheduledCall(clientId) {
    try {
      const today = new Date().toISOString().split('T')[0]
      
      const { data, error } = await this.supabase
        .from('scheduled_calls')
        .select('*')
        .eq('client_id', clientId)
        .eq('status', 'scheduled')
        .gte('call_date', today)
        .order('call_date', { ascending: true })
        .order('call_time', { ascending: true })
        .limit(1)
        .single()
      
      if (error && error.code !== 'PGRST116') throw error // PGRST116 = no rows returned
      
      return data
    } catch (error) {
      console.error('Error getting next call:', error)
      return null
    }
  }

  async getRecentCalls(clientId, limit = 5) {
    try {
      const { data, error } = await this.supabase
        .from('scheduled_calls')
        .select('*')
        .eq('client_id', clientId)
        .eq('status', 'completed')
        .order('call_date', { ascending: false })
        .limit(limit)
      
      if (error) throw error
      
      return data || []
    } catch (error) {
      console.error('Error getting recent calls:', error)
      return []
    }
  }

  async scheduleCall(callData) {
    try {
      const { data, error } = await this.supabase
        .from('scheduled_calls')
        .insert([{
          ...callData,
          status: 'scheduled',
          reminder_sent: false
        }])
        .select()
        .single()
      
      if (error) throw error
      
      return data
    } catch (error) {
      console.error('Error scheduling call:', error)
      throw error
    }
  }

  async updateCallStatus(callId, status) {
    try {
      const { data, error } = await this.supabase
        .from('scheduled_calls')
        .update({ 
          status,
          updated_at: new Date().toISOString()
        })
        .eq('id', callId)
        .select()
        .single()
      
      if (error) throw error
      
      return data
    } catch (error) {
      console.error('Error updating call status:', error)
      throw error
    }
  }

  // ===== COACH VIDEOS =====
  async getCoachVideos(coachId, category = null) {
    try {
      let query = this.supabase
        .from('coach_videos')
        .select('*')
        .eq('is_active', true)
        .or(`coach_id.eq.${coachId},is_featured.eq.true`)
        .order('order_index', { ascending: true })
      
      if (category && category !== 'all') {
        query = query.eq('category', category)
      }
      
      const { data, error } = await query.limit(20)
      
      if (error) throw error
      
      return data || []
    } catch (error) {
      console.error('Error getting coach videos:', error)
      return []
    }
  }

  async getFeaturedVideos(limit = 5) {
    try {
      const { data, error } = await this.supabase
        .from('coach_videos')
        .select('*')
        .eq('is_active', true)
        .eq('is_featured', true)
        .order('order_index', { ascending: true })
        .limit(limit)
      
      if (error) throw error
      
      return data || []
    } catch (error) {
      console.error('Error getting featured videos:', error)
      return []
    }
  }

  async incrementVideoView(videoId) {
    try {
      // First get current view count
      const { data: video } = await this.supabase
        .from('coach_videos')
        .select('view_count')
        .eq('id', videoId)
        .single()
      
      if (video) {
        const { error } = await this.supabase
          .from('coach_videos')
          .update({ 
            view_count: (video.view_count || 0) + 1,
            updated_at: new Date().toISOString()
          })
          .eq('id', videoId)
        
        if (error) throw error
      }
    } catch (error) {
      console.error('Error incrementing video view:', error)
    }
  }

  // ===== COACH MESSAGES / NOTIFICATIONS =====
  async getUnreadCoachMessages(clientId) {
    try {
      const { data, error } = await this.supabase
        .from('coach_notifications')
        .select('*')
        .eq('client_id', clientId)
        .eq('status', 'unread')
        .order('created_at', { ascending: false })
        .limit(10)
      
      if (error) throw error
      
      return data || []
    } catch (error) {
      console.error('Error getting coach messages:', error)
      return []
    }
  }

  async markMessageAsRead(messageId) {
    try {
      const { error } = await this.supabase
        .from('coach_notifications')
        .update({ 
          status: 'read',
          read_at: new Date().toISOString()
        })
        .eq('id', messageId)
      
      if (error) throw error
      
      return true
    } catch (error) {
      console.error('Error marking message as read:', error)
      return false
    }
  }

  async sendCoachMessage(clientId, message) {
    try {
      const { data, error } = await this.supabase
        .from('coach_notifications')
        .insert([{
          client_id: clientId,
          type: message.type || 'message',
          priority: message.priority || 'normal',
          title: message.title || 'Coach Bericht',
          message: message.text,
          action_type: message.action?.type,
          action_target: message.action?.target,
          action_label: message.action?.label,
          status: 'unread'
        }])
        .select()
        .single()
      
      if (error) throw error
      
      return data
    } catch (error) {
      console.error('Error sending coach message:', error)
      throw error
    }
  }

  // ===== QUICK ACTIONS DATA =====
  async getTodaysWorkout(clientId) {
    try {
      const dayNames = ['Zondag', 'Maandag', 'Dinsdag', 'Woensdag', 'Donderdag', 'Vrijdag', 'Zaterdag']
      const today = dayNames[new Date().getDay()]
      
      const { data, error } = await this.supabase
        .from('client_workouts')
        .select('*, workout_templates(*)')
        .eq('client_id', clientId)
        .eq('is_active', true)
        .single()
      
      if (error && error.code !== 'PGRST116') throw error
      
      if (data?.workout_templates?.exercises) {
        const todaysExercises = data.workout_templates.exercises.find(ex => 
          ex.day?.toLowerCase() === today.toLowerCase()
        )
        return todaysExercises
      }
      
      return null
    } catch (error) {
      console.error('Error getting today workout:', error)
      return null
    }
  }

  async getNextGoalDeadline(clientId) {
    try {
      const { data, error } = await this.supabase
        .from('client_goals')
        .select('*')
        .eq('client_id', clientId)
        .eq('status', 'active')
        .gte('target_date', new Date().toISOString())
        .order('target_date', { ascending: true })
        .limit(1)
        .single()
      
      if (error && error.code !== 'PGRST116') throw error
      
      return data
    } catch (error) {
      console.error('Error getting next goal:', error)
      return null
    }
  }

  async getWeeklyProgress(clientId) {
    try {
      const weekAgo = new Date()
      weekAgo.setDate(weekAgo.getDate() - 7)
      
      const [workouts, meals, goals] = await Promise.all([
        this.getWeeklyWorkoutCount(clientId),
        this.getWeeklyMealAdherence(clientId),
        this.getGoalProgress(clientId)
      ])
      
      return {
        workouts,
        meals,
        goals,
        streak: await this.getClientStreak(clientId)
      }
    } catch (error) {
      console.error('Error getting weekly progress:', error)
      return {
        workouts: 0,
        meals: 0,
        goals: 0,
        streak: 0
      }
    }
  }

  async getWeeklyMealAdherence(clientId) {
    try {
      const weekAgo = new Date()
      weekAgo.setDate(weekAgo.getDate() - 7)
      
      const { data, error } = await this.supabase
        .from('meal_logs')
        .select('adherence_percentage')
        .eq('client_id', clientId)
        .gte('date', weekAgo.toISOString())
      
      if (error) throw error
      
      if (data && data.length > 0) {
        const totalAdherence = data.reduce((sum, log) => sum + (log.adherence_percentage || 0), 0)
        return Math.round(totalAdherence / data.length)
      }
      
      return 0
    } catch (error) {
      console.error('Error getting meal adherence:', error)
      return 0
    }
  }

  async getGoalProgress(clientId) {
    try {
      const goals = await this.getClientGoals(clientId)
      const activeGoals = goals.filter(g => g.status === 'active')
      
      if (activeGoals.length === 0) return 0
      
      const totalProgress = activeGoals.reduce((sum, goal) => {
        const progress = (goal.current_value / goal.target_value) * 100
        return sum + Math.min(100, progress)
      }, 0)
      
      return Math.round(totalProgress / activeGoals.length)
    } catch (error) {
      console.error('Error getting goal progress:', error)
      return 0
    }
  }



// ============================================
// CHALLENGES SERVICE - Database Integration
// Add these methods to DatabaseService.js
// ============================================

// Add to existing DatabaseService class:

// ==================== CHALLENGES SYSTEM ====================

// Get all available challenges
async getChallenges(category = null) {
  try {
    let query = this.supabase
      .from('challenges')
      .select('*')
      .eq('is_active', true)
      .order('category', { ascending: true })
      .order('difficulty', { ascending: true });
    
    if (category) {
      query = query.eq('category', category);
    }
    
    const { data, error } = await query;
    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error fetching challenges:', error);
    return [];
  }
}

// Get single challenge details
async getChallenge(challengeId) {
  try {
    const { data, error } = await this.supabase
      .from('challenges')
      .select('*')
      .eq('id', challengeId)
      .single();
    
    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error fetching challenge:', error);
    return null;
  }
}

// Get client's active challenges
async getClientActiveChallenges(clientId) {
  try {
    const { data, error } = await this.supabase
      .from('client_challenges')
      .select(`
        *,
        challenge:challenges(*)
      `)
      .eq('client_id', clientId)
      .in('status', ['active', 'paused'])
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    
    // Merge challenge data into main object
    return data.map(item => ({
      ...item,
      ...item.challenge,
      client_challenge_id: item.id,
      progress_percentage: item.progress_percentage,
      current_streak: item.current_streak,
      is_money_back_challenge: item.is_money_back_challenge,
      money_back_number: item.money_back_number
    }));
  } catch (error) {
    console.error('Error fetching client challenges:', error);
    return [];
  }
}

// Start a new challenge for client
async startClientChallenge(challengeData) {
  try {
    const challenge = await this.getChallenge(challengeData.challenge_id);
    if (!challenge) throw new Error('Challenge not found');
    
    const endDate = new Date();
    endDate.setDate(endDate.getDate() + challenge.duration_days);
    
    const { data, error } = await this.supabase
      .from('client_challenges')
      .insert({
        client_id: challengeData.client_id,
        challenge_id: challengeData.challenge_id,
        status: 'active',
        is_money_back_challenge: challengeData.is_money_back_challenge || false,
        money_back_number: challengeData.money_back_number || null,
        target_end_date: endDate.toISOString().split('T')[0],
        motivation_reason: challengeData.motivation || null
      })
      .select()
      .single();
    
    if (error) throw error;
    
    // Create initial milestones
    if (challenge.milestones && challenge.milestones.length > 0) {
      await this.createChallengeMilestones(data.id, challenge.milestones);
    }
    
    // Send notification
    await this.sendNotification(
      challengeData.client_id,
      'challenge_started',
      `🎯 Challenge "${challenge.name}" gestart! Je hebt ${challenge.duration_days} dagen om deze te voltooien!`
    );
    
    return data;
  } catch (error) {
    console.error('Error starting challenge:', error);
    throw error;
  }
}

// Update challenge progress
async updateChallengeProgress(clientChallengeId, progressData) {
  try {
    const updates = {
      progress_percentage: progressData.progress,
      current_streak: progressData.streak || 0,
      updated_at: new Date().toISOString()
    };
    
    if (progressData.milestone_completed) {
      updates.completed_milestones = progressData.completed_milestones;
      updates.current_milestone_index = progressData.current_milestone_index;
    }
    
    if (progressData.progress >= 100) {
      updates.status = 'completed';
      updates.actual_end_date = new Date().toISOString().split('T')[0];
    }
    
    const { data, error } = await this.supabase
      .from('client_challenges')
      .update(updates)
      .eq('id', clientChallengeId)
      .select()
      .single();
    
    if (error) throw error;
    
    // Award points if completed
    if (data.status === 'completed') {
      await this.awardChallengeCompletion(data);
    }
    
    return data;
  } catch (error) {
    console.error('Error updating challenge progress:', error);
    throw error;
  }
}

// Log daily challenge activity
async logChallengeDaily(clientChallengeId, logData) {
  try {
    const today = new Date().toISOString().split('T')[0];
    
    const { data, error } = await this.supabase
      .from('challenge_daily_logs')
      .upsert({
        client_challenge_id: clientChallengeId,
        log_date: today,
        completed: logData.completed || false,
        workout_completed: logData.workout_completed || null,
        meal_plan_followed: logData.meal_followed || null,
        water_intake: logData.water || null,
        custom_metrics: logData.custom || {},
        notes: logData.notes || null,
        photo_url: logData.photo || null,
        points_earned: logData.completed ? 10 : 0
      }, {
        onConflict: 'client_challenge_id,log_date'
      })
      .select()
      .single();
    
    if (error) throw error;
    
    // Update streak
    if (logData.completed) {
      await this.updateChallengeStreak(clientChallengeId);
    }
    
    return data;
  } catch (error) {
    console.error('Error logging daily challenge:', error);
    throw error;
  }
}

// Update challenge streak
async updateChallengeStreak(clientChallengeId) {
  try {
    // Get last 7 days of logs
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - 6);
    
    const { data: logs, error: logError } = await this.supabase
      .from('challenge_daily_logs')
      .select('log_date, completed')
      .eq('client_challenge_id', clientChallengeId)
      .gte('log_date', startDate.toISOString().split('T')[0])
      .lte('log_date', endDate.toISOString().split('T')[0])
      .order('log_date', { ascending: false });
    
    if (logError) throw logError;
    
    // Calculate current streak
    let streak = 0;
    for (const log of logs) {
      if (log.completed) {
        streak++;
      } else {
        break;
      }
    }
    
    // Update client challenge
    const { data, error } = await this.supabase
      .from('client_challenges')
      .update({
        current_streak: streak,
        longest_streak: this.supabase.sql`GREATEST(longest_streak, ${streak})`
      })
      .eq('id', clientChallengeId)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error updating streak:', error);
    throw error;
  }
}

// Get challenge leaderboard
async getChallengeLeaderboard(challengeId, limit = 10) {
  try {
    const { data, error } = await this.supabase
      .from('challenge_leaderboard')
      .select(`
        *,
        client:clients(first_name, last_name, avatar_url)
      `)
      .eq('challenge_id', challengeId)
      .order('rank', { ascending: true })
      .limit(limit);
    
    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error fetching leaderboard:', error);
    return [];
  }
}

// Award challenge completion
async awardChallengeCompletion(challengeData) {
  try {
    const challenge = await this.getChallenge(challengeData.challenge_id);
    
    // Calculate total points
    const totalPoints = challenge.base_points + 
                       challenge.completion_bonus + 
                       (challengeData.current_streak * 10);
    
    // Create reward record
    const { data: reward, error: rewardError } = await this.supabase
      .from('challenge_rewards')
      .insert({
        client_id: challengeData.client_id,
        challenge_id: challengeData.challenge_id,
        reward_type: 'completion',
        reward_value: {
          points: totalPoints,
          badge: challenge.name,
          completion_date: new Date().toISOString()
        },
        badge_name: `${challenge.name} Champion`,
        badge_icon: '🏆',
        badge_color: '#fbbf24'
      })
      .select()
      .single();
    
    if (rewardError) throw rewardError;
    
    // Check money back eligibility
    if (challengeData.is_money_back_challenge) {
      await this.checkMoneyBackEligibility(challengeData.client_id);
    }
    
    // Send completion notification
    await this.sendNotification(
      challengeData.client_id,
      'challenge_completed',
      `🎉 GEFELICITEERD! Je hebt "${challenge.name}" voltooid en ${totalPoints} punten verdiend!`
    );
    
    return reward;
  } catch (error) {
    console.error('Error awarding completion:', error);
    throw error;
  }
}

// Check if client completed 3 money back challenges
async checkMoneyBackEligibility(clientId) {
  try {
    const { data, error } = await this.supabase
      .from('client_challenges')
      .select('id, money_back_number')
      .eq('client_id', clientId)
      .eq('is_money_back_challenge', true)
      .eq('status', 'completed');
    
    if (error) throw error;
    
    if (data.length >= 3) {
      // Client is eligible for money back!
      await this.sendNotification(
        clientId,
        'money_back_earned',
        '💰 GEFELICITEERD! Je hebt 3 challenges voltooid en komt in aanmerking voor 100% GELD TERUG!'
      );
      
      // Create money back reward
      await this.supabase
        .from('challenge_rewards')
        .insert({
          client_id: clientId,
          challenge_id: null,
          reward_type: 'money_back',
          reward_value: {
            status: 'eligible',
            completed_challenges: data.map(c => c.money_back_number),
            date: new Date().toISOString()
          },
          badge_name: '💰 Money Back Champion',
          badge_icon: '💰',
          badge_color: '#fbbf24'
        });
    }
    
    return data.length >= 3;
  } catch (error) {
    console.error('Error checking money back:', error);
    return false;
  }
}

// Pause a challenge
async pauseChallenge(clientChallengeId) {
  try {
    const { data, error } = await this.supabase
      .from('client_challenges')
      .update({
        status: 'paused',
        paused_date: new Date().toISOString().split('T')[0]
      })
      .eq('id', clientChallengeId)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error pausing challenge:', error);
    throw error;
  }
}

// Resume a challenge
async resumeChallenge(clientChallengeId) {
  try {
    const { data, error } = await this.supabase
      .from('client_challenges')
      .update({
        status: 'active',
        paused_date: null
      })
      .eq('id', clientChallengeId)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error resuming challenge:', error);
    throw error;
  }
}

// Create milestones for a challenge
async createChallengeMilestones(clientChallengeId, milestones) {
  try {
    const milestoneRecords = milestones.map((milestone, index) => ({
      client_challenge_id: clientChallengeId,
      milestone_index: index,
      title: milestone.title,
      description: milestone.description,
      target_value: milestone.target_value || null,
      unit: milestone.unit || null,
      points_value: milestone.points || 50
    }));
    
    const { error } = await this.supabase
      .from('challenge_milestones')
      .insert(milestoneRecords);
    
    if (error) throw error;
    return true;
  } catch (error) {
    console.error('Error creating milestones:', error);
    return false;
  }
}


// ============================================
// CHALLENGE SERVICE - Database Integration
// Add these methods to DatabaseService.js
// ============================================

// ==================== CHALLENGES SYSTEM ====================

// Get all available challenges
async getChallenges(category = null) {
  try {
    let query = this.supabase
      .from('challenges')
      .select('*')
      .eq('is_active', true)
      .order('category')
      .order('difficulty');
    
    if (category && category !== 'all') {
      query = query.eq('category', category);
    }
    
    const { data, error } = await query;
    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Error fetching challenges:', error);
    return [];
  }
}

// Get client's active challenges with progress
async getClientActiveChallenges(clientId) {
  try {
    const { data, error } = await this.supabase
      .from('client_challenges')
      .select(`
        *,
        challenge:challenges(*)
      `)
      .eq('client_id', clientId)
      .in('status', ['active', 'paused'])
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    
    // Calculate real-time progress for each challenge
    const challengesWithProgress = await Promise.all(
      (data || []).map(async (item) => {
        const progress = await this.calculateChallengeProgress(item.id);
        return {
          ...item.challenge,
          ...item,
          progress: progress.percentage,
          streak: progress.streak,
          daysLeft: progress.daysLeft
        };
      })
    );
    
    return challengesWithProgress;
  } catch (error) {
    console.error('Error fetching client challenges:', error);
    return [];
  }
}

// Calculate challenge progress
async calculateChallengeProgress(clientChallengeId) {
  try {
    // Get challenge details
    const { data: challenge } = await this.supabase
      .from('client_challenges')
      .select('*, challenge:challenges(*)')
      .eq('id', clientChallengeId)
      .single();
    
    if (!challenge) return { percentage: 0, streak: 0, daysLeft: 0 };
    
    // Get progress logs
    const { data: logs } = await this.supabase
      .from('challenge_progress_logs')
      .select('*')
      .eq('client_challenge_id', clientChallengeId)
      .order('log_date', { ascending: false });
    
    // Calculate days left
    const endDate = new Date(challenge.target_end_date);
    const today = new Date();
    const daysLeft = Math.max(0, Math.ceil((endDate - today) / (1000 * 60 * 60 * 24)));
    
    // Calculate streak
    let streak = 0;
    const todayStr = today.toISOString().split('T')[0];
    const sortedLogs = (logs || []).sort((a, b) => 
      new Date(b.log_date) - new Date(a.log_date)
    );
    
    for (let i = 0; i < sortedLogs.length; i++) {
      const logDate = new Date(sortedLogs[i].log_date);
      const expectedDate = new Date(today);
      expectedDate.setDate(expectedDate.getDate() - i);
      
      if (logDate.toDateString() === expectedDate.toDateString()) {
        streak++;
      } else {
        break;
      }
    }
    
    // Calculate percentage
    const totalDays = challenge.challenge.duration_days;
    const completedDays = logs ? logs.length : 0;
    const percentage = Math.min(100, Math.round((completedDays / totalDays) * 100));
    
    return {
      percentage,
      streak,
      daysLeft,
      totalLogs: completedDays
    };
  } catch (error) {
    console.error('Error calculating progress:', error);
    return { percentage: 0, streak: 0, daysLeft: 0 };
  }
}

// Start a new challenge
async startClientChallenge(clientId, challengeId, isMoneyBack = false) {
  try {
    // Get challenge details
    const { data: challenge } = await this.supabase
      .from('challenges')
      .select('*')
      .eq('id', challengeId)
      .single();
    
    if (!challenge) throw new Error('Challenge niet gevonden');
    
    // Check if already active
    const { data: existing } = await this.supabase
      .from('client_challenges')
      .select('id')
      .eq('client_id', clientId)
      .eq('challenge_id', challengeId)
      .eq('status', 'active')
      .single();
    
    if (existing) throw new Error('Challenge is al actief');
    
    // Calculate end date
    const startDate = new Date();
    const endDate = new Date();
    endDate.setDate(endDate.getDate() + challenge.duration_days);
    
    // Determine money back number
    let moneyBackNumber = null;
    if (isMoneyBack) {
      const { data: moneyBackChallenges } = await this.supabase
        .from('client_challenges')
        .select('money_back_number')
        .eq('client_id', clientId)
        .eq('is_money_back_challenge', true)
        .order('money_back_number', { ascending: false })
        .limit(1);
      
      moneyBackNumber = moneyBackChallenges && moneyBackChallenges[0]
        ? moneyBackChallenges[0].money_back_number + 1
        : 1;
      
      if (moneyBackNumber > 3) {
        throw new Error('Maximum 3 money back challenges bereikt');
      }
    }
    
    // Create client challenge
    const { data: newChallenge, error } = await this.supabase
      .from('client_challenges')
      .insert({
        client_id: clientId,
        challenge_id: challengeId,
        status: 'active',
        is_money_back_challenge: isMoneyBack,
        money_back_number: moneyBackNumber,
        start_date: startDate.toISOString().split('T')[0],
        target_end_date: endDate.toISOString().split('T')[0]
      })
      .select()
      .single();
    
    if (error) throw error;
    
    // Create milestones if defined
    if (challenge.milestones && challenge.milestones.length > 0) {
      const milestones = challenge.milestones.map((m, index) => ({
        client_challenge_id: newChallenge.id,
        milestone_index: index,
        title: m.title,
        description: m.description,
        target_value: m.target_value,
        status: 'pending'
      }));
      
      await this.supabase
        .from('challenge_milestones')
        .insert(milestones);
    }
    
    // Update challenge stats
    await this.supabase
      .from('challenges')
      .update({ total_enrolled: challenge.total_enrolled + 1 })
      .eq('id', challengeId);
    
    return newChallenge;
  } catch (error) {
    console.error('Error starting challenge:', error);
    throw error;
  }
}

// Log daily progress
async logChallengeProgress(clientChallengeId, progressData) {
  try {
    const today = new Date().toISOString().split('T')[0];
    
    // Check if already logged today
    const { data: existing } = await this.supabase
      .from('challenge_progress_logs')
      .select('id')
      .eq('client_challenge_id', clientChallengeId)
      .eq('log_date', today)
      .eq('progress_type', progressData.type || 'daily')
      .single();
    
    if (existing) {
      // Update existing log
      const { data, error } = await this.supabase
        .from('challenge_progress_logs')
        .update({
          progress_value: progressData.value,
          progress_data: progressData.data,
          verified: progressData.verified || false,
          verification_url: progressData.verificationUrl,
          updated_at: new Date().toISOString()
        })
        .eq('id', existing.id)
        .select()
        .single();
      
      if (error) throw error;
      await this.updateChallengeProgress(clientChallengeId);
      return data;
    } else {
      // Create new log
      const { data, error } = await this.supabase
        .from('challenge_progress_logs')
        .insert({
          client_challenge_id: clientChallengeId,
          log_date: today,
          progress_type: progressData.type || 'daily',
          progress_value: progressData.value,
          progress_data: progressData.data,
          verified: progressData.verified || false,
          verification_url: progressData.verificationUrl,
          points_earned: progressData.points || 10
        })
        .select()
        .single();
      
      if (error) throw error;
      await this.updateChallengeProgress(clientChallengeId);
      return data;
    }
  } catch (error) {
    console.error('Error logging progress:', error);
    throw error;
  }
}

// Update challenge progress percentage and streak
async updateChallengeProgress(clientChallengeId) {
  try {
    const progress = await this.calculateChallengeProgress(clientChallengeId);
    
    // Update challenge record
    const { error } = await this.supabase
      .from('client_challenges')
      .update({
        progress_percentage: progress.percentage,
        current_streak: progress.streak,
        total_active_days: progress.totalLogs,
        updated_at: new Date().toISOString()
      })
      .eq('id', clientChallengeId);
    
    if (error) throw error;
    
    // Check if completed
    if (progress.percentage >= 100) {
      await this.completeChallenge(clientChallengeId);
    }
    
    // Check milestones
    await this.checkMilestones(clientChallengeId, progress.percentage);
    
    return progress;
  } catch (error) {
    console.error('Error updating progress:', error);
    throw error;
  }
}

// Complete a challenge
async completeChallenge(clientChallengeId) {
  try {
    // Update status
    const { data: challenge, error } = await this.supabase
      .from('client_challenges')
      .update({
        status: 'completed',
        actual_end_date: new Date().toISOString().split('T')[0],
        progress_percentage: 100
      })
      .eq('id', clientChallengeId)
      .select('*, challenge:challenges(*)')
      .single();
    
    if (error) throw error;
    
    // Award completion reward
    await this.supabase
      .from('challenge_rewards')
      .insert({
        client_id: challenge.client_id,
        challenge_id: challenge.challenge_id,
        reward_type: 'completion',
        reward_value: {
          points: challenge.challenge.completion_bonus,
          badge: 'Champion'
        },
        badge_name: `${challenge.challenge.name} Champion`,
        badge_color: '#10b981'
      });
    
    // Check money back eligibility
    if (challenge.is_money_back_challenge) {
      await this.checkMoneyBackEligibility(challenge.client_id);
    }
    
    // Update challenge stats
    await this.supabase
      .from('challenges')
      .update({ 
        total_completed: challenge.challenge.total_completed + 1,
        success_rate: Math.round(
          ((challenge.challenge.total_completed + 1) / challenge.challenge.total_enrolled) * 100
        )
      })
      .eq('id', challenge.challenge_id);
    
    return challenge;
  } catch (error) {
    console.error('Error completing challenge:', error);
    throw error;
  }
}

// Check money back eligibility
async checkMoneyBackEligibility(clientId) {
  try {
    const { data: completed } = await this.supabase
      .from('client_challenges')
      .select('id, money_back_number')
      .eq('client_id', clientId)
      .eq('is_money_back_challenge', true)
      .eq('status', 'completed')
      .order('money_back_number');
    
    if (completed && completed.length >= 3) {
      // Check if all 3 are within 90 days
      const firstStart = await this.supabase
        .from('client_challenges')
        .select('start_date')
        .eq('client_id', clientId)
        .eq('money_back_number', 1)
        .single();
      
      const lastComplete = await this.supabase
        .from('client_challenges')
        .select('actual_end_date')
        .eq('client_id', clientId)
        .eq('money_back_number', 3)
        .single();
      
      if (firstStart && lastComplete) {
        const start = new Date(firstStart.data.start_date);
        const end = new Date(lastComplete.data.actual_end_date);
        const daysDiff = Math.ceil((end - start) / (1000 * 60 * 60 * 24));
        
        if (daysDiff <= 90) {
          // Eligible for money back!
          await this.supabase
            .from('challenge_rewards')
            .insert({
              client_id: clientId,
              reward_type: 'money_back',
              reward_value: {
                status: 'eligible',
                completed_date: new Date().toISOString(),
                challenges_completed: completed.map(c => c.id)
              }
            });
          
          return true;
        }
      }
    }
    
    return false;
  } catch (error) {
    console.error('Error checking money back:', error);
    return false;
  }
}

// Check and update milestones
async checkMilestones(clientChallengeId, currentProgress) {
  try {
    const { data: milestones } = await this.supabase
      .from('challenge_milestones')
      .select('*')
      .eq('client_challenge_id', clientChallengeId)
      .eq('status', 'pending')
      .order('milestone_index');
    
    if (!milestones || milestones.length === 0) return;
    
    // Simple progress-based milestone check
    const milestonesPerQuarter = 100 / 4;
    
    for (const milestone of milestones) {
      const targetProgress = (milestone.milestone_index + 1) * milestonesPerQuarter;
      
      if (currentProgress >= targetProgress) {
        await this.supabase
          .from('challenge_milestones')
          .update({
            status: 'completed',
            completed_date: new Date().toISOString().split('T')[0],
            points_earned: milestone.points_value
          })
          .eq('id', milestone.id);
        
        // Update client challenge milestones count
        await this.supabase
          .from('client_challenges')
          .update({
            completed_milestones: milestone.milestone_index + 1,
            points_earned: this.supabase.sql`points_earned + ${milestone.points_value}`
          })
          .eq('id', clientChallengeId);
      }
    }
  } catch (error) {
    console.error('Error checking milestones:', error);
  }
}

// Get challenge leaderboard
async getChallengeLeaderboard(challengeId, limit = 10) {
  try {
    const { data, error } = await this.supabase
      .from('challenge_leaderboard')
      .select(`
        *,
        client:clients(first_name, last_name, avatar_url)
      `)
      .eq('challenge_id', challengeId)
      .order('rank')
      .limit(limit);
    
    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Error fetching leaderboard:', error);
    return [];
  }
}

// Auto-track progress from other systems
async autoTrackChallengeProgress(clientId, sourceType, sourceData) {
  try {
    // Get active challenges that match the source type
    const { data: challenges } = await this.supabase
      .from('client_challenges')
      .select('*, challenge:challenges(*)')
      .eq('client_id', clientId)
      .eq('status', 'active');
    
    if (!challenges || challenges.length === 0) return;
    
    for (const challenge of challenges) {
      let shouldLog = false;
      let progressData = {};
      
      // Check if this challenge should track this source
      if (sourceType === 'workout' && challenge.challenge.strategy_type === 'workout_plan') {
        shouldLog = true;
        progressData = {
          type: 'workout',
          value: 1,
          data: { workout_id: sourceData.workoutId }
        };
      } else if (sourceType === 'meal' && challenge.challenge.strategy_type === 'meal_plan') {
        shouldLog = true;
        progressData = {
          type: 'meal',
          value: sourceData.compliance || 1,
          data: { meal_id: sourceData.mealId }
        };
      } else if (sourceType === 'check_in' && challenge.challenge.strategy_type === 'daily_habit') {
        shouldLog = true;
        progressData = {
          type: 'daily',
          value: 1,
          data: { check_in_time: sourceData.time }
        };
      }
      
      if (shouldLog) {
        await this.logChallengeProgress(challenge.id, {
          ...progressData,
          auto_tracked: true,
          source_type: sourceType,
          source_id: sourceData.id
        });
      }
    }
  } catch (error) {
    console.error('Error auto-tracking progress:', error);
  }
}

// Get money back status for client
async getMoneyBackStatus(clientId) {
  try {
    const { data: challenges } = await this.supabase
      .from('client_challenges')
      .select('money_back_number, status')
      .eq('client_id', clientId)
      .eq('is_money_back_challenge', true)
      .order('money_back_number');
    
    const completed = challenges ? challenges.filter(c => c.status === 'completed').length : 0;
    const active = challenges ? challenges.filter(c => c.status === 'active').length : 0;
    
    return {
      count: completed,
      active: active,
      eligible: (completed + active) < 3,
      remaining: 3 - completed
    };
  } catch (error) {
    console.error('Error getting money back status:', error);
    return { count: 0, active: 0, eligible: true, remaining: 3 };
  }
}

// ===== PLAK HIER BOVEN  =====


}












// ===== HELPER FUNCTIONS =====

// Calculate success probability
function calculateSuccessProbability(currentProgress, avgStreak, daysElapsed, estimatedDaysToComplete) {
  let probability = 50 // Base probability
  
  // Adjust based on current progress
  if (currentProgress > 75) probability += 30
  else if (currentProgress > 50) probability += 20
  else if (currentProgress > 25) probability += 10
  
  // Adjust based on consistency (streak)
  if (avgStreak > 14) probability += 20
  else if (avgStreak > 7) probability += 15
  else if (avgStreak > 3) probability += 10
  
  // Adjust based on time remaining
  if (estimatedDaysToComplete && estimatedDaysToComplete < 30) probability += 10
  else if (estimatedDaysToComplete && estimatedDaysToComplete > 180) probability -= 10
  
  // Cap between 5 and 95
  return Math.min(95, Math.max(5, probability))













}





// EERST extend de class
extendDatabaseService(DatabaseServiceClass)

// DAN PAS maak de instance
const DatabaseService = new DatabaseServiceClass()

// Export
export default DatabaseService
export { DatabaseServiceClass }
