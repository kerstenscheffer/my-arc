import React from 'react'
import { Clock, ChevronRight, Utensils, Flame } from 'lucide-react'

export default function NextMealCard({ nextMeal, onMealClick }) {
  const isMobile = window.innerWidth <= 768
  
  if (!nextMeal) {
    return (
      <div style={{
        background: 'linear-gradient(135deg, #047857 0%, #065f46 100%)',
        borderRadius: isMobile ? '16px' : '20px',
        padding: isMobile ? '1.25rem' : '1.5rem',
        marginBottom: '1.5rem',
        boxShadow: '0 4px 20px rgba(4, 120, 87, 0.25)',
        border: '1px solid rgba(16, 185, 129, 0.2)',
        color: 'white',
        touchAction: 'manipulation',
        WebkitTapHighlightColor: 'transparent'
      }}>
        <div style={{ 
          display: 'flex', 
          alignItems: 'center', 
          gap: '0.75rem',
          marginBottom: '0.5rem'
        }}>
          <Utensils size={isMobile ? 18 : 20} style={{ color: '#10b981' }} />
          <h3 style={{ 
            fontSize: isMobile ? '1.1rem' : '1.25rem', 
            margin: 0,
            fontWeight: '600',
            textShadow: '0 2px 4px rgba(0,0,0,0.1)'
          }}>
            Alle maaltijden voltooid! 🎉
          </h3>
        </div>
        <p style={{ 
          margin: 0, 
          opacity: 0.9,
          fontSize: isMobile ? '0.9rem' : '1rem'
        }}>
          Geweldige prestatie vandaag!
        </p>
      </div>
    )
  }

  const timeUntil = () => {
    const now = new Date()
    const currentHours = now.getHours() + now.getMinutes() / 60
    const mealHours = nextMeal.plannedTime
    
    if (mealHours < currentHours) {
      return 'Nu eten'
    }
    
    const hoursUntil = mealHours - currentHours
    if (hoursUntil < 1) {
      const minutes = Math.round(hoursUntil * 60)
      return `Over ${minutes} min`
    }
    
    const hours = Math.floor(hoursUntil)
    const minutes = Math.round((hoursUntil - hours) * 60)
    return `Over ${hours}u ${minutes > 0 ? `${minutes}m` : ''}`
  }

  return (
    <div 
      onClick={() => onMealClick(nextMeal)}
      style={{
        background: 'linear-gradient(135deg, #047857 0%, #065f46 100%)',
        borderRadius: isMobile ? '16px' : '20px',
        padding: isMobile ? '1.25rem' : '1.5rem',
        marginBottom: '1.5rem',
        boxShadow: '0 4px 20px rgba(4, 120, 87, 0.3)',
        border: '1px solid rgba(16, 185, 129, 0.2)',
        cursor: 'pointer',
        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
        color: 'white',
        position: 'relative',
        overflow: 'hidden',
        touchAction: 'manipulation',
        WebkitTapHighlightColor: 'transparent'
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.transform = 'translateY(-2px) scale(1.01)'
        e.currentTarget.style.boxShadow = '0 8px 30px rgba(4, 120, 87, 0.4)'
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.transform = 'translateY(0) scale(1)'
        e.currentTarget.style.boxShadow = '0 4px 20px rgba(4, 120, 87, 0.3)'
      }}
    >
      {/* Subtle pattern overlay */}
      <div style={{
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: 'radial-gradient(circle at top right, rgba(16, 185, 129, 0.1) 0%, transparent 50%)',
        pointerEvents: 'none'
      }} />

      <div style={{ position: 'relative', zIndex: 1 }}>
        {/* Header */}
        <div style={{ 
          display: 'flex', 
          justifyContent: 'space-between',
          alignItems: 'flex-start',
          marginBottom: '1rem'
        }}>
          <div>
            <div style={{ 
              display: 'flex', 
              alignItems: 'center', 
              gap: '0.5rem',
              marginBottom: '0.25rem'
            }}>
              <Clock size={isMobile ? 16 : 18} style={{ color: '#10b981' }} />
              <span style={{ 
                fontSize: isMobile ? '0.85rem' : '0.9rem',
                color: '#10b981',
                fontWeight: '600',
                letterSpacing: '0.5px'
              }}>
                {timeUntil()}
              </span>
            </div>
            <h3 style={{ 
              fontSize: isMobile ? '1.25rem' : '1.5rem', 
              margin: 0,
              fontWeight: '700',
              letterSpacing: '-0.5px',
              textShadow: '0 2px 8px rgba(0,0,0,0.2)'
            }}>
              {nextMeal.timeSlot}
            </h3>
          </div>
          <ChevronRight 
            size={isMobile ? 20 : 24} 
            style={{ 
              color: 'rgba(255,255,255,0.7)',
              marginTop: '0.5rem'
            }} 
          />
        </div>

        {/* Meal Name */}
        <div style={{
          background: 'rgba(0,0,0,0.2)',
          borderRadius: '12px',
          padding: isMobile ? '0.875rem' : '1rem',
          backdropFilter: 'blur(10px)',
          marginBottom: '1rem'
        }}>
          <h4 style={{ 
            margin: 0,
            fontSize: isMobile ? '1.1rem' : '1.25rem',
            fontWeight: '600',
            marginBottom: '0.5rem'
          }}>
            {nextMeal.name}
          </h4>
          
          {/* Macros Grid */}
          <div style={{ 
            display: 'grid',
            gridTemplateColumns: 'repeat(4, 1fr)',
            gap: isMobile ? '0.5rem' : '0.75rem',
            marginTop: '0.75rem'
          }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ 
                fontSize: isMobile ? '1.1rem' : '1.25rem',
                fontWeight: '700',
                color: '#fbbf24',
                textShadow: '0 0 10px rgba(251, 191, 36, 0.4)'
              }}>
                {nextMeal.kcal || 0}
              </div>
              <div style={{ 
                fontSize: isMobile ? '0.7rem' : '0.75rem',
                opacity: 0.8,
                marginTop: '2px',
                letterSpacing: '0.5px'
              }}>
                KCAL
              </div>
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ 
                fontSize: isMobile ? '1.1rem' : '1.25rem',
                fontWeight: '700',
                color: '#60a5fa',
                textShadow: '0 0 10px rgba(96, 165, 250, 0.4)'
              }}>
                {nextMeal.protein || 0}g
              </div>
              <div style={{ 
                fontSize: isMobile ? '0.7rem' : '0.75rem',
                opacity: 0.8,
                marginTop: '2px',
                letterSpacing: '0.5px'
              }}>
                EIWIT
              </div>
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ 
                fontSize: isMobile ? '1.1rem' : '1.25rem',
                fontWeight: '700',
                color: '#f87171',
                textShadow: '0 0 10px rgba(248, 113, 113, 0.4)'
              }}>
                {nextMeal.carbs || 0}g
              </div>
              <div style={{ 
                fontSize: isMobile ? '0.7rem' : '0.75rem',
                opacity: 0.8,
                marginTop: '2px',
                letterSpacing: '0.5px'
              }}>
                CARBS
              </div>
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ 
                fontSize: isMobile ? '1.1rem' : '1.25rem',
                fontWeight: '700',
                color: '#c084fc',
                textShadow: '0 0 10px rgba(192, 132, 252, 0.4)'
              }}>
                {nextMeal.fat || 0}g
              </div>
              <div style={{ 
                fontSize: isMobile ? '0.7rem' : '0.75rem',
                opacity: 0.8,
                marginTop: '2px',
                letterSpacing: '0.5px'
              }}>
                VET
              </div>
            </div>
          </div>
        </div>

        {/* Action hint */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '0.5rem',
          fontSize: isMobile ? '0.85rem' : '0.9rem',
          opacity: 0.9
        }}>
          <Flame size={isMobile ? 14 : 16} />
          <span>Tik voor recept & details</span>
        </div>
      </div>
    </div>
  )
}
