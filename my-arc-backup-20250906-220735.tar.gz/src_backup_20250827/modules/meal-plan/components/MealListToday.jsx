// src/modules/meal-plan/components/MealListToday.jsx
import React, { useState } from 'react'
import { 
  CheckCircle2, Star, RefreshCw, ChevronRight,
  Flame, Dumbbell, Zap, Droplets, Clock,
  Sparkles, TrendingUp
} from 'lucide-react'

export default function MealListToday({ 
  meals, 
  checkedMeals, 
  favorites, 
  onToggleMeal, 
  onSwapMeal, 
  onDetailMeal, 
  onToggleFavorite 
}) {
  const isMobile = window.innerWidth <= 768
  const completedCount = Object.values(checkedMeals).filter(Boolean).length
  const completionPercent = meals.length > 0 ? Math.round((completedCount / meals.length) * 100) : 0
  
  return (
    <div style={{ padding: '0 1rem 1rem' }}>
      {/* Section Header with Progress */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: '1rem'
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '0.5rem'
        }}>
          <TrendingUp size={16} style={{ color: '#059669' }} />
          <h3 style={{
            fontSize: '0.9rem',
            color: 'rgba(255,255,255,0.5)',
            margin: 0,
            fontWeight: '600',
            textTransform: 'uppercase',
            letterSpacing: '0.05em'
          }}>
            Vandaag's Planning
          </h3>
        </div>
        
        {meals.length > 0 && (
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '0.5rem',
            background: 'rgba(4, 120, 87, 0.1)',
            padding: '0.25rem 0.75rem',
            borderRadius: '20px',
            border: '1px solid rgba(4, 120, 87, 0.2)'
          }}>
            <CheckCircle2 size={14} style={{ color: '#059669' }} />
            <span style={{
              fontSize: '0.75rem',
              color: '#059669',
              fontWeight: '600'
            }}>
              {completedCount}/{meals.length}
            </span>
          </div>
        )}
      </div>
      
      {/* Progress Bar */}
      {meals.length > 0 && (
        <div style={{
          background: 'rgba(4, 120, 87, 0.1)',
          borderRadius: '8px',
          height: '4px',
          overflow: 'hidden',
          marginBottom: '1rem'
        }}>
          <div style={{
            background: 'linear-gradient(90deg, #047857 0%, #059669 100%)',
            height: '100%',
            width: `${completionPercent}%`,
            transition: 'width 0.5s ease',
            boxShadow: '0 0 10px rgba(5, 150, 105, 0.5)'
          }} />
        </div>
      )}
      
      {/* Meals List */}
      {meals.length > 0 ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
          {meals.map((meal, idx) => (
            <MealCard
              key={`${meal.id}-${idx}`}
              meal={meal}
              index={idx}
              isChecked={checkedMeals[idx]}
              isFavorite={favorites.includes(meal.id)}
              onToggle={() => onToggleMeal(idx)}
              onSwap={() => onSwapMeal(meal)}
              onDetail={() => onDetailMeal(meal)}
              onFavorite={() => onToggleFavorite(meal.id)}
            />
          ))}
        </div>
      ) : (
        <EmptyState />
      )}
    </div>
  )
}

function MealCard({ 
  meal, 
  index,
  isChecked, 
  isFavorite, 
  onToggle, 
  onSwap, 
  onDetail, 
  onFavorite 
}) {
  const [isHovered, setIsHovered] = useState(false)
  const isMobile = window.innerWidth <= 768
  
  const getMealImage = (name) => {
    if (!name) return 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=150&h=150&fit=crop'
    
    const images = {
      'smoothie': 'https://images.unsplash.com/photo-1502767089025-6572583495f9?w=150&h=150&fit=crop',
      'bowl': 'https://images.unsplash.com/photo-1590301157890-4810ed352733?w=150&h=150&fit=crop',
      'chicken': 'https://images.unsplash.com/photo-1532550907401-a500c9a57435?w=150&h=150&fit=crop',
      'kip': 'https://images.unsplash.com/photo-1532550907401-a500c9a57435?w=150&h=150&fit=crop',
      'zalm': 'https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=150&h=150&fit=crop',
      'salmon': 'https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=150&h=150&fit=crop',
      'yoghurt': 'https://images.unsplash.com/photo-1488477304112-4944851de03d?w=150&h=150&fit=crop',
      'oats': 'https://images.unsplash.com/photo-1517673400267-0251440c45dc?w=150&h=150&fit=crop',
      'pasta': 'https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?w=150&h=150&fit=crop',
      'salade': 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=150&h=150&fit=crop'
    }
    
    const key = Object.keys(images).find(k => name.toLowerCase().includes(k))
    return images[key] || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=150&h=150&fit=crop'
  }
  
  // Time until meal
  const getTimeStatus = () => {
    if (!meal.plannedTime) return null
    const now = new Date().getHours() + new Date().getMinutes() / 60
    const timeUntil = meal.plannedTime - now
    
    if (Math.abs(timeUntil) < 0.5) return { text: 'Nu', color: '#059669' }
    if (timeUntil > 0 && timeUntil < 2) return { text: `${Math.round(timeUntil * 60)} min`, color: '#f59e0b' }
    if (timeUntil < 0) return { text: 'Gemist', color: '#ef4444' }
    return null
  }
  
  const timeStatus = getTimeStatus()
  
  return (
    <div 
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      style={{
        background: isChecked
          ? 'linear-gradient(135deg, rgba(4, 120, 87, 0.15) 0%, rgba(5, 150, 105, 0.08) 100%)'
          : isHovered
            ? 'linear-gradient(135deg, rgba(23, 23, 23, 0.8) 0%, rgba(30, 30, 30, 0.6) 100%)'
            : 'linear-gradient(135deg, rgba(23, 23, 23, 0.6) 0%, rgba(20, 20, 20, 0.4) 100%)',
        border: isChecked
          ? '1px solid rgba(4, 120, 87, 0.3)'
          : '1px solid rgba(255, 255, 255, 0.05)',
        borderRadius: '14px',
        padding: isMobile ? '0.75rem' : '1rem',
        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
        cursor: 'pointer',
        animation: `slideInUp 0.4s cubic-bezier(0.4, 0, 0.2, 1) ${index * 0.05}s both`,
        position: 'relative',
        overflow: 'hidden',
        transform: isHovered ? 'translateY(-2px)' : 'translateY(0)',
        boxShadow: isHovered 
          ? '0 10px 30px rgba(0, 0, 0, 0.3)'
          : '0 4px 15px rgba(0, 0, 0, 0.2)'
      }}
      onClick={onToggle}
    >
      {/* Shimmer effect on hover */}
      {isHovered && !isChecked && (
        <div style={{
          position: 'absolute',
          top: 0,
          left: '-100%',
          width: '100%',
          height: '100%',
          background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.03), transparent)',
          animation: 'shimmer 0.5s ease'
        }} />
      )}
      
      <div style={{ display: 'flex', gap: isMobile ? '0.75rem' : '1rem', alignItems: 'center' }}>
        {/* Image with premium styling */}
        <div 
          onClick={(e) => {
            e.stopPropagation()
            onDetail()
          }}
          style={{
            width: isMobile ? '55px' : '70px',
            height: isMobile ? '55px' : '70px',
            borderRadius: '12px',
            overflow: 'hidden',
            flexShrink: 0,
            position: 'relative',
            background: 'rgba(0,0,0,0.4)',
            cursor: 'pointer',
            border: isChecked ? '2px solid rgba(4, 120, 87, 0.5)' : '2px solid transparent',
            transition: 'all 0.3s ease'
          }}
        >
          <img
            src={meal.image_url || getMealImage(meal.name)}
            alt={meal.name}
            style={{
              width: '100%',
              height: '100%',
              objectFit: 'cover',
              filter: isChecked ? 'brightness(0.7)' : 'brightness(1)'
            }}
            onError={(e) => {
              e.target.src = 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=150&h=150&fit=crop'
            }}
          />
          
          {isChecked && (
            <div style={{
              position: 'absolute',
              inset: 0,
              background: 'linear-gradient(135deg, rgba(4, 120, 87, 0.9) 0%, rgba(5, 150, 105, 0.8) 100%)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              animation: 'fadeIn 0.3s ease'
            }}>
              <CheckCircle2 size={26} style={{ color: '#fff', filter: 'drop-shadow(0 2px 4px rgba(0,0,0,0.3))' }} />
            </div>
          )}
          
          {/* Time badge */}
          {timeStatus && !isChecked && (
            <div style={{
              position: 'absolute',
              top: '4px',
              right: '4px',
              background: 'rgba(0, 0, 0, 0.8)',
              backdropFilter: 'blur(10px)',
              borderRadius: '8px',
              padding: '2px 6px',
              border: `1px solid ${timeStatus.color}40`
            }}>
              <span style={{
                fontSize: '0.65rem',
                color: timeStatus.color,
                fontWeight: '600'
              }}>
                {timeStatus.text}
              </span>
            </div>
          )}
        </div>
        
        {/* Content */}
        <div style={{ flex: 1 }}>
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'flex-start',
            marginBottom: '0.5rem'
          }}>
            <div style={{ flex: 1 }}>
              {/* Time slot with clock icon */}
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.25rem',
                marginBottom: '0.35rem'
              }}>
                <Clock size={12} style={{ color: 'rgba(5, 150, 105, 0.6)' }} />
                <p style={{
                  color: 'rgba(5, 150, 105, 0.8)',
                  fontSize: '0.7rem',
                  fontWeight: '600',
                  textTransform: 'uppercase',
                  letterSpacing: '0.05em'
                }}>
                  {meal.timeSlot}
                </p>
              </div>
              
              <p 
                onClick={(e) => {
                  e.stopPropagation()
                  onDetail()
                }}
                style={{
                  color: '#fff',
                  fontSize: isMobile ? '0.95rem' : '1rem',
                  fontWeight: '600',
                  textDecoration: isChecked ? 'line-through' : 'none',
                  opacity: isChecked ? 0.6 : 1,
                  cursor: 'pointer',
                  transition: 'all 0.3s ease',
                  marginBottom: '0.5rem'
                }}
              >
                {meal.name}
              </p>
              
              {/* Premium Macro Display */}
              <div style={{
                display: 'flex',
                gap: isMobile ? '0.5rem' : '0.75rem',
                flexWrap: 'wrap'
              }}>
                <MacroItem 
                  icon={Flame} 
                  value={meal.kcal || 0} 
                  unit=" kcal" 
                  color="#f59e0b"
                  isChecked={isChecked}
                  compact={isMobile}
                />
                <MacroItem 
                  icon={Dumbbell} 
                  value={meal.protein || 0} 
                  unit="g" 
                  color="#3b82f6"
                  isChecked={isChecked}
                  compact={isMobile}
                />
                <MacroItem 
                  icon={Zap} 
                  value={meal.carbs || 0} 
                  unit="g" 
                  color="#ef4444"
                  isChecked={isChecked}
                  compact={isMobile}
                />
                {!isMobile && (
                  <MacroItem 
                    icon={Droplets} 
                    value={meal.fat || 0} 
                    unit="g" 
                    color="#8b5cf6"
                    isChecked={isChecked}
                    compact={isMobile}
                  />
                )}
              </div>
            </div>
            
            {/* Action Buttons */}
            <div style={{ 
              display: 'flex', 
              gap: '0.25rem',
              alignItems: 'center'
            }}>
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  onFavorite()
                }}
                style={{
                  background: 'transparent',
                  border: 'none',
                  cursor: 'pointer',
                  padding: '0.5rem',
                  borderRadius: '10px',
                  transition: 'all 0.2s ease',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = 'rgba(245, 158, 11, 0.1)'
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'transparent'
                }}
              >
                <Star 
                  size={18} 
                  style={{ 
                    color: isFavorite ? '#f59e0b' : 'rgba(255,255,255,0.2)',
                    fill: isFavorite ? '#f59e0b' : 'none',
                    transition: 'all 0.2s ease',
                    filter: isFavorite ? 'drop-shadow(0 0 4px rgba(245, 158, 11, 0.5))' : 'none'
                  }} 
                />
              </button>
              
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  onSwap()
                }}
                style={{
                  background: 'transparent',
                  border: 'none',
                  cursor: 'pointer',
                  padding: '0.5rem',
                  borderRadius: '10px',
                  transition: 'all 0.2s ease',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = 'rgba(5, 150, 105, 0.1)'
                  e.currentTarget.querySelector('svg').style.transform = 'rotate(180deg)'
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'transparent'
                  e.currentTarget.querySelector('svg').style.transform = 'rotate(0deg)'
                }}
              >
                <RefreshCw 
                  size={18} 
                  style={{ 
                    color: 'rgba(5, 150, 105, 0.6)',
                    transition: 'all 0.3s ease'
                  }} 
                />
              </button>
            </div>
          </div>
        </div>
      </div>
      
      <style>{`
        @keyframes slideInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        
        @keyframes shimmer {
          to { left: 100%; }
        }
      `}</style>
    </div>
  )
}

function MacroItem({ icon: Icon, value, unit, color, isChecked, compact }) {
  return (
    <div style={{ 
      display: 'flex', 
      alignItems: 'center', 
      gap: compact ? '3px' : '4px',
      background: isChecked ? 'transparent' : `${color}10`,
      padding: compact ? '2px 6px' : '3px 8px',
      borderRadius: '6px',
      transition: 'all 0.3s ease'
    }}>
      <Icon size={compact ? 11 : 12} style={{ color: isChecked ? `${color}80` : color }} />
      <span style={{ 
        fontSize: compact ? '0.7rem' : '0.75rem',
        color: isChecked ? 'rgba(255,255,255,0.4)' : 'rgba(255,255,255,0.7)',
        fontWeight: '500'
      }}>
        {value}{unit}
      </span>
    </div>
  )
}

function EmptyState() {
  return (
    <div style={{
      textAlign: 'center',
      padding: '3rem 2rem',
      background: 'linear-gradient(135deg, rgba(23, 23, 23, 0.6) 0%, rgba(20, 20, 20, 0.4) 100%)',
      borderRadius: '18px',
      border: '1px solid rgba(255, 255, 255, 0.05)',
      position: 'relative',
      overflow: 'hidden'
    }}>
      <div style={{
        position: 'absolute',
        top: '-50px',
        right: '-50px',
        width: '150px',
        height: '150px',
        background: 'radial-gradient(circle, rgba(5, 150, 105, 0.1) 0%, transparent 70%)',
        borderRadius: '50%'
      }} />
      
      <div style={{
        width: '70px',
        height: '70px',
        margin: '0 auto 1.5rem',
        borderRadius: '50%',
        background: 'linear-gradient(135deg, rgba(4, 120, 87, 0.2) 0%, rgba(5, 150, 105, 0.1) 100%)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        position: 'relative',
        zIndex: 1
      }}>
        <ChevronRight size={28} style={{ color: '#059669' }} />
      </div>
      
      <p style={{
        color: '#fff',
        fontSize: '1.1rem',
        fontWeight: '600',
        marginBottom: '0.5rem'
      }}>
        Geen maaltijden gepland
      </p>
      <p style={{
        color: 'rgba(255, 255, 255, 0.5)',
        fontSize: '0.9rem',
        lineHeight: 1.5
      }}>
        Vraag je coach om een meal plan voor je te maken!
      </p>
    </div>
  )
}
