// src/modules/workout/constants/exerciseDatabase.js

const EXERCISE_DATABASE = {
  chest: {
    compound: [
      "Machine Chest Press",
      "Incline Dumbbell Press",
      "Barbell Bench Press",
      "Weighted Dips",
      "Low-Incline Barbell Bench Press",
      "Flat Dumbbell Bench Press",
      "Decline Bench Press",
      "Close-Grip Bench Press"
    ],
    isolation: [
      "Incline Cable Flies",
      "Machine Pec Deck",
      "Seated Cable Fly",
      "Low-to-High Cable Fly",
      "Dumbbell Flies",
      "Cable Crossover",
      "Chest Dips"
    ]
  },
  
  back: {
    compound: [
      "Lat Pulldown",
      "Weighted Pull-Ups",
      "T-Bar Row (Chest-Supported)",
      "Cable Row",
      "Barbell Bent-Over Row",
      "Single-Arm Dumbbell Row",
      "Pendlay Row",
      "Rack Pulls"
    ],
    isolation: [
      "Cable Pullovers",
      "Straight-Arm Pulldown (Rope)",
      "Face Pulls",
      "Single-Arm Lat Pulldown",
      "Reverse Flies",
      "Shrugs"
    ]
  },
  
  legs: {
    compound: [
      "Leg Press",
      "Romanian Deadlift",
      "Hip Thrust",
      "High-Bar Back Squat",
      "Bulgarian Split Squat",
      "Hack Squat",
      "Front Squat",
      "Goblet Squat",
      "Walking Lunges",
      "Step-Ups"
    ],
    isolation: [
      "Leg Extension",
      "Leg Curl",
      "Calf Raises",
      "Single-Leg Leg Extension",
      "Nordic Curls",
      "Seated Calf Raises",
      "Glute Kickbacks"
    ]
  },
  
  shoulders: {
    compound: [
      "Machine Shoulder Press",
      "Dumbbell Shoulder Press",
      "Overhead Press",
      "Seated Barbell Overhead Press",
      "Arnold Press",
      "Pike Push-Ups"
    ],
    isolation: [
      "Cable Lateral Raises",
      "Lean-Away Cable Lateral Raise",
      "Machine Lateral Raises",
      "Dumbbell Lateral Raises",
      "Lying Incline Lateral Raise",
      "Front Raises",
      "Rear Delt Flies"
    ]
  },
  
  biceps: {
    isolation: [
      "Incline Dumbbell Curl",
      "Bayesian Cable Curl",
      "Cable Bicep Curls",
      "Preacher Curls",
      "Hammer Curls",
      "Barbell Curls",
      "Concentration Curls",
      "Spider Curls",
      "21s",
      "Cable Hammer Curls"
    ]
  },
  
  triceps: {
    compound: [
      "Close-Grip Bench Press",
      "Weighted Dips",
      "Diamond Push-Ups"
    ],
    isolation: [
      "Cable Overhead Triceps Extension",
      "Single-Arm Overhead Cable Extension",
      "Crossbody Cable Extension",
      "Incline Skull Crushers",
      "Triceps Pushdown",
      "Dumbbell Overhead Extension",
      "Rope Pushdown",
      "Kickbacks"
    ]
  },
  
  abs: {
    compound: [
      "Hanging Leg Raises",
      "Ab Wheel Rollout",
      "Dragon Flags"
    ],
    isolation: [
      "Cable Crunches",
      "Plank",
      "Side Plank",
      "Russian Twists",
      "Bicycle Crunches",
      "Dead Bug",
      "Bird Dog",
      "Mountain Climbers"
    ]
  },
  
  glutes: {
    compound: [
      "Hip Thrust",
      "Barbell Glute Bridge",
      "Single-Leg Hip Thrust",
      "Romanian Deadlift"
    ],
    isolation: [
      "Cable Pull-Through",
      "Glute Kickbacks",
      "Clamshells",
      "Fire Hydrants",
      "Donkey Kicks",
      "Cable Hip Abduction"
    ]
  }
}

// Helper functions
export const getMuscleGroups = () => Object.keys(EXERCISE_DATABASE)

export const getExercisesForMuscle = (muscle, type = 'all') => {
  const muscleData = EXERCISE_DATABASE[muscle.toLowerCase()]
  if (!muscleData) return []
  
  if (type === 'compound') return muscleData.compound || []
  if (type === 'isolation') return muscleData.isolation || []
  
  // Return all exercises
  const all = []
  if (muscleData.compound) all.push(...muscleData.compound)
  if (muscleData.isolation) all.push(...muscleData.isolation)
  return all
}

export const searchExercises = (query) => {
  const results = []
  const searchTerm = query.toLowerCase()
  
  Object.entries(EXERCISE_DATABASE).forEach(([muscle, exercises]) => {
    if (exercises.compound) {
      exercises.compound.forEach(ex => {
        if (ex.toLowerCase().includes(searchTerm)) {
          results.push({ name: ex, muscle, type: 'compound' })
        }
      })
    }
    if (exercises.isolation) {
      exercises.isolation.forEach(ex => {
        if (ex.toLowerCase().includes(searchTerm)) {
          results.push({ name: ex, muscle, type: 'isolation' })
        }
      })
    }
  })
  
  return results
}

export default EXERCISE_DATABASE
