// src/modules/workout/components/WorkoutDetails.jsx
import { X, Play, BookOpen, RefreshCw, Video, Clock, Target, Flame, Activity, Info, ChevronLeft } from 'lucide-react'

export default function WorkoutDetails({
  workout,
  workoutKey,
  onClose,
  onComplete,
  onShowAlternatives,
  client,
  db,
  weekSchedule,
  weekDays
}) {
  const isMobile = window.innerWidth <= 768
  
  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: 'linear-gradient(180deg, #0a0a0a 0%, #171717 100%)',
      zIndex: 1000,
      overflowY: 'auto',
      animation: 'slideIn 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
    }}>
      {/* Sticky Header */}
      <WorkoutHeader 
        workout={workout}
        onClose={onClose}
        onComplete={onComplete}
        isMobile={isMobile}
      />

      {/* Exercises List */}
      <div style={{ 
        padding: isMobile ? '1rem' : '1.5rem',
        paddingTop: '0.5rem',
        paddingBottom: isMobile ? '6rem' : '2rem'
      }}>
        <ExercisesList 
          exercises={workout.exercises}
          onShowAlternatives={onShowAlternatives}
          isMobile={isMobile}
        />
      </div>
    </div>
  )
}

function WorkoutHeader({ workout, onClose, onComplete, isMobile }) {
  return (
    <div style={{
      background: 'linear-gradient(135deg, #f97316 0%, #ea580c 100%)',
      padding: isMobile ? '1rem' : '1.5rem',
      position: 'sticky',
      top: 0,
      zIndex: 10,
      boxShadow: '0 10px 30px rgba(249, 115, 22, 0.3)'
    }}>
      {/* Top bar with back button */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: '1rem'
      }}>
        <button 
          onClick={onClose}
          style={{
            background: 'rgba(255,255,255,0.15)',
            backdropFilter: 'blur(10px)',
            border: 'none',
            borderRadius: '12px',
            width: isMobile ? '40px' : '44px',
            height: isMobile ? '40px' : '44px',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            transition: 'all 0.2s ease'
          }}
        >
          <ChevronLeft size={20} color="#fff" />
        </button>
        
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '0.5rem',
          padding: '0.5rem 0.75rem',
          background: 'rgba(255,255,255,0.15)',
          borderRadius: '10px',
          fontSize: '0.75rem',
          color: '#fff',
          fontWeight: '600'
        }}>
          <Flame size={14} />
          {workout.exercises?.length || 0} oefeningen
        </div>
      </div>
      
      {/* Workout info */}
      <h3 style={{
        margin: '0 0 0.5rem 0',
        fontSize: isMobile ? '1.3rem' : '1.5rem',
        color: '#fff',
        fontWeight: '800'
      }}>
        {workout.name}
      </h3>
      
      <div style={{
        display: 'flex',
        alignItems: 'center',
        gap: '1rem',
        marginBottom: '1.25rem',
        flexWrap: 'wrap'
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '0.35rem',
          fontSize: '0.85rem',
          color: 'rgba(255,255,255,0.9)'
        }}>
          <Target size={14} />
          {workout.focus}
        </div>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '0.35rem',
          fontSize: '0.85rem',
          color: 'rgba(255,255,255,0.9)'
        }}>
          <Clock size={14} />
          ~45 minuten
        </div>
      </div>
      
      {/* Action Buttons */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: isMobile ? '1fr' : 'repeat(2, 1fr)',
        gap: '0.75rem'
      }}>
        <button 
          onClick={() => {
            onComplete()
            alert('Workout voltooid! Goed bezig! 💪')
            onClose()
          }}
          style={{
            background: 'rgba(255,255,255,0.95)',
            border: 'none',
            borderRadius: '12px',
            padding: isMobile ? '0.875rem' : '0.75rem',
            cursor: 'pointer',
            color: '#ea580c',
            fontSize: '0.9rem',
            fontWeight: '700',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '0.5rem',
            transition: 'all 0.2s ease',
            order: isMobile ? 1 : 2
          }}
        >
          <Play size={18} />
          Start Workout
        </button>
        
        <button 
          onClick={() => alert('Exercise library komt binnenkort!')}
          style={{
            background: 'rgba(255,255,255,0.1)',
            border: '1px solid rgba(255,255,255,0.2)',
            borderRadius: '12px',
            padding: isMobile ? '0.875rem' : '0.75rem',
            cursor: 'pointer',
            color: '#fff',
            fontSize: '0.9rem',
            fontWeight: '600',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '0.5rem',
            transition: 'all 0.2s ease',
            order: isMobile ? 2 : 1
          }}
        >
          <BookOpen size={18} />
          Bibliotheek
        </button>
      </div>
    </div>
  )
}

function ExercisesList({ exercises, onShowAlternatives, isMobile }) {
  if (!exercises || exercises.length === 0) {
    return (
      <div style={{
        textAlign: 'center',
        padding: '3rem',
        color: 'rgba(255,255,255,0.5)'
      }}>
        <Activity size={48} color="rgba(249, 115, 22, 0.3)" style={{ marginBottom: '1rem' }} />
        <p>Nog geen oefeningen geconfigureerd</p>
      </div>
    )
  }
  
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
      {exercises.map((exercise, index) => (
        <ExerciseCard 
          key={index}
          exercise={exercise}
          index={index}
          onShowAlternatives={onShowAlternatives}
          isMobile={isMobile}
        />
      ))}
    </div>
  )
}

function ExerciseCard({ exercise, index, onShowAlternatives, isMobile }) {
  return (
    <div style={{
      background: 'linear-gradient(145deg, #141414 0%, #0a0a0a 100%)',
      borderRadius: '20px',
      padding: 0,
      transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
      position: 'relative',
      overflow: 'hidden',
      border: '1px solid rgba(249, 115, 22, 0.06)',
      boxShadow: '0 4px 20px rgba(0, 0, 0, 0.4)'
    }}>
      {/* Top accent gradient */}
      <div style={{
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        height: '2px',
        background: 'linear-gradient(90deg, #f97316 0%, #ea580c 50%, #f97316 100%)',
        backgroundSize: '200% 100%',
        animation: 'shimmer 3s ease-in-out infinite'
      }} />
      
      {/* Exercise Header - Full width bar */}
      <div style={{
        background: 'linear-gradient(135deg, rgba(249, 115, 22, 0.12) 0%, rgba(234, 88, 12, 0.06) 100%)',
        padding: isMobile ? '1rem 1.25rem' : '1.25rem 1.5rem',
        borderBottom: '1px solid rgba(249, 115, 22, 0.08)',
        display: 'flex',
        alignItems: 'center',
        gap: '1rem'
      }}>
        <div style={{
          width: '42px',
          height: '42px',
          background: 'linear-gradient(135deg, #f97316 0%, #ea580c 100%)',
          borderRadius: '12px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontWeight: '800',
          color: '#fff',
          fontSize: '1.1rem',
          flexShrink: 0,
          boxShadow: '0 6px 20px rgba(249, 115, 22, 0.3)',
          position: 'relative'
        }}>
          {index + 1}
          <div style={{
            position: 'absolute',
            inset: '-1px',
            borderRadius: '12px',
            padding: '1px',
            background: 'linear-gradient(135deg, rgba(255,255,255,0.2) 0%, transparent 100%)',
            WebkitMask: 'linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)',
            WebkitMaskComposite: 'xor',
            maskComposite: 'exclude',
            pointerEvents: 'none'
          }} />
        </div>
        <h4 style={{
          fontSize: isMobile ? '1.1rem' : '1.2rem',
          color: '#fff',
          margin: 0,
          fontWeight: '700',
          flex: 1,
          letterSpacing: '-0.02em'
        }}>
          {exercise.name}
        </h4>
      </div>
      
      <div style={{ padding: isMobile ? '1.25rem' : '1.5rem' }}>
        {/* Stats Grid - Redesigned */}
        <ExerciseStats exercise={exercise} isMobile={isMobile} />
        
        {/* Notes */}
        {exercise.notes && (
          <ExerciseNotes notes={exercise.notes} isMobile={isMobile} />
        )}
        
        {/* Action Buttons */}
        <ExerciseActions 
          exercise={exercise}
          onShowAlternatives={onShowAlternatives}
          isMobile={isMobile}
        />
      </div>
    </div>
  )
}

function ExerciseStats({ exercise, isMobile }) {
  const stats = [
    { label: 'Sets', value: exercise.sets, color: '#f97316', icon: Target },
    { label: 'Reps', value: exercise.reps, color: '#3b82f6', icon: Activity },
    { label: 'Rust', value: exercise.rust || '90s', color: '#10b981', icon: Clock },
    { label: 'RPE', value: exercise.rpe || '8', color: '#8b5cf6', icon: Flame }
  ]
  
  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: 'repeat(2, 1fr)',
      gap: '0.875rem',
      marginBottom: '1.25rem'
    }}>
      {stats.map((stat, i) => {
        const Icon = stat.icon
        return (
          <div key={i} style={{
            background: 'linear-gradient(145deg, #1a1a1a 0%, #0f0f0f 100%)',
            padding: isMobile ? '1rem' : '1.125rem',
            borderRadius: '14px',
            textAlign: 'center',
            border: '1px solid rgba(255,255,255,0.05)',
            position: 'relative',
            overflow: 'hidden',
            boxShadow: 'inset 0 2px 4px rgba(0,0,0,0.3)',
            transition: 'all 0.3s ease'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = 'translateY(-2px)'
            e.currentTarget.style.boxShadow = '0 4px 12px rgba(0,0,0,0.5), inset 0 2px 4px rgba(0,0,0,0.3)'
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'translateY(0)'
            e.currentTarget.style.boxShadow = 'inset 0 2px 4px rgba(0,0,0,0.3)'
          }}
          >
            {/* Background gradient glow */}
            <div style={{
              position: 'absolute',
              top: '-50%',
              left: '-50%',
              width: '200%',
              height: '200%',
              background: `radial-gradient(circle, ${stat.color}15 0%, transparent 60%)`,
              pointerEvents: 'none'
            }} />
            
            {/* Icon watermark */}
            <Icon 
              size={40} 
              color={stat.color} 
              style={{
                position: 'absolute',
                bottom: '-10px',
                right: '-10px',
                opacity: 0.08,
                transform: 'rotate(-15deg)'
              }}
            />
            
            <div style={{ position: 'relative', zIndex: 1 }}>
              <div style={{
                fontSize: isMobile ? '1.75rem' : '2rem',
                fontWeight: '800',
                color: stat.color,
                lineHeight: 1,
                marginBottom: '0.35rem',
                textShadow: `0 0 20px ${stat.color}40`
              }}>
                {stat.value}
              </div>
              <div style={{
                fontSize: '0.65rem',
                color: 'rgba(255,255,255,0.3)',
                textTransform: 'uppercase',
                letterSpacing: '0.1em',
                fontWeight: '600'
              }}>
                {stat.label}
              </div>
            </div>
          </div>
        )
      })}
    </div>
  )
}

function ExerciseNotes({ notes, isMobile }) {
  return (
    <div style={{
      background: 'linear-gradient(145deg, rgba(249, 115, 22, 0.06) 0%, rgba(234, 88, 12, 0.03) 100%)',
      padding: isMobile ? '1rem 1.125rem' : '1.125rem 1.25rem',
      marginBottom: '1.25rem',
      borderRadius: '14px',
      border: '1px solid rgba(249, 115, 22, 0.1)',
      display: 'flex',
      gap: '0.75rem',
      alignItems: 'flex-start',
      position: 'relative',
      overflow: 'hidden',
      backdropFilter: 'blur(10px)'
    }}>
      {/* Subtle glow effect */}
      <div style={{
        position: 'absolute',
        top: 0,
        left: 0,
        width: '100px',
        height: '100px',
        background: 'radial-gradient(circle, rgba(249, 115, 22, 0.1) 0%, transparent 70%)',
        pointerEvents: 'none'
      }} />
      
      <div style={{
        width: '32px',
        height: '32px',
        borderRadius: '8px',
        background: 'linear-gradient(135deg, rgba(249, 115, 22, 0.15) 0%, rgba(234, 88, 12, 0.08) 100%)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexShrink: 0,
        marginTop: '2px'
      }}>
        <Info size={16} color="#f97316" />
      </div>
      
      <div style={{ position: 'relative', zIndex: 1 }}>
        <p style={{
          fontSize: '0.7rem',
          color: '#f97316',
          margin: '0 0 0.35rem 0',
          fontWeight: '700',
          textTransform: 'uppercase',
          letterSpacing: '0.1em',
          display: 'flex',
          alignItems: 'center',
          gap: '0.35rem'
        }}>
          <Flame size={12} color="#f97316" />
          Focus on stretch position
        </p>
        <p style={{
          fontSize: isMobile ? '0.85rem' : '0.9rem',
          color: 'rgba(255,255,255,0.65)',
          margin: 0,
          lineHeight: 1.5
        }}>
          {notes}
        </p>
      </div>
    </div>
  )
}

function ExerciseActions({ exercise, onShowAlternatives, isMobile }) {
  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: isMobile ? '1fr' : 'repeat(2, 1fr)',
      gap: '0.875rem'
    }}>
      <button 
        onClick={() => onShowAlternatives(exercise, exercise.primairSpieren || 'chest')}
        style={{
          flex: 1,
          padding: isMobile ? '0.875rem' : '1rem',
          background: 'linear-gradient(145deg, #1a1a1a 0%, #0f0f0f 100%)',
          border: '1px solid rgba(249, 115, 22, 0.15)',
          borderRadius: '12px',
          color: '#f97316',
          fontSize: '0.85rem',
          fontWeight: '700',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '0.5rem',
          transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
          position: 'relative',
          overflow: 'hidden',
          boxShadow: 'inset 0 1px 2px rgba(0,0,0,0.3)'
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.background = 'linear-gradient(145deg, rgba(249, 115, 22, 0.1) 0%, rgba(234, 88, 12, 0.05) 100%)'
          e.currentTarget.style.transform = 'translateY(-2px)'
          e.currentTarget.style.boxShadow = '0 4px 12px rgba(249, 115, 22, 0.2), inset 0 1px 2px rgba(0,0,0,0.3)'
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.background = 'linear-gradient(145deg, #1a1a1a 0%, #0f0f0f 100%)'
          e.currentTarget.style.transform = 'translateY(0)'
          e.currentTarget.style.boxShadow = 'inset 0 1px 2px rgba(0,0,0,0.3)'
        }}
      >
        <RefreshCw size={16} />
        Alternatieven
      </button>
      
      <button 
        onClick={() => alert(`Video voor ${exercise.name} komt binnenkort!`)}
        style={{
          flex: 1,
          padding: isMobile ? '0.875rem' : '1rem',
          background: 'linear-gradient(145deg, rgba(249, 115, 22, 0.08) 0%, rgba(234, 88, 12, 0.04) 100%)',
          border: '1px solid rgba(249, 115, 22, 0.15)',
          borderRadius: '12px',
          color: '#f97316',
          fontSize: '0.85rem',
          fontWeight: '700',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '0.5rem',
          transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
          position: 'relative',
          overflow: 'hidden',
          boxShadow: 'inset 0 1px 2px rgba(0,0,0,0.1)'
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.background = 'linear-gradient(145deg, rgba(249, 115, 22, 0.12) 0%, rgba(234, 88, 12, 0.06) 100%)'
          e.currentTarget.style.transform = 'translateY(-2px)'
          e.currentTarget.style.boxShadow = '0 4px 12px rgba(249, 115, 22, 0.15), inset 0 1px 2px rgba(0,0,0,0.1)'
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.background = 'linear-gradient(145deg, rgba(249, 115, 22, 0.08) 0%, rgba(234, 88, 12, 0.04) 100%)'
          e.currentTarget.style.transform = 'translateY(0)'
          e.currentTarget.style.boxShadow = 'inset 0 1px 2px rgba(0,0,0,0.1)'
        }}
      >
        <Video size={16} />
        Techniek Video
      </button>
    </div>
  )
}

{/* Add shimmer animation to style tag */}
<style>{`
  @keyframes shimmer {
    0% { background-position: -100% 0; }
    100% { background-position: 100% 0; }
  }
`}</style>
