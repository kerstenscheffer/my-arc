import React, { useState, useEffect, useRef } from 'react'
import { 
  Play, X, Clock, Star, ChevronRight, Calendar,
  TrendingUp, Award, Zap, Target, Coffee, Sun, Moon,
  Heart, Brain, Activity, Sparkles, Video
} from 'lucide-react'
import videoService from './VideoService'

// Singleton pattern om dubbele mounts te voorkomen
let globalVideoLoadState = {}

export default function ClientVideoWidget({ client, db }) {
  const [todaysVideo, setTodaysVideo] = useState(null)
  const [recentVideos, setRecentVideos] = useState([])
  const [loading, setLoading] = useState(true)
  const [showPlayer, setShowPlayer] = useState(false)
  const [currentVideo, setCurrentVideo] = useState(null)
  
  // FIX: Gebruik useRef om dubbele loads te voorkomen
  const loadedRef = useRef(false)
  const mountedRef = useRef(true)
  const instanceId = useRef(Math.random().toString(36).substr(2, 9))
  
  const isMobile = window.innerWidth <= 768

  useEffect(() => {
    console.log(`🎬 VideoWidget instance ${instanceId.current} mounted`)
    
    // Cleanup functie
    return () => {
      console.log(`🎬 VideoWidget instance ${instanceId.current} unmounting`)
      mountedRef.current = false
      if (client?.id && globalVideoLoadState[client.id] === instanceId.current) {
        delete globalVideoLoadState[client.id]
      }
    }
  }, [])

  useEffect(() => {
    // FIX: Check of een andere instance al aan het laden is
    if (!client?.id) {
      console.log('⚠️ No client ID, skipping video load')
      return
    }
    
    // Check voor recent gecachte data (binnen 30 seconden)
    if (window.__videoWidgetData && window.__videoWidgetData[client.id]) {
      const cachedData = window.__videoWidgetData[client.id]
      const cacheAge = Date.now() - cachedData.loadedAt
      
      if (cacheAge < 30000) { // 30 seconden cache
        console.log(`📦 Using cached video data (${Math.round(cacheAge/1000)}s old)`)
        setTodaysVideo(cachedData.todaysVideo)
        setRecentVideos(cachedData.recentVideos)
        setLoading(false)
        return
      }
    }
    
    if (globalVideoLoadState[client.id] && globalVideoLoadState[client.id] !== instanceId.current) {
      console.log(`⚠️ Another instance is already loading videos`)
      setLoading(false)
      return
    }
    
    if (loadedRef.current) {
      console.log('⚠️ This instance already loaded videos')
      return
    }
    
    // Claim this client's video loading
    globalVideoLoadState[client.id] = instanceId.current
    loadedRef.current = true
    loadVideos()
    
    // Reset de ref als client ID verandert
    return () => {
      loadedRef.current = false
    }
  }, [client?.id])

  const loadVideos = async () => {
    // Extra check voor mounted state
    if (!mountedRef.current) {
      console.log('⚠️ Component not mounted, skipping video load')
      return
    }
    
    setLoading(true)
    try {
      console.log(`🎬 Instance ${instanceId.current} loading videos for client:`, client.id)
      
      // Get videos voor HOME context
      const homeVideos = await videoService.getVideosForPage(client.id, 'home')
      
      // Check of component nog mounted is
      if (!mountedRef.current) {
        console.log('⚠️ Component unmounted during load, aborting...')
        return
      }
      
      console.log(`✅ Instance ${instanceId.current} loaded ${homeVideos.length} videos`)
      
      // Vind vandaag's video
      const today = new Date().toISOString().split('T')[0]
      const todayVideo = homeVideos.find(v => 
        v.scheduled_for === today && v.status !== 'completed'
      )
      
      if (mountedRef.current) {
        console.log('📺 Today\'s video:', todayVideo ? 'Found' : 'Not found')
        setTodaysVideo(todayVideo)
        
        // Get recent videos
        setRecentVideos(homeVideos.slice(0, 5))
        
        // Store loaded state globally om dubbele renders te voorkomen
        if (!window.__videoWidgetData) {
          window.__videoWidgetData = {}
        }
        window.__videoWidgetData[client.id] = {
          todaysVideo,
          recentVideos: homeVideos.slice(0, 5),
          loadedAt: Date.now()
        }
      }
    } catch (error) {
      console.error(`❌ Instance ${instanceId.current} error:`, error)
    } finally {
      if (mountedRef.current) {
        setLoading(false)
      }
    }
  }

  const handleWatchVideo = async (assignment) => {
    setCurrentVideo(assignment)
    setShowPlayer(true)
    
    // Mark as viewed
    await videoService.markVideoWatched(assignment.id, {
      duration: 0 // Will be updated when video ends
    })
  }

  const getCategoryConfig = (category) => {
    const configs = {
      motivation: { gradient: 'linear-gradient(135deg, rgba(239, 68, 68, 0.7) 0%, rgba(220, 38, 38, 0.6) 100%)', icon: Zap, label: 'Motivatie', color: '#ef4444' },
      technique: { gradient: 'linear-gradient(135deg, rgba(59, 130, 246, 0.7) 0%, rgba(37, 99, 235, 0.6) 100%)', icon: Target, label: 'Techniek', color: '#3b82f6' },
      nutrition: { gradient: 'linear-gradient(135deg, rgba(16, 185, 129, 0.7) 0%, rgba(5, 150, 105, 0.6) 100%)', icon: Heart, label: 'Voeding', color: '#10b981' },
      mindset: { gradient: 'linear-gradient(135deg, rgba(139, 92, 246, 0.7) 0%, rgba(124, 58, 237, 0.6) 100%)', icon: Brain, label: 'Mindset', color: '#8b5cf6' },
      recovery: { gradient: 'linear-gradient(135deg, rgba(6, 182, 212, 0.7) 0%, rgba(8, 145, 178, 0.6) 100%)', icon: Activity, label: 'Herstel', color: '#06b6d4' }
    }
    return configs[category] || configs.motivation
  }

  const getTimeIcon = () => {
    const hour = new Date().getHours()
    if (hour < 6) return <Moon size={16} />
    if (hour < 12) return <Coffee size={16} />
    if (hour < 18) return <Sun size={16} />
    return <Moon size={16} />
  }

  const extractYouTubeId = (url) => {
    if (!url) return null
    const match = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&\n?#]+)/)
    return match ? match[1] : null
  }

  if (loading) {
    return (
      <div style={{
        background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.1) 0%, rgba(5, 150, 105, 0.05) 100%)',
        borderRadius: isMobile ? '16px' : '20px',
        padding: isMobile ? '1.5rem' : '2rem',
        margin: '0 1rem 1rem',
        border: '2px solid rgba(16, 185, 129, 0.2)',
        minHeight: '200px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }}>
        <div style={{ textAlign: 'center', color: 'rgba(255,255,255,0.5)' }}>
          Videos laden...
        </div>
      </div>
    )
  }

  // If there's a featured video for today
  if (todaysVideo) {
    const video = todaysVideo.video
    const categoryConfig = getCategoryConfig(video.category)
    const videoId = extractYouTubeId(video.video_url)
    
    return (
      <>
        <div style={{
          background: categoryConfig.gradient,
          borderRadius: isMobile ? '16px' : '20px',
          padding: isMobile ? '1.5rem' : '2rem',
          margin: '0 1rem 1rem',
          position: 'relative',
          overflow: 'hidden',
          boxShadow: '0 10px 30px rgba(0,0,0,0.3)'
        }}>
          {/* Animated background pattern */}
          <div style={{
            position: 'absolute',
            top: '-50%',
            right: '-20%',
            width: '300px',
            height: '300px',
            background: 'radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%)',
            borderRadius: '50%',
            animation: 'float 6s ease-in-out infinite'
          }} />
          
          <div style={{ position: 'relative', zIndex: 1 }}>
            {/* Header */}
            <div style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginBottom: '1rem'
            }}>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
                fontSize: isMobile ? '0.85rem' : '0.9rem',
                color: 'rgba(255,255,255,0.95)',
                fontWeight: '600'
              }}>
                {getTimeIcon()}
                <span>Video van de Dag</span>
              </div>
              <div style={{
                padding: '0.35rem 0.75rem',
                background: 'rgba(255,255,255,0.15)',
                backdropFilter: 'blur(10px)',
                borderRadius: '8px',
                fontSize: '0.75rem',
                fontWeight: '600',
                color: '#fff',
                display: 'flex',
                alignItems: 'center',
                gap: '0.3rem',
                border: '1px solid rgba(255,255,255,0.2)'
              }}>
                {React.createElement(categoryConfig.icon, { size: 12 })}
                {categoryConfig.label}
              </div>
            </div>

            {/* Video Preview */}
            <div 
              style={{
                position: 'relative',
                borderRadius: '12px',
                overflow: 'hidden',
                marginBottom: '1rem',
                cursor: 'pointer',
                transform: 'scale(1)',
                transition: 'transform 0.3s ease'
              }}
              onClick={() => handleWatchVideo(todaysVideo)}
              onMouseEnter={(e) => {
                if (!isMobile) e.currentTarget.style.transform = 'scale(1.02)'
              }}
              onMouseLeave={(e) => {
                if (!isMobile) e.currentTarget.style.transform = 'scale(1)'
              }}
            >
              <div style={{
                position: 'relative',
                paddingBottom: '56.25%',
                background: '#000'
              }}>
                {videoId && (
                  <img
                    src={`https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`}
                    alt={video.title}
                    style={{
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      width: '100%',
                      height: '100%',
                      objectFit: 'cover'
                    }}
                    onError={(e) => {
                      e.target.src = `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`
                    }}
                  />
                )}
                
                {/* Play Button Overlay */}
                <div style={{
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  right: 0,
                  bottom: 0,
                  background: 'rgba(0,0,0,0.4)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}>
                  <div style={{
                    width: '60px',
                    height: '60px',
                    borderRadius: '50%',
                    background: 'rgba(255,255,255,0.95)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    boxShadow: '0 4px 20px rgba(0,0,0,0.3)'
                  }}>
                    <Play size={24} color="#000" style={{ marginLeft: '4px' }} />
                  </div>
                </div>
                
                {/* Status Badge */}
                {todaysVideo.status === 'viewed' && (
                  <div style={{
                    position: 'absolute',
                    top: '0.75rem',
                    right: '0.75rem',
                    padding: '0.35rem 0.75rem',
                    background: 'rgba(16, 185, 129, 0.9)',
                    borderRadius: '8px',
                    fontSize: '0.75rem',
                    fontWeight: '600',
                    color: '#fff'
                  }}>
                    ✓ Bekeken
                  </div>
                )}
              </div>
            </div>

            {/* Video Info */}
            <h3 style={{
              fontSize: isMobile ? '1.1rem' : '1.25rem',
              fontWeight: 'bold',
              color: '#fff',
              marginBottom: '0.5rem',
              lineHeight: 1.3
            }}>
              {video.title}
            </h3>
            
            {video.description && (
              <p style={{
                fontSize: isMobile ? '0.85rem' : '0.9rem',
                color: 'rgba(255,255,255,0.9)',
                lineHeight: 1.5,
                marginBottom: '1rem'
              }}>
                {video.description}
              </p>
            )}

            {/* Action Button */}
            <button
              onClick={() => handleWatchVideo(todaysVideo)}
              style={{
                width: '100%',
                padding: isMobile ? '0.75rem' : '0.875rem',
                background: 'rgba(255,255,255,0.25)',
                backdropFilter: 'blur(10px)',
                border: '2px solid rgba(255,255,255,0.3)',
                borderRadius: '10px',
                color: '#fff',
                fontSize: isMobile ? '0.95rem' : '1rem',
                fontWeight: '700',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '0.5rem',
                transition: 'all 0.3s ease'
              }}
              onMouseEnter={(e) => {
                if (!isMobile) {
                  e.currentTarget.style.background = 'rgba(255,255,255,0.35)'
                  e.currentTarget.style.transform = 'translateY(-2px)'
                }
              }}
              onMouseLeave={(e) => {
                if (!isMobile) {
                  e.currentTarget.style.background = 'rgba(255,255,255,0.25)'
                  e.currentTarget.style.transform = 'translateY(0)'
                }
              }}
            >
              <Play size={18} />
              {todaysVideo.status === 'viewed' ? 'Bekijk Opnieuw' : 'Start Video'}
              <ChevronRight size={18} />
            </button>
          </div>
        </div>

        {/* Recent Videos Section */}
        {recentVideos.length > 1 && (
          <div style={{
            padding: '0 1rem',
            marginBottom: '1rem'
          }}>
            <h4 style={{
              fontSize: isMobile ? '1rem' : '1.1rem',
              fontWeight: 'bold',
              color: '#fff',
              marginBottom: '1rem',
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem'
            }}>
              <Clock size={18} color="#10b981" />
              Recent Toegewezen
            </h4>
            
            <div style={{
              display: 'flex',
              gap: '0.75rem',
              overflowX: 'auto',
              paddingBottom: '0.5rem'
            }}>
              {recentVideos.slice(1).map((assignment) => {
                const video = assignment.video
                const videoId = extractYouTubeId(video.video_url)
                const categoryConfig = getCategoryConfig(video.category)
                
                return (
                  <div
                    key={assignment.id}
                    onClick={() => handleWatchVideo(assignment)}
                    style={{
                      minWidth: isMobile ? '200px' : '240px',
                      background: 'rgba(255,255,255,0.05)',
                      borderRadius: '12px',
                      overflow: 'hidden',
                      border: '1px solid rgba(255,255,255,0.1)',
                      cursor: 'pointer',
                      transition: 'all 0.3s ease'
                    }}
                    onMouseEnter={(e) => {
                      if (!isMobile) {
                        e.currentTarget.style.transform = 'translateY(-4px)'
                        e.currentTarget.style.borderColor = '#10b981'
                      }
                    }}
                    onMouseLeave={(e) => {
                      if (!isMobile) {
                        e.currentTarget.style.transform = 'translateY(0)'
                        e.currentTarget.style.borderColor = 'rgba(255,255,255,0.1)'
                      }
                    }}
                  >
                    {/* Thumbnail */}
                    <div style={{
                      position: 'relative',
                      paddingBottom: '56.25%',
                      background: '#000'
                    }}>
                      {videoId && (
                        <img
                          src={`https://img.youtube.com/vi/${videoId}/mqdefault.jpg`}
                          alt={video.title}
                          style={{
                            position: 'absolute',
                            top: 0,
                            left: 0,
                            width: '100%',
                            height: '100%',
                            objectFit: 'cover'
                          }}
                        />
                      )}
                      
                      {/* Play Icon */}
                      <div style={{
                        position: 'absolute',
                        top: '50%',
                        left: '50%',
                        transform: 'translate(-50%, -50%)',
                        width: '40px',
                        height: '40px',
                        borderRadius: '50%',
                        background: 'rgba(0,0,0,0.7)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                      }}>
                        <Play size={16} color="#fff" style={{ marginLeft: '2px' }} />
                      </div>
                      
                      {/* Category Badge */}
                      <div style={{
                        position: 'absolute',
                        top: '0.5rem',
                        left: '0.5rem',
                        padding: '0.25rem 0.5rem',
                        background: 'rgba(0,0,0,0.6)',
                        backdropFilter: 'blur(10px)',
                        borderRadius: '6px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        border: '1px solid rgba(255,255,255,0.1)'
                      }}>
                        {React.createElement(categoryConfig.icon, { size: 10, color: categoryConfig.color || '#fff' })}
                      </div>
                      
                      {/* Status */}
                      {assignment.status === 'viewed' && (
                        <div style={{
                          position: 'absolute',
                          top: '0.5rem',
                          right: '0.5rem',
                          width: '24px',
                          height: '24px',
                          borderRadius: '50%',
                          background: 'rgba(16, 185, 129, 0.9)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center'
                        }}>
                          <span style={{ fontSize: '0.7rem', color: '#fff' }}>✓</span>
                        </div>
                      )}
                    </div>
                    
                    {/* Info */}
                    <div style={{ padding: '0.75rem' }}>
                      <h5 style={{
                        fontSize: '0.85rem',
                        fontWeight: '600',
                        color: '#fff',
                        marginBottom: '0.25rem',
                        lineHeight: 1.3,
                        display: '-webkit-box',
                        WebkitLineClamp: 2,
                        WebkitBoxOrient: 'vertical',
                        overflow: 'hidden'
                      }}>
                        {video.title}
                      </h5>
                      <div style={{
                        fontSize: '0.75rem',
                        color: 'rgba(255,255,255,0.5)'
                      }}>
                        {new Date(assignment.scheduled_for).toLocaleDateString('nl-NL', {
                          day: 'numeric',
                          month: 'short'
                        })}
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {/* Video Player Modal */}
        {showPlayer && currentVideo && (
          <VideoPlayerModal
            video={currentVideo.video}
            assignment={currentVideo}
            onClose={() => {
              setShowPlayer(false)
              setCurrentVideo(null)
            }}
            onComplete={async (watchData) => {
              await videoService.markVideoWatched(currentVideo.id, watchData)
              await loadVideos()
            }}
          />
        )}
      </>
    )
  }

  // No videos assigned
  return (
    <div style={{
      background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.1) 0%, rgba(5, 150, 105, 0.05) 100%)',
      borderRadius: isMobile ? '16px' : '20px',
      padding: isMobile ? '1.5rem' : '2rem',
      margin: '0 1rem 1rem',
      border: '2px solid rgba(16, 185, 129, 0.2)',
      textAlign: 'center'
    }}>
      <Play size={48} style={{ color: 'rgba(16, 185, 129, 0.3)', margin: '0 auto 1rem' }} />
      <h3 style={{
        fontSize: isMobile ? '1.1rem' : '1.25rem',
        fontWeight: 'bold',
        color: '#fff',
        marginBottom: '0.5rem'
      }}>
        Nog geen videos beschikbaar
      </h3>
      <p style={{
        fontSize: isMobile ? '0.85rem' : '0.9rem',
        color: 'rgba(255,255,255,0.5)'
      }}>
        Je coach zal binnenkort inspirerende videos met je delen!
      </p>
    </div>
  )
}

// ============================================
// VIDEO PLAYER MODAL
// ============================================
function VideoPlayerModal({ video, assignment, onClose, onComplete }) {
  const [rating, setRating] = useState(0)
  const [watchStartTime] = useState(Date.now())
  const isMobile = window.innerWidth <= 768
  
  const videoId = video.video_url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&\n?#]+)/)?.[1]
  
  const handleClose = () => {
    const watchDuration = Math.floor((Date.now() - watchStartTime) / 1000)
    onComplete({ duration: watchDuration })
    onClose()
  }
  
  const handleRate = async (value) => {
    setRating(value)
    await videoService.rateVideo(assignment.id, value)
  }
  
  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: 'rgba(0,0,0,0.95)',
      zIndex: 10000,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      padding: isMobile ? '1rem' : '2rem'
    }}>
      {/* Close Button */}
      <button
        onClick={handleClose}
        style={{
          position: 'absolute',
          top: '1rem',
          right: '1rem',
          background: 'rgba(255,255,255,0.1)',
          border: 'none',
          borderRadius: '50%',
          width: '40px',
          height: '40px',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 10001
        }}
      >
        <X size={20} color="#fff" />
      </button>
      
      {/* Video Container */}
      <div style={{
        width: '100%',
        maxWidth: '900px',
        aspectRatio: '16/9',
        background: '#000',
        borderRadius: '12px',
        overflow: 'hidden'
      }}>
        {videoId && (
          <iframe
            src={`https://www.youtube.com/embed/${videoId}?autoplay=1`}
            style={{
              width: '100%',
              height: '100%',
              border: 'none'
            }}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
        )}
      </div>
      
      {/* Video Info & Rating */}
      <div style={{
        maxWidth: '900px',
        width: '100%',
        marginTop: '1.5rem',
        padding: '1.5rem',
        background: 'rgba(255,255,255,0.05)',
        borderRadius: '12px'
      }}>
        <h3 style={{
          fontSize: isMobile ? '1.1rem' : '1.25rem',
          fontWeight: 'bold',
          color: '#fff',
          marginBottom: '0.5rem'
        }}>
          {video.title}
        </h3>
        
        {video.description && (
          <p style={{
            fontSize: isMobile ? '0.85rem' : '0.9rem',
            color: 'rgba(255,255,255,0.7)',
            marginBottom: '1rem',
            lineHeight: 1.5
          }}>
            {video.description}
          </p>
        )}
        
        {/* Rating */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '1rem'
        }}>
          <span style={{
            fontSize: '0.9rem',
            color: 'rgba(255,255,255,0.7)'
          }}>
            Beoordeel deze video:
          </span>
          <div style={{ display: 'flex', gap: '0.5rem' }}>
            {[1, 2, 3, 4, 5].map(value => (
              <button
                key={value}
                onClick={() => handleRate(value)}
                style={{
                  background: 'none',
                  border: 'none',
                  cursor: 'pointer',
                  padding: 0
                }}
              >
                <Star
                  size={24}
                  color={value <= rating ? '#fbbf24' : 'rgba(255,255,255,0.2)'}
                  fill={value <= rating ? '#fbbf24' : 'none'}
                />
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

// Add animations
const style = document.createElement('style')
style.textContent = `
  @keyframes float {
    0%, 100% { transform: translateY(0px); }
    50% { transform: translateY(-20px); }
  }
`
document.head.appendChild(style)
