import React from 'react';
import { X, Calendar, Award, Users, Target, ChevronRight, TrendingUp, Clock } from 'lucide-react';

export default function ChallengeDetailModal({ challenge, onClose, onStart, isActive = false }) {
  if (!challenge) return null;
  
  const getDifficultyColor = (difficulty) => ({
    beginner: '#10b981',
    gemiddeld: '#f59e0b', 
    gevorderd: '#ef4444'
  }[difficulty] || '#6b7280');
  
  const milestones = challenge.milestones || [
    { week: 1, title: 'Fundament', description: 'Basis leggen en wennen aan routine' },
    { week: 2, title: 'Opbouwen', description: 'Intensiteit verhogen' },
    { week: 3, title: 'Doorbreken', description: 'Grenzen verleggen' },
    { week: 4, title: 'Voltooien', description: 'Laatste sprint naar finish' }
  ];
  
  return (
    <div 
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: 'rgba(0,0,0,0.9)',
        zIndex: 9999,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '1rem',
        backdropFilter: 'blur(10px)'
      }}
      onClick={onClose}
    >
      <div 
        style={{
          width: '100%',
          maxWidth: '600px',
          maxHeight: '90vh',
          background: '#1a1a1a',
          borderRadius: '24px',
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column'
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div style={{
          background: 'linear-gradient(135deg, #dc2626 0%, #ef4444 100%)',
          padding: '2rem',
          position: 'relative'
        }}>
          <button
            onClick={onClose}
            style={{
              position: 'absolute',
              top: '1rem',
              right: '1rem',
              background: 'rgba(0,0,0,0.2)',
              border: 'none',
              borderRadius: '50%',
              width: '32px',
              height: '32px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              color: '#fff'
            }}
          >
            <X size={18} />
          </button>
          
          <div style={{
            display: 'inline-flex',
            padding: '0.25rem 0.75rem',
            background: 'rgba(255,255,255,0.2)',
            borderRadius: '20px',
            marginBottom: '1rem'
          }}>
            <span style={{
              fontSize: '0.7rem',
              color: '#fff',
              fontWeight: '600',
              textTransform: 'uppercase',
              letterSpacing: '0.05em'
            }}>
              {challenge.category || 'FITNESS'}
            </span>
          </div>
          
          <h2 style={{
            fontSize: '1.75rem',
            fontWeight: 'bold',
            color: '#fff',
            marginBottom: '0.5rem'
          }}>
            {challenge.name}
          </h2>
          
          <p style={{
            color: 'rgba(255,255,255,0.9)',
            fontSize: '0.95rem'
          }}>
            {challenge.subtitle}
          </p>
        </div>
        
        {/* Content */}
        <div style={{
          flex: 1,
          overflowY: 'auto',
          padding: '1.5rem'
        }}>
          {/* Stats Grid */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            gap: '1rem',
            marginBottom: '2rem'
          }}>
            <div style={{
              background: 'rgba(0, 0, 0, 0.4)',
              borderRadius: '12px',
              padding: '1rem',
              textAlign: 'center',
              border: '1px solid rgba(255,255,255,0.05)'
            }}>
              <Calendar size={20} style={{ color: '#ef4444', marginBottom: '0.5rem' }} />
              <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#fff' }}>
                {challenge.duration_days || 30}
              </div>
              <div style={{ fontSize: '0.65rem', color: 'rgba(255,255,255,0.5)', textTransform: 'uppercase' }}>
                Dagen
              </div>
            </div>
            
            <div style={{
              background: 'rgba(0, 0, 0, 0.4)',
              borderRadius: '12px',
              padding: '1rem',
              textAlign: 'center',
              border: '1px solid rgba(255,255,255,0.05)'
            }}>
              <Award size={20} style={{ color: '#f59e0b', marginBottom: '0.5rem' }} />
              <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#fff' }}>
                {challenge.base_points || 200}
              </div>
              <div style={{ fontSize: '0.65rem', color: 'rgba(255,255,255,0.5)', textTransform: 'uppercase' }}>
                Punten
              </div>
            </div>
            
            <div style={{
              background: 'rgba(0, 0, 0, 0.4)',
              borderRadius: '12px',
              padding: '1rem',
              textAlign: 'center',
              border: '1px solid rgba(255,255,255,0.05)'
            }}>
              <Users size={20} style={{ color: '#10b981', marginBottom: '0.5rem' }} />
              <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#fff' }}>
                {challenge.participants || 234}
              </div>
              <div style={{ fontSize: '0.65rem', color: 'rgba(255,255,255,0.5)', textTransform: 'uppercase' }}>
                Deelnemers
              </div>
            </div>
          </div>
          
          {/* Difficulty Badge */}
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '1rem',
            marginBottom: '2rem'
          }}>
            <span style={{
              fontSize: '0.75rem',
              color: 'rgba(255,255,255,0.5)',
              textTransform: 'uppercase',
              letterSpacing: '0.1em'
            }}>
              Moeilijkheidsgraad
            </span>
            <span style={{
              padding: '0.35rem 1rem',
              background: `${getDifficultyColor(challenge.difficulty)}20`,
              color: getDifficultyColor(challenge.difficulty),
              borderRadius: '20px',
              fontSize: '0.75rem',
              fontWeight: '600',
              textTransform: 'uppercase'
            }}>
              {challenge.difficulty || 'Gemiddeld'}
            </span>
          </div>
          
          {/* Description */}
          <div style={{ marginBottom: '2rem' }}>
            <h3 style={{
              fontSize: '0.75rem',
              color: 'rgba(255,255,255,0.5)',
              textTransform: 'uppercase',
              letterSpacing: '0.1em',
              marginBottom: '1rem'
            }}>
              Over deze challenge
            </h3>
            <p style={{
              color: 'rgba(255,255,255,0.7)',
              lineHeight: 1.6,
              fontSize: '0.9rem'
            }}>
              {challenge.description || 'Push jezelf naar nieuwe hoogtes met deze intensieve challenge. Ontwikkel discipline, bouw kracht op en bereik je doelen stap voor stap.'}
            </p>
          </div>
          
          {/* Milestones */}
          <div>
            <h3 style={{
              fontSize: '0.75rem',
              color: 'rgba(255,255,255,0.5)',
              textTransform: 'uppercase',
              letterSpacing: '0.1em',
              marginBottom: '1rem'
            }}>
              Weekdoelen
            </h3>
            
            <div style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '0.75rem'
            }}>
              {milestones.map((milestone, index) => (
                <div key={index} style={{
                  display: 'flex',
                  gap: '1rem',
                  padding: '1rem',
                  background: 'rgba(0, 0, 0, 0.3)',
                  borderRadius: '12px',
                  border: '1px solid rgba(255,255,255,0.05)'
                }}>
                  <div style={{
                    width: '40px',
                    height: '40px',
                    borderRadius: '8px',
                    background: 'rgba(239, 68, 68, 0.1)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: '#ef4444',
                    fontWeight: 'bold',
                    flexShrink: 0
                  }}>
                    W{index + 1}
                  </div>
                  <div>
                    <div style={{
                      fontWeight: '600',
                      color: '#fff',
                      marginBottom: '0.25rem',
                      fontSize: '0.9rem'
                    }}>
                      {milestone.title}
                    </div>
                    <div style={{
                      fontSize: '0.75rem',
                      color: 'rgba(255,255,255,0.5)'
                    }}>
                      {milestone.description}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        {/* Footer */}
        <div style={{
          padding: '1.5rem',
          borderTop: '1px solid rgba(255,255,255,0.05)'
        }}>
          {!isActive ? (
            <button
              onClick={onStart}
              style={{
                width: '100%',
                padding: '1rem',
                background: 'linear-gradient(135deg, #dc2626 0%, #ef4444 100%)',
                border: 'none',
                borderRadius: '12px',
                color: '#fff',
                fontSize: '1rem',
                fontWeight: '600',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '0.5rem',
                transition: 'all 0.2s ease'
              }}
            >
              Start Challenge
              <ChevronRight size={18} />
            </button>
          ) : (
            <div style={{
              padding: '1rem',
              background: 'rgba(16, 185, 129, 0.1)',
              borderRadius: '12px',
              textAlign: 'center',
              color: '#10b981',
              border: '1px solid rgba(16, 185, 129, 0.2)',
              fontWeight: '600'
            }}>
              Deze challenge is al actief
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
