import React, { useState } from 'react';
import {
  Calendar, Clock, Video, Lock, CheckCircle, 
  ChevronRight, Trophy, ChevronDown, Info, Eye, Headphones
} from 'lucide-react';
import { callTypeConfig } from '../constants/callTypes';

export default function CallCard({ call, index, handleBookCall }) {
  const [isHovered, setIsHovered] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  
  const isMobile = window.innerWidth <= 768;
  const status = call.status || 'locked';
  const isClickable = status === 'available';
  const config = callTypeConfig[call.call_number] || callTypeConfig[1];
  const IconComponent = config.icon;

  const renderProgressRing = (progress, color, size = 80) => {
    const circumference = 2 * Math.PI * 35;
    const strokeDashoffset = circumference - (progress / 100) * circumference;
    
    return (
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        <circle
          cx={size/2}
          cy={size/2}
          r="35"
          stroke="rgba(255,255,255,0.1)"
          strokeWidth="6"
          fill="none"
        />
        <circle
          cx={size/2}
          cy={size/2}
          r="35"
          stroke={color}
          strokeWidth="6"
          fill="none"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          style={{ 
            transition: 'stroke-dashoffset 1s cubic-bezier(0.4, 0, 0.2, 1)',
            filter: `drop-shadow(0 0 10px ${color}66)`
          }}
        />
      </svg>
    );
  };

  return (
    <div
      style={{
        background: status === 'completed' 
          ? config.darkGradient
          : status === 'scheduled'
          ? 'linear-gradient(135deg, rgba(59, 130, 246, 0.15) 0%, rgba(59, 130, 246, 0.05) 100%)'
          : status === 'available'
          ? config.darkGradient
          : 'rgba(0, 0, 0, 0.4)',
        backdropFilter: 'blur(10px)',
        borderRadius: isMobile ? '14px' : '18px',
        padding: isMobile ? '1.25rem' : '1.5rem',
        border: status === 'available' 
          ? `2px solid ${config.color}`
          : status === 'completed'
          ? `2px solid ${config.color}66`
          : '1px solid rgba(255, 255, 255, 0.1)',
        cursor: isClickable || isExpanded ? 'pointer' : 'default',
        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
        transform: isHovered && !isMobile ? 'translateY(-8px) scale(1.02)' : 'translateY(0) scale(1)',
        boxShadow: isHovered 
          ? `0 20px 40px ${config.color}33, 0 0 60px ${config.color}22`
          : status === 'available'
          ? `0 10px 30px rgba(0, 0, 0, 0.3), 0 0 40px ${config.color}11`
          : '0 4px 20px rgba(0, 0, 0, 0.3)',
        position: 'relative',
        overflow: 'hidden',
        touchAction: 'manipulation',
        WebkitTapHighlightColor: 'transparent'
      }}
      onMouseEnter={() => !isMobile && setIsHovered(true)}
      onMouseLeave={() => !isMobile && setIsHovered(false)}
      onClick={() => {
        if (isClickable) {
          handleBookCall(call);
        } else if (status !== 'locked') {
          setIsExpanded(!isExpanded);
        }
      }}
      onTouchStart={(e) => {
        if (isMobile && (isClickable || status !== 'locked')) {
          e.currentTarget.style.transform = 'scale(0.98)';
        }
      }}
      onTouchEnd={(e) => {
        if (isMobile) {
          e.currentTarget.style.transform = 'scale(1)';
        }
      }}
    >
      {/* Animated Glow Background */}
      {status === 'available' && (
        <div style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          width: '200%',
          height: '200%',
          background: `radial-gradient(circle, ${config.color}33 0%, transparent 60%)`,
          animation: 'glow 4s ease-in-out infinite',
          pointerEvents: 'none'
        }} />
      )}

      {/* Card Header */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        marginBottom: '1rem',
        position: 'relative',
        zIndex: 1
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: isMobile ? '0.65rem' : '0.875rem'
        }}>
          <div style={{
            width: isMobile ? '42px' : '48px',
            height: isMobile ? '42px' : '48px',
            borderRadius: '12px',
            background: status === 'completed' || status === 'available'
              ? config.gradient
              : status === 'scheduled'
              ? 'linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)'
              : 'rgba(255, 255, 255, 0.1)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: status === 'locked' ? 'rgba(255, 255, 255, 0.4)' : '#fff',
            boxShadow: status !== 'locked' ? '0 8px 20px rgba(0, 0, 0, 0.3)' : 'none',
            position: 'relative'
          }}>
            <IconComponent size={isMobile ? 18 : 22} />
            {status === 'available' && (
              <div style={{
                position: 'absolute',
                top: '-3px',
                right: '-3px',
                width: '10px',
                height: '10px',
                background: '#10b981',
                borderRadius: '50%',
                animation: 'pulse 2s infinite'
              }} />
            )}
          </div>
          
          <div>
            <div style={{
              color: config.color,
              fontSize: isMobile ? '0.65rem' : '0.7rem',
              fontWeight: '600',
              textTransform: 'uppercase',
              letterSpacing: '0.05em',
              marginBottom: '0.2rem'
            }}>
              Call #{call.call_number}
            </div>
            <div style={{
              color: '#fff',
              fontWeight: '600',
              fontSize: isMobile ? '0.95rem' : '1.05rem'
            }}>
              {config.name}
            </div>
          </div>
        </div>

        {/* Progress Ring for completed calls */}
        {status === 'completed' && !isMobile && (
          <div style={{ position: 'relative' }}>
            {renderProgressRing(100, config.color, 36)}
            <CheckCircle 
              size={14} 
              style={{ 
                position: 'absolute',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                color: config.color
              }} 
            />
          </div>
        )}
      </div>

      {/* Card Description */}
      <p style={{
        color: 'rgba(255, 255, 255, 0.7)',
        fontSize: isMobile ? '0.8rem' : '0.85rem',
        marginBottom: '0.875rem',
        lineHeight: '1.45',
        position: 'relative',
        zIndex: 1
      }}>
        {config.description}
      </p>

      {/* Card Footer / Status */}
      <div style={{
        marginTop: 'auto',
        paddingTop: '0.875rem',
        borderTop: '1px solid rgba(255, 255, 255, 0.1)',
        position: 'relative',
        zIndex: 1
      }}>
        {status === 'locked' && (
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '0.4rem',
            color: 'rgba(255, 255, 255, 0.5)',
            fontSize: isMobile ? '0.75rem' : '0.8rem'
          }}>
            <Lock size={14} />
            <span>Voltooi eerst call #{call.call_number - 1}</span>
          </div>
        )}
        
        {status === 'available' && (
          <button
            style={{
              width: '100%',
              padding: isMobile ? '0.7rem' : '0.8rem',
              background: config.gradient,
              border: 'none',
              borderRadius: '10px',
              color: '#fff',
              fontWeight: '700',
              fontSize: isMobile ? '0.85rem' : '0.9rem',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '0.4rem',
              transition: 'all 0.3s ease',
              boxShadow: `0 4px 15px ${config.color}44`,
              touchAction: 'manipulation',
              WebkitTapHighlightColor: 'transparent'
            }}
            onMouseEnter={(e) => {
              if (!isMobile) {
                e.stopPropagation();
                e.currentTarget.style.transform = 'scale(1.05)';
                e.currentTarget.style.boxShadow = `0 8px 25px ${config.color}66`;
              }
            }}
            onMouseLeave={(e) => {
              if (!isMobile) {
                e.stopPropagation();
                e.currentTarget.style.transform = 'scale(1)';
                e.currentTarget.style.boxShadow = `0 4px 15px ${config.color}44`;
              }
            }}
          >
            <Calendar size={14} />
            Plan deze call
            <ChevronRight size={14} />
          </button>
        )}
        
        {status === 'scheduled' && (
          <div>
            {call.scheduled_date ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem' }}>
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.4rem',
                  color: '#3b82f6',
                  fontSize: isMobile ? '0.8rem' : '0.85rem',
                  fontWeight: '500',
                  flexWrap: 'wrap'
                }}>
                  <Clock size={14} />
                  <span>
                    {new Date(call.scheduled_date).toLocaleDateString('nl-NL', {
                      weekday: 'short',
                      day: 'numeric',
                      month: 'long'
                    })}
                    {!isMobile && ` ${new Date(call.scheduled_date).toLocaleTimeString('nl-NL', {
                      hour: '2-digit',
                      minute: '2-digit'
                    })}`}
                  </span>
                </div>
                
                {call.zoom_link && (
                  <a
                    href={call.zoom_link}
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '0.4rem',
                      padding: isMobile ? '0.6rem' : '0.65rem',
                      background: 'linear-gradient(135deg, rgba(59, 130, 246, 0.2) 0%, rgba(59, 130, 246, 0.1) 100%)',
                      border: '1px solid rgba(59, 130, 246, 0.3)',
                      borderRadius: '8px',
                      color: '#3b82f6',
                      fontWeight: '600',
                      fontSize: isMobile ? '0.8rem' : '0.85rem',
                      textDecoration: 'none',
                      transition: 'all 0.3s ease',
                      touchAction: 'manipulation',
                      WebkitTapHighlightColor: 'transparent'
                    }}
                    onClick={(e) => e.stopPropagation()}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.background = 'linear-gradient(135deg, rgba(59, 130, 246, 0.3) 0%, rgba(59, 130, 246, 0.2) 100%)';
                      if (!isMobile) e.currentTarget.style.transform = 'translateY(-2px)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = 'linear-gradient(135deg, rgba(59, 130, 246, 0.2) 0%, rgba(59, 130, 246, 0.1) 100%)';
                      if (!isMobile) e.currentTarget.style.transform = 'translateY(0)';
                    }}
                  >
                    <Video size={14} />
                    <span>Join Zoom</span>
                  </a>
                )}
              </div>
            ) : (
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.4rem',
                color: '#3b82f6',
                fontSize: isMobile ? '0.8rem' : '0.85rem'
              }}>
                <Calendar size={14} />
                <span>Ingepland - details volgen</span>
              </div>
            )}
          </div>
        )}
        
        {status === 'completed' && (
          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between'
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.4rem',
              color: config.color,
              fontSize: isMobile ? '0.8rem' : '0.85rem',
              fontWeight: '600'
            }}>
              <Trophy size={14} />
              <span>Voltooid</span>
            </div>
            <div style={{
              padding: '0.2rem 0.65rem',
              background: config.gradient,
              borderRadius: '16px',
              fontSize: isMobile ? '0.65rem' : '0.7rem',
              fontWeight: '700',
              color: '#fff'
            }}>
              +50 XP
            </div>
          </div>
        )}

        {/* Expandable section */}
        {(status === 'completed' || status === 'scheduled') && !isClickable && (
          <div style={{
            marginTop: '0.4rem',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'rgba(255, 255, 255, 0.5)',
            fontSize: '0.7rem'
          }}>
            <ChevronDown 
              size={14} 
              style={{
                transform: isExpanded ? 'rotate(180deg)' : 'rotate(0)',
                transition: 'transform 0.3s ease'
              }}
            />
          </div>
        )}
      </div>

      {/* Expanded Content */}
      {isExpanded && (
        <div style={{
          marginTop: '0.875rem',
          paddingTop: '0.875rem',
          borderTop: `1px solid ${config.color}33`,
          animation: 'slideIn 0.3s ease'
        }}
        onClick={(e) => e.stopPropagation()}
        >
          <div style={{
            padding: isMobile ? '0.65rem' : '0.875rem',
            background: 'rgba(0, 0, 0, 0.3)',
            borderRadius: '8px'
          }}>
            <h4 style={{
              color: config.color,
              fontSize: isMobile ? '0.75rem' : '0.8rem',
              fontWeight: '600',
              marginBottom: '0.65rem',
              display: 'flex',
              alignItems: 'center',
              gap: '0.4rem'
            }}>
              <Info size={12} />
              Call Details
            </h4>
            
            {call.client_subject && (
              <p style={{
                color: 'rgba(255, 255, 255, 0.8)',
                fontSize: isMobile ? '0.75rem' : '0.8rem',
                lineHeight: '1.45'
              }}>
                {call.client_subject}
              </p>
            )}

            {status === 'completed' && (
              <div style={{
                marginTop: '0.875rem',
                display: 'flex',
                gap: '0.4rem'
              }}>
                <button style={{
                  flex: 1,
                  padding: isMobile ? '0.35rem' : '0.45rem',
                  background: config.darkGradient,
                  border: `1px solid ${config.color}33`,
                  borderRadius: '6px',
                  color: config.color,
                  fontSize: isMobile ? '0.65rem' : '0.7rem',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '0.25rem',
                  touchAction: 'manipulation',
                  WebkitTapHighlightColor: 'transparent'
                }}>
                  <Eye size={11} />
                  Notes
                </button>
                <button style={{
                  flex: 1,
                  padding: isMobile ? '0.35rem' : '0.45rem',
                  background: config.darkGradient,
                  border: `1px solid ${config.color}33`,
                  borderRadius: '6px',
                  color: config.color,
                  fontSize: isMobile ? '0.65rem' : '0.7rem',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '0.25rem',
                  touchAction: 'manipulation',
                  WebkitTapHighlightColor: 'transparent'
                }}>
                  <Headphones size={11} />
                  Recording
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
