// src/modules/shopping/ShoppingService.js
export default class ShoppingService {
  constructor(db) {
    this.db = db
    this.supabase = db.supabase
  }
  
  // Get active meal plan with shopping list
  async getActiveMealPlan(clientId) {
    try {
      const { data, error } = await this.supabase
        .from('client_meal_plans')
        .select('*')
        .eq('client_id', clientId)
        .eq('is_active', true)
        .single()
      
      if (error && error.code !== 'PGRST116') throw error
      
      console.log('✅ Active meal plan loaded:', data?.template_name)
      return data
    } catch (error) {
      console.error('❌ Failed to get active meal plan:', error)
      return null
    }
  }
  
  // Generate shopping list from week structure
  async generateShoppingList(weekStructure) {
    try {
      const ingredientMap = {}
      
      // Loop through all days and meals
      const days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']
      
      for (const day of days) {
        const dayMeals = weekStructure[day]
        if (!dayMeals) continue
        
        console.log(`🔍 Processing ${day}:`, dayMeals)
        
        // Process each meal slot
        const slots = ['breakfast', 'lunch', 'dinner', 'snacks']
        
        for (const slot of slots) {
          const mealData = dayMeals[slot]
          if (!mealData) continue
          
          // Handle snacks array or single meal
          const meals = Array.isArray(mealData) ? mealData : [mealData]
          
          for (const mealItem of meals) {
            // CRITICAL FIX: mealItem IS the meal ID string directly!
            let mealId = null
            
            // Check if it's a string (direct ID) or object
            if (typeof mealItem === 'string') {
              // It's already the meal ID
              mealId = mealItem.replace('_xl', '').replace('_xxl', '').replace('_l', '') // Remove size suffixes
            } else if (typeof mealItem === 'object') {
              // It's an object, try to get ID
              mealId = mealItem?.meal_id || mealItem?.id
            }
            
            if (!mealId) {
              console.log('⚠️ No meal ID found for:', mealItem)
              continue
            }
            
            console.log(`📦 Loading meal with ID: ${mealId}`)
            
            // Get full meal data with ingredients
            const fullMealData = await this.getMealWithIngredients(mealId)
            if (!fullMealData) {
              console.log('❌ Could not load meal data for ID:', mealId)
              continue
            }
            
            console.log(`✅ Loaded meal: ${fullMealData.name}, Ingredients:`, fullMealData.ingredients_list?.length || 0)
            
            // Process each ingredient
            if (fullMealData.ingredients_list && Array.isArray(fullMealData.ingredients_list)) {
              for (const ing of fullMealData.ingredients_list) {
                const key = ing.ingredient_id
                
                if (!ingredientMap[key]) {
                  // Get ingredient details
                  const ingredient = await this.getIngredientDetails(ing.ingredient_id)
                  
                  if (!ingredient) {
                    console.log('⚠️ Could not load ingredient:', ing.ingredient_id)
                    continue
                  }
                  
                  ingredientMap[key] = {
                    id: ing.ingredient_id,
                    name: ingredient.name || 'Unknown',
                    category: ingredient.category || 'Other',
                    totalAmount: 0,
                    unit: ing.unit || 'gram',
                    instances: [],
                    pricePerUnit: ingredient.price_per_unit || 0,
                    unitType: ingredient.unit_type || 'gram'
                  }
                }
                
                // Add this instance
                const amount = ing.amount || 0
                ingredientMap[key].totalAmount += amount
                ingredientMap[key].instances.push({
                  day,
                  meal: slot,
                  mealName: fullMealData.name,
                  amount: amount
                })
              }
            } else {
              console.log('⚠️ No ingredients list for meal:', fullMealData.name)
            }
          }
        }
      }
      
      // Convert to array and calculate costs
      const shoppingList = Object.values(ingredientMap).map(item => ({
        ...item,
        estimatedCost: this.calculateItemCost(item)
      }))
      
      // Sort by category
      shoppingList.sort((a, b) => {
        // First sort by category
        const categoryOrder = ['protein', 'carbs', 'vegetables', 'fats', 'dairy', 'fruit', 'other']
        const aIndex = categoryOrder.indexOf(a.category) !== -1 ? categoryOrder.indexOf(a.category) : 999
        const bIndex = categoryOrder.indexOf(b.category) !== -1 ? categoryOrder.indexOf(b.category) : 999
        
        if (aIndex !== bIndex) return aIndex - bIndex
        
        // Then alphabetically by name
        return a.name.localeCompare(b.name)
      })
      
      console.log(`✅ Generated shopping list with ${shoppingList.length} items`)
      
      return {
        items: shoppingList,
        totalCost: shoppingList.reduce((sum, item) => sum + item.estimatedCost, 0),
        itemCount: shoppingList.length,
        generatedAt: new Date().toISOString()
      }
    } catch (error) {
      console.error('❌ Failed to generate shopping list:', error)
      return {
        items: [],
        totalCost: 0,
        itemCount: 0,
        generatedAt: new Date().toISOString()
      }
    }
  }
  
  // Get meal with ingredients
  async getMealWithIngredients(mealId) {
    try {
      // Clean the meal ID (remove size suffixes if present)
      const cleanMealId = mealId.replace('_xl', '').replace('_xxl', '').replace('_l', '')
      
      const { data, error } = await this.supabase
        .from('ai_meals')
        .select('*')
        .eq('id', cleanMealId)
        .single()
      
      if (error) {
        console.error(`❌ Error fetching meal ${cleanMealId}:`, error)
        throw error
      }
      
      return data
    } catch (error) {
      console.error('❌ Failed to get meal:', error)
      return null
    }
  }
  
  // Get ingredient details
  async getIngredientDetails(ingredientId) {
    try {
      const { data, error } = await this.supabase
        .from('ai_ingredients')
        .select('*')
        .eq('id', ingredientId)
        .single()
      
      if (error) throw error
      return data
    } catch (error) {
      console.error('❌ Failed to get ingredient:', error)
      return null
    }
  }
  
  // Calculate item cost
  calculateItemCost(item) {
    if (!item.pricePerUnit) return 0
    
    // Convert to same unit for calculation
    let cost = 0
    
    if (item.unit === 'gram' && item.unitType === 'kg') {
      // Price is per kg, amount is in grams
      cost = (item.totalAmount / 1000) * item.pricePerUnit
    } else if (item.unit === 'ml' && item.unitType === 'liter') {
      // Price is per liter, amount is in ml
      cost = (item.totalAmount / 1000) * item.pricePerUnit
    } else if (item.unitType === 'piece') {
      // Price per piece
      cost = Math.ceil(item.totalAmount) * item.pricePerUnit
    } else {
      // Same unit or default
      cost = item.totalAmount * item.pricePerUnit
    }
    
    return Math.round(cost * 100) / 100 // Round to 2 decimals
  }
  
  // Save/update shopping progress
  async saveShoppingProgress(clientId, planId, progress) {
    try {
      const { data: existing } = await this.supabase
        .from('ai_shopping_progress')
        .select('id')
        .eq('client_id', clientId)
        .eq('plan_id', planId)
        .single()
      
      if (existing) {
        // Update existing
        const { error } = await this.supabase
          .from('ai_shopping_progress')
          .update({
            purchased_items: progress.checkedItems,
            purchased_count: Object.values(progress.checkedItems || {}).filter(Boolean).length,
            updated_at: new Date().toISOString()
          })
          .eq('id', existing.id)
        
        if (error) throw error
      } else {
        // Create new
        const { error } = await this.supabase
          .from('ai_shopping_progress')
          .insert({
            client_id: clientId,
            plan_id: planId,
            purchased_items: progress.checkedItems,
            purchased_count: Object.values(progress.checkedItems || {}).filter(Boolean).length,
            week_start: new Date().toISOString(),
            created_at: new Date().toISOString()
          })
        
        if (error) throw error
      }
      
      console.log('✅ Shopping progress saved')
      return true
    } catch (error) {
      console.error('❌ Failed to save shopping progress:', error)
      return false
    }
  }
  
  // Get shopping progress
  async getShoppingProgress(clientId, planId) {
    if (!planId) return null
    
    try {
      const { data, error } = await this.supabase
        .from('ai_shopping_progress')
        .select('*')
        .eq('client_id', clientId)
        .eq('plan_id', planId)
        .single()
      
      if (error && error.code !== 'PGRST116') throw error
      
      return data
    } catch (error) {
      console.error('❌ Failed to get shopping progress:', error)
      return null
    }
  }
  
  // Export shopping list as text
  generateExportText(shoppingList) {
    if (!shoppingList?.items) return ''
    
    let text = '🛒 MY ARC BOODSCHAPPENLIJST\n'
    text += '━━━━━━━━━━━━━━━━━━━\n\n'
    
    // Group by category with proper ordering
    const categoryOrder = {
      'protein': '🥩 EIWITTEN',
      'carbs': '🌾 KOOLHYDRATEN', 
      'vegetables': '🥬 GROENTEN',
      'fats': '🥑 VETTEN',
      'dairy': '🥛 ZUIVEL',
      'fruit': '🍎 FRUIT',
      'other': '📦 OVERIG'
    }
    
    const categories = {}
    shoppingList.items.forEach(item => {
      const cat = item.category || 'other'
      if (!categories[cat]) {
        categories[cat] = []
      }
      categories[cat].push(item)
    })
    
    // Generate text per category in order
    Object.keys(categoryOrder).forEach(catKey => {
      if (categories[catKey]) {
        text += `${categoryOrder[catKey]}\n`
        categories[catKey].forEach(item => {
          const amount = this.formatAmount(item.totalAmount, item.unit)
          const price = item.estimatedCost ? ` (€${item.estimatedCost.toFixed(2)})` : ''
          text += `□ ${item.name} - ${amount}${price}\n`
        })
        text += '\n'
      }
    })
    
    text += '━━━━━━━━━━━━━━━━━━━\n'
    text += `💰 Geschat totaal: €${shoppingList.totalCost?.toFixed(2) || '0.00'}\n`
    text += `📊 Totaal items: ${shoppingList.itemCount || 0}\n`
    text += `📅 Gegenereerd: ${new Date().toLocaleDateString('nl-NL')}`
    
    return text
  }
  
  // Format amount with unit
  formatAmount(amount, unit) {
    if (unit === 'gram') {
      if (amount >= 1000) {
        return `${(amount / 1000).toFixed(1)}kg`
      }
      return `${Math.round(amount)}g`
    }
    
    if (unit === 'ml') {
      if (amount >= 1000) {
        return `${(amount / 1000).toFixed(1)}L`
      }
      return `${Math.round(amount)}ml`
    }
    
    if (unit === 'stuks' || unit === 'pieces') {
      return `${Math.round(amount)} stuks`
    }
    
    return `${Math.round(amount)} ${unit}`
  }
  
  // Share via WhatsApp
  shareViaWhatsApp(text) {
    const encoded = encodeURIComponent(text)
    const url = `https://wa.me/?text=${encoded}`
    window.open(url, '_blank')
  }
  
  // Copy to clipboard
  async copyToClipboard(text) {
    try {
      await navigator.clipboard.writeText(text)
      return true
    } catch (error) {
      console.error('Failed to copy:', error)
      return false
    }
  }
}
