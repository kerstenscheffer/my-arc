// src/modules/ai-meal-generator/tabs/PlanBuilder.jsx
// TAB 3: Build & Generate AI Week Plan - FIXED WITH SELECTED INGREDIENTS

import { useState, useEffect } from 'react'
import { 
  Zap, Calendar, RefreshCw, Loader, CheckCircle,
  AlertCircle, TrendingUp, Clock, DollarSign, Info,
  ChevronLeft, ChevronRight, Shuffle, Lock, Brain,
  Target, Award, ShoppingCart, Ban, Heart
} from 'lucide-react'

export default function PlanBuilder({
  db,
  selectedClient,
  clientProfile,
  dailyTargets,
  mealsPerDay,
  forcedMeals,
  excludedIngredients,
  selectedIngredients,  // FIXED: Now properly declared as prop
  mealPreferences,
  setGeneratedPlan,
  isMobile
}) {
  // States
  const [activeDay, setActiveDay] = useState(0)
  const [generating, setGenerating] = useState(false)
  const [generationStats, setGenerationStats] = useState(null)
  const [currentPlan, setCurrentPlan] = useState(null)
  const [planStats, setPlanStats] = useState(null)
  const [aiService, setAiService] = useState(null)
  
  const weekDays = [
    { id: 'monday', label: 'Ma', fullLabel: 'Maandag' },
    { id: 'tuesday', label: 'Di', fullLabel: 'Dinsdag' },
    { id: 'wednesday', label: 'Wo', fullLabel: 'Woensdag' },
    { id: 'thursday', label: 'Do', fullLabel: 'Donderdag' },
    { id: 'friday', label: 'Vr', fullLabel: 'Vrijdag' },
    { id: 'saturday', label: 'Za', fullLabel: 'Zaterdag' },
    { id: 'sunday', label: 'Zo', fullLabel: 'Zondag' }
  ]
  
  const mealSlots = [
    { id: 'breakfast', label: '🌅 Ontbijt', time: '08:00', color: '#f59e0b' },
    { id: 'lunch', label: '🥗 Lunch', time: '12:30', color: '#10b981' },
    { id: 'dinner', label: '🍽️ Diner', time: '18:30', color: '#3b82f6' },
    { id: 'snack1', label: '🥜 Snack 1', time: '10:30', color: '#ec4899' },
    { id: 'snack2', label: '🍎 Snack 2', time: '15:00', color: '#8b5cf6' },
    { id: 'snack3', label: '🥤 Snack 3', time: '20:00', color: '#f97316' }
  ].slice(0, mealsPerDay)
  
  // Initialize AI Service on mount
  useEffect(() => {
    const initService = async () => {
      try {
        // Get AI service instance from DatabaseService
        const service = await db.getAIMealPlanningService()
        setAiService(service)
      } catch (error) {
        console.error('Failed to initialize AI service:', error)
        // Fallback: try to create directly if method doesn't exist
        if (db.supabase) {
          const { getAIMealPlanningService } = await import('../AIMealPlanningService')
          const service = getAIMealPlanningService(db.supabase)
          setAiService(service)
        }
      }
    }
    
    if (selectedClient && db) {
      initService()
    }
  }, [selectedClient, db])
  
  // Debug logging
  useEffect(() => {
    console.log('📍 PlanBuilder received selectedIngredients:', selectedIngredients)
    console.log('🚫 PlanBuilder received excludedIngredients:', excludedIngredients)
  }, [selectedIngredients, excludedIngredients])
  
  // Generate AI Plan with REAL intelligence
  const handleGeneratePlan = async () => {
    if (!aiService) {
      console.error('AI Service not initialized')
      return
    }
    
    setGenerating(true)
    setGenerationStats({
      step: 'Initialiseren...',
      progress: 0
    })
    
    try {
      // Step 1: Ensure client profile exists
      setGenerationStats({
        step: 'AI profiel laden...',
        progress: 10
      })
      
      const aiProfile = await aiService.ensureClientProfile(selectedClient)
      
      // Override with current settings INCLUDING BOTH EXCLUDED AND SELECTED INGREDIENTS
      const updatedProfile = {
        ...aiProfile,
        target_calories: dailyTargets.calories,
        target_protein_g: dailyTargets.protein,
        target_carbs_g: dailyTargets.carbs,
        target_fat_g: dailyTargets.fat,
        meals_per_day: mealsPerDay,
        budget_tier: mealPreferences.budgetTier || 'moderate',
        allergies: excludedIngredients
          .filter(ing => ing.reason === 'allergie')
          .map(ing => ing.name || ing.id),
        excluded_ingredients: excludedIngredients.map(ing => ({
          id: ing.id,
          name: ing.name || ing.label || ing.id
        })),
        selected_ingredients: selectedIngredients.map(ing => ({  // FIXED: Added selected ingredients
          id: ing.id,
          name: ing.name || ing.label || ing.id
        }))
      }
      
      // Log both ingredient types for debugging
      console.log('✅ Selected ingredients being passed:', updatedProfile.selected_ingredients)
      console.log('🚫 Excluded ingredients being passed:', updatedProfile.excluded_ingredients)
      
      // Step 2: Load and score all meals
      setGenerationStats({
        step: `AI meals analyseren (${excludedIngredients.length} uitgesloten, ${selectedIngredients.length} gewenst)...`,
        progress: 20
      })
      
      const allMeals = await aiService.loadAIMeals()
      console.log(`Loaded ${allMeals.length} meals for AI analysis`)
      
      // Step 3: Score meals with AI AND INGREDIENT PREFERENCES
      setGenerationStats({
        step: `AI scoring toepassen (${selectedIngredients.length} gewenste, ${excludedIngredients.length} uitgesloten)...`,  // FIXED: Now selectedIngredients exists
        progress: 30
      })
      
      // Pass both excluded AND selected ingredients to scoring function
      const scoredMeals = aiService.scoreAllMeals(
        allMeals, 
        updatedProfile, 
        updatedProfile.excluded_ingredients,
        updatedProfile.selected_ingredients  // FIXED: Pass selected ingredients
      )
      
      const eligibleMeals = scoredMeals.filter(m => m.aiScore >= 0)
      console.log(`${eligibleMeals.length} meals passed AI scoring after exclusions`)
      
      // Log some top scoring meals for debugging
      const topMeals = eligibleMeals.slice(0, 5)
      console.log('Top 5 scoring meals:', topMeals.map(m => ({
        name: m.name,
        score: m.aiScore,
        hasSelectedIngredient: selectedIngredients.some(sel => {
          if (!m.ingredients_list) return false
          const mealIngredients = typeof m.ingredients_list === 'object'
            ? Object.keys(m.ingredients_list).map(i => i.toLowerCase())
            : []
          return mealIngredients.some(ing => ing.includes((sel.name || sel.id || '').toLowerCase()))
        })
      })))
      
      // Step 4: Generate week plan with AI optimization
      setGenerationStats({
        step: 'Weekplan genereren met AI...',
        progress: 50
      })
      
      const generatedPlan = await aiService.generateWeekPlan(updatedProfile, {
        days: 7,
        variationLevel: mealPreferences.avoidRepeats ? 'high' : 'medium',
        avoidDuplicates: mealPreferences.avoidRepeats,
        respectPortionLimits: true,
        forcedMeals: forcedMeals,
        excludedIngredients: updatedProfile.excluded_ingredients,
        selectedIngredients: updatedProfile.selected_ingredients  // FIXED: Pass to week generation
      })
      
      // Step 5: Integrate forced meals
      if (forcedMeals.length > 0) {
        setGenerationStats({
          step: 'Verplichte maaltijden toevoegen...',
          progress: 70
        })
        
        // Replace random meals with forced ones
        forcedMeals.forEach((forcedMeal, index) => {
          if (index < generatedPlan.weekPlan.length) {
            const dayIndex = index % 7
            const day = generatedPlan.weekPlan[dayIndex]
            
            // Find best slot based on meal timing
            const targetSlot = forcedMeal.timing?.includes('breakfast') ? 'breakfast' :
                              forcedMeal.timing?.includes('lunch') ? 'lunch' :
                              forcedMeal.timing?.includes('dinner') ? 'dinner' :
                              'snacks'
            
            if (targetSlot === 'snacks' && day.snacks.length > 0) {
              day.snacks[0] = { ...forcedMeal, forced: true }
            } else if (day[targetSlot]) {
              day[targetSlot] = { ...forcedMeal, forced: true }
            }
            
            // Recalculate totals
            day.totals = {
              kcal: 0,
              protein: 0,
              carbs: 0,
              fat: 0
            }
            
            const meals = [day.breakfast, day.lunch, day.dinner, ...day.snacks].filter(Boolean)
            meals.forEach(meal => {
              day.totals.kcal += meal.calories || 0
              day.totals.protein += meal.protein || 0
              day.totals.carbs += meal.carbs || 0
              day.totals.fat += meal.fat || 0
            })
          }
        })
      }
      
      // Step 6: Generate shopping list
      setGenerationStats({
        step: 'Boodschappenlijst genereren...',
        progress: 85
      })
      
      const shoppingList = aiService.generateShoppingList(generatedPlan.weekPlan)
      
      // Step 7: Finalize
      setGenerationStats({
        step: 'Plan voltooien...',
        progress: 95
      })
      
      // Store the plan
      setCurrentPlan(generatedPlan)
      setPlanStats({
        ...generatedPlan.stats,
        shoppingList,
        selectedIngredientsUsed: selectedIngredients.length,  // Track how many were used
        excludedIngredientsAvoided: excludedIngredients.length
      })
      
      // Pass to parent if needed
      if (setGeneratedPlan) {
        setGeneratedPlan(generatedPlan)
      }
      
      setGenerationStats({
        step: 'Voltooid! AI plan klaar.',
        progress: 100,
        success: true
      })
      
    } catch (error) {
      console.error('Error generating AI plan:', error)
      setGenerationStats({
        step: `Fout: ${error.message}`,
        progress: 0,
        error: true
      })
    } finally {
      setTimeout(() => {
        setGenerating(false)
        if (generationStats?.success) {
          setGenerationStats(null)
        }
      }, 2000)
    }
  }
  
  // Get current day's meals
  const getCurrentDayMeals = () => {
    if (!currentPlan) return []
    
    const day = currentPlan.weekPlan[activeDay]
    if (!day) return []
    
    const meals = []
    
    if (day.breakfast) {
      meals.push({
        slot: 'breakfast',
        ...mealSlots.find(s => s.id === 'breakfast'),
        meal: day.breakfast
      })
    }
    
    if (day.lunch) {
      meals.push({
        slot: 'lunch',
        ...mealSlots.find(s => s.id === 'lunch'),
        meal: day.lunch
      })
    }
    
    if (day.dinner) {
      meals.push({
        slot: 'dinner',
        ...mealSlots.find(s => s.id === 'dinner'),
        meal: day.dinner
      })
    }
    
    day.snacks?.forEach((snack, index) => {
      if (snack) {
        meals.push({
          slot: `snack${index + 1}`,
          ...mealSlots.find(s => s.id === `snack${index + 1}`) || {
            label: `🥜 Snack ${index + 1}`,
            time: '15:00',
            color: '#ec4899'
          },
          meal: snack
        })
      }
    })
    
    return meals
  }
  
  // Get current day totals
  const getCurrentDayTotals = () => {
    if (!currentPlan) return { kcal: 0, protein: 0, carbs: 0, fat: 0 }
    return currentPlan.weekPlan[activeDay]?.totals || { kcal: 0, protein: 0, carbs: 0, fat: 0 }
  }
  
  // Get current day accuracy
  const getCurrentDayAccuracy = () => {
    if (!currentPlan) return { total: 0, calories: 0, protein: 0 }
    return currentPlan.weekPlan[activeDay]?.accuracy || { total: 0, calories: 0, protein: 0 }
  }
  
  if (!selectedClient) {
    return (
      <div style={{
        textAlign: 'center',
        padding: '3rem',
        color: 'rgba(255,255,255,0.5)'
      }}>
        <Calendar size={48} style={{ marginBottom: '1rem', opacity: 0.3 }} />
        <p>Selecteer eerst een client en stel voorkeuren in</p>
      </div>
    )
  }
  
  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      gap: isMobile ? '1rem' : '1.5rem'
    }}>
      {/* Header */}
      <div>
        <h2 style={{
          fontSize: isMobile ? '1.25rem' : '1.5rem',
          fontWeight: '700',
          color: '#fff',
          marginBottom: '0.5rem',
          display: 'flex',
          alignItems: 'center',
          gap: '0.5rem'
        }}>
          <Brain size={24} style={{ color: '#10b981' }} />
          AI Week Plan Generator
        </h2>
        <p style={{
          fontSize: isMobile ? '0.875rem' : '0.95rem',
          color: 'rgba(255,255,255,0.6)'
        }}>
          Intelligente weekplanning met AI optimalisatie en scoring
        </p>
      </div>
      
      {/* Configuration Overview */}
      <div style={{
        background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.05) 0%, rgba(16, 185, 129, 0.02) 100%)',
        borderRadius: '12px',
        border: '1px solid rgba(16, 185, 129, 0.2)',
        padding: isMobile ? '1rem' : '1.25rem'
      }}>
        <h3 style={{
          fontSize: isMobile ? '1rem' : '1.1rem',
          fontWeight: '600',
          color: '#10b981',
          marginBottom: '1rem',
          display: 'flex',
          alignItems: 'center',
          gap: '0.5rem'
        }}>
          <Target size={18} />
          AI Configuratie
        </h3>
        
        <div style={{
          display: 'grid',
          gridTemplateColumns: isMobile ? '1fr' : 'repeat(2, 1fr)',
          gap: '1rem'
        }}>
          {/* Client Profile */}
          <div style={{
            padding: '0.75rem',
            background: 'rgba(255,255,255,0.03)',
            borderRadius: '8px',
            border: '1px solid rgba(255,255,255,0.1)'
          }}>
            <div style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.5)', marginBottom: '0.5rem' }}>
              Client Profiel
            </div>
            <div style={{ fontSize: '0.95rem', color: '#fff', fontWeight: '600' }}>
              {selectedClient.first_name} {selectedClient.last_name}
            </div>
            <div style={{ fontSize: '0.85rem', color: '#10b981', marginTop: '0.25rem' }}>
              {clientProfile?.primary_goal === 'muscle_gain' ? '💪 Spieropbouw' :
               clientProfile?.primary_goal === 'fat_loss' ? '🔥 Vetverlies' :
               clientProfile?.primary_goal === 'maintain' ? '⚖️ Onderhoud' : 
               '🎯 Algemeen'}
            </div>
          </div>
          
          {/* Daily Targets */}
          <div style={{
            padding: '0.75rem',
            background: 'rgba(255,255,255,0.03)',
            borderRadius: '8px',
            border: '1px solid rgba(255,255,255,0.1)'
          }}>
            <div style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.5)', marginBottom: '0.5rem' }}>
              Dagelijkse Targets
            </div>
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(4, 1fr)',
              gap: '0.5rem',
              fontSize: '0.8rem'
            }}>
              <div>
                <strong style={{ color: '#fff' }}>{dailyTargets.calories}</strong>
                <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: '0.65rem' }}>kcal</div>
              </div>
              <div>
                <strong style={{ color: '#10b981' }}>{dailyTargets.protein}g</strong>
                <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: '0.65rem' }}>eiwit</div>
              </div>
              <div>
                <strong style={{ color: '#3b82f6' }}>{dailyTargets.carbs}g</strong>
                <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: '0.65rem' }}>carbs</div>
              </div>
              <div>
                <strong style={{ color: '#f59e0b' }}>{dailyTargets.fat}g</strong>
                <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: '0.65rem' }}>vet</div>
              </div>
            </div>
          </div>
          
          {/* AI Settings */}
          <div style={{
            padding: '0.75rem',
            background: 'rgba(255,255,255,0.03)',
            borderRadius: '8px',
            border: '1px solid rgba(255,255,255,0.1)'
          }}>
            <div style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.5)', marginBottom: '0.5rem' }}>
              AI Optimalisatie
            </div>
            <div style={{ fontSize: '0.8rem', color: '#fff' }}>
              {mealPreferences.avoidRepeats && '✓ Maximum variatie'}
            </div>
            <div style={{ fontSize: '0.8rem', color: '#fff' }}>
              {mealPreferences.optimizeShopping && '✓ Efficiënte boodschappen'}
            </div>
            <div style={{ fontSize: '0.8rem', color: '#10b981' }}>
              ✓ AI Scoring Engine Actief
            </div>
          </div>
          
          {/* Constraints */}
          <div style={{
            padding: '0.75rem',
            background: 'rgba(255,255,255,0.03)',
            borderRadius: '8px',
            border: '1px solid rgba(255,255,255,0.1)'
          }}>
            <div style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.5)', marginBottom: '0.5rem' }}>
              Beperkingen & Voorkeuren
            </div>
            <div style={{ fontSize: '0.8rem', color: '#f59e0b' }}>
              {forcedMeals.length} verplichte maaltijden
            </div>
            <div style={{ fontSize: '0.8rem', color: '#10b981' }}>
              {selectedIngredients.length} gewenste ingrediënten
            </div>
            <div style={{ fontSize: '0.8rem', color: '#ef4444' }}>
              {excludedIngredients.length} uitgesloten ingrediënten
            </div>
            <div style={{ fontSize: '0.8rem', color: '#8b5cf6' }}>
              {mealsPerDay} maaltijden per dag
            </div>
          </div>
        </div>
        
        {/* Selected Ingredients Display - FIXED: Now shows selected ingredients */}
        {selectedIngredients.length > 0 && (
          <div style={{
            marginTop: '1rem',
            paddingTop: '1rem',
            borderTop: '1px solid rgba(255,255,255,0.1)'
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem',
              marginBottom: '0.5rem'
            }}>
              <Heart size={16} style={{ color: '#10b981' }} />
              <span style={{
                fontSize: '0.85rem',
                color: '#10b981',
                fontWeight: '600'
              }}>
                Gewenste Ingrediënten ({selectedIngredients.length})
              </span>
            </div>
            <div style={{
              display: 'flex',
              flexWrap: 'wrap',
              gap: '0.4rem'
            }}>
              {selectedIngredients.slice(0, 10).map((ing, index) => (
                <span key={index} style={{
                  padding: '0.25rem 0.5rem',
                  background: 'rgba(16, 185, 129, 0.1)',
                  border: '1px solid rgba(16, 185, 129, 0.3)',
                  borderRadius: '6px',
                  fontSize: '0.7rem',
                  color: 'rgba(255,255,255,0.8)'
                }}>
                  {ing.name || ing.label || ing.id}
                </span>
              ))}
              {selectedIngredients.length > 10 && (
                <span style={{
                  padding: '0.25rem 0.5rem',
                  background: 'rgba(16, 185, 129, 0.05)',
                  borderRadius: '6px',
                  fontSize: '0.7rem',
                  color: 'rgba(255,255,255,0.5)'
                }}>
                  +{selectedIngredients.length - 10} meer...
                </span>
              )}
            </div>
          </div>
        )}
        
        {/* Excluded Ingredients Display */}
        {excludedIngredients.length > 0 && (
          <div style={{
            marginTop: '1rem',
            paddingTop: '1rem',
            borderTop: '1px solid rgba(255,255,255,0.1)'
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem',
              marginBottom: '0.5rem'
            }}>
              <Ban size={16} style={{ color: '#ef4444' }} />
              <span style={{
                fontSize: '0.85rem',
                color: '#ef4444',
                fontWeight: '600'
              }}>
                Uitgesloten Ingrediënten ({excludedIngredients.length})
              </span>
            </div>
            <div style={{
              display: 'flex',
              flexWrap: 'wrap',
              gap: '0.4rem'
            }}>
              {excludedIngredients.slice(0, 10).map((ing, index) => (
                <span key={index} style={{
                  padding: '0.25rem 0.5rem',
                  background: 'rgba(239, 68, 68, 0.1)',
                  border: '1px solid rgba(239, 68, 68, 0.3)',
                  borderRadius: '6px',
                  fontSize: '0.7rem',
                  color: 'rgba(255,255,255,0.8)'
                }}>
                  {ing.name || ing.label || ing.id}
                </span>
              ))}
              {excludedIngredients.length > 10 && (
                <span style={{
                  padding: '0.25rem 0.5rem',
                  background: 'rgba(239, 68, 68, 0.05)',
                  borderRadius: '6px',
                  fontSize: '0.7rem',
                  color: 'rgba(255,255,255,0.5)'
                }}>
                  +{excludedIngredients.length - 10} meer...
                </span>
              )}
            </div>
          </div>
        )}
      </div>
      
      {/* Generate Button */}
      {!currentPlan && (
        <button
          onClick={handleGeneratePlan}
          disabled={generating || !aiService}
          style={{
            padding: isMobile ? '1rem' : '1.25rem',
            background: generating || !aiService
              ? 'linear-gradient(135deg, #6b7280 0%, #4b5563 100%)'
              : 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
            border: 'none',
            borderRadius: '12px',
            color: '#fff',
            fontSize: isMobile ? '1rem' : '1.1rem',
            fontWeight: '700',
            cursor: generating || !aiService ? 'not-allowed' : 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '0.75rem',
            minHeight: '56px',
            touchAction: 'manipulation',
            transition: 'all 0.3s ease',
            boxShadow: generating || !aiService
              ? 'none'
              : '0 10px 25px rgba(16, 185, 129, 0.25)'
          }}
        >
          {generating ? (
            <>
              <Loader size={24} style={{ animation: 'spin 1s linear infinite' }} />
              AI Plan Genereren...
            </>
          ) : !aiService ? (
            <>
              <AlertCircle size={24} />
              AI Service Laden...
            </>
          ) : (
            <>
              <Brain size={24} />
              Genereer AI Week Plan
            </>
          )}
        </button>
      )}
      
      {/* Generation Progress */}
      {generating && generationStats && (
        <div style={{
          background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.1) 0%, rgba(16, 185, 129, 0.05) 100%)',
          borderRadius: '12px',
          border: '1px solid rgba(16, 185, 129, 0.3)',
          padding: isMobile ? '1rem' : '1.25rem'
        }}>
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '0.75rem'
          }}>
            <span style={{
              fontSize: '0.9rem',
              color: generationStats.error ? '#ef4444' : 
                     generationStats.success ? '#10b981' : '#f59e0b',
              fontWeight: '600'
            }}>
              {generationStats.step}
            </span>
            <span style={{
              fontSize: '0.85rem',
              color: 'rgba(255,255,255,0.6)'
            }}>
              {generationStats.progress}%
            </span>
          </div>
          
          <div style={{
            height: '8px',
            background: 'rgba(255,255,255,0.1)',
            borderRadius: '4px',
            overflow: 'hidden'
          }}>
            <div style={{
              height: '100%',
              width: `${generationStats.progress}%`,
              background: generationStats.error 
                ? 'linear-gradient(90deg, #ef4444, #dc2626)'
                : generationStats.success
                  ? 'linear-gradient(90deg, #10b981, #059669)'
                  : 'linear-gradient(90deg, #f59e0b, #d97706)',
              transition: 'width 0.5s ease',
              borderRadius: '4px'
            }} />
          </div>
        </div>
      )}
      
      {/* Week Plan Display - REST OF COMPONENT UNCHANGED */}
      {currentPlan && (
        <>
          {/* AI Stats */}
          <div style={{
            background: 'linear-gradient(135deg, rgba(139, 92, 246, 0.05) 0%, rgba(139, 92, 246, 0.02) 100%)',
            borderRadius: '12px',
            border: '1px solid rgba(139, 92, 246, 0.2)',
            padding: isMobile ? '1rem' : '1.25rem'
          }}>
            <h3 style={{
              fontSize: isMobile ? '0.95rem' : '1.05rem',
              fontWeight: '600',
              color: '#8b5cf6',
              marginBottom: '0.75rem',
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem'
            }}>
              <Award size={18} />
              AI Plan Statistieken
            </h3>
            
            <div style={{
              display: 'grid',
              gridTemplateColumns: isMobile ? 'repeat(2, 1fr)' : 'repeat(4, 1fr)',
              gap: '1rem'
            }}>
              <div>
                <div style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.5)' }}>Gem. Accuracy</div>
                <div style={{ fontSize: '1.25rem', fontWeight: '700', color: '#10b981' }}>
                  {currentPlan.stats?.averageAccuracy || 0}%
                </div>
              </div>
              <div>
                <div style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.5)' }}>Variatie Score</div>
                <div style={{ fontSize: '1.25rem', fontWeight: '700', color: '#f59e0b' }}>
                  {currentPlan.stats?.varietyScore || 0}%
                </div>
              </div>
              <div>
                <div style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.5)' }}>Compliance</div>
                <div style={{ fontSize: '1.25rem', fontWeight: '700', color: '#3b82f6' }}>
                  {currentPlan.stats?.complianceScore || 0}%
                </div>
              </div>
              <div>
                <div style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.5)' }}>AI Score</div>
                <div style={{ fontSize: '1.25rem', fontWeight: '700', color: '#8b5cf6' }}>
                  {currentPlan.aiAnalysis?.averageScore || 0}
                </div>
              </div>
            </div>
            
            {/* Ingredient Usage Stats */}
            {(planStats?.selectedIngredientsUsed > 0 || planStats?.excludedIngredientsAvoided > 0) && (
              <div style={{
                marginTop: '1rem',
                paddingTop: '1rem',
                borderTop: '1px solid rgba(255,255,255,0.1)',
                display: 'flex',
                gap: '2rem'
              }}>
                {planStats?.selectedIngredientsUsed > 0 && (
                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.5rem'
                  }}>
                    <Heart size={16} style={{ color: '#10b981' }} />
                    <span style={{ fontSize: '0.85rem', color: 'rgba(255,255,255,0.7)' }}>
                      {planStats.selectedIngredientsUsed} gewenste ingrediënten gebruikt
                    </span>
                  </div>
                )}
                {planStats?.excludedIngredientsAvoided > 0 && (
                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.5rem'
                  }}>
                    <Ban size={16} style={{ color: '#ef4444' }} />
                    <span style={{ fontSize: '0.85rem', color: 'rgba(255,255,255,0.7)' }}>
                      {planStats.excludedIngredientsAvoided} ingrediënten vermeden
                    </span>
                  </div>
                )}
              </div>
            )}
            
            {/* Budget Analysis */}
            {planStats?.shoppingList && (
              <div style={{
                marginTop: '1rem',
                paddingTop: '1rem',
                borderTop: '1px solid rgba(255,255,255,0.1)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between'
              }}>
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.5rem'
                }}>
                  <ShoppingCart size={16} style={{ color: '#10b981' }} />
                  <span style={{ fontSize: '0.85rem', color: 'rgba(255,255,255,0.7)' }}>
                    Geschatte kosten per week:
                  </span>
                </div>
                <span style={{ fontSize: '1rem', fontWeight: '600', color: '#10b981' }}>
                  €{planStats.shoppingList.totalCost}
                </span>
              </div>
            )}
          </div>
          
          {/* Day Navigation */}
          <div style={{
            background: 'rgba(255,255,255,0.03)',
            borderRadius: '12px',
            border: '1px solid rgba(255,255,255,0.1)',
            padding: isMobile ? '0.75rem' : '1rem'
          }}>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '1rem'
            }}>
              <button
                onClick={() => setActiveDay(Math.max(0, activeDay - 1))}
                disabled={activeDay === 0}
                style={{
                  padding: '0.5rem',
                  background: activeDay === 0 ? 'transparent' : 'rgba(255,255,255,0.05)',
                  border: '1px solid rgba(255,255,255,0.1)',
                  borderRadius: '8px',
                  color: activeDay === 0 ? 'rgba(255,255,255,0.3)' : '#fff',
                  cursor: activeDay === 0 ? 'not-allowed' : 'pointer',
                  minHeight: '44px',
                  minWidth: '44px',
                  touchAction: 'manipulation'
                }}
              >
                <ChevronLeft size={20} />
              </button>
              
              <h3 style={{
                fontSize: isMobile ? '1.1rem' : '1.25rem',
                fontWeight: '600',
                color: '#fff'
              }}>
                {weekDays[activeDay].fullLabel}
              </h3>
              
              <button
                onClick={() => setActiveDay(Math.min(6, activeDay + 1))}
                disabled={activeDay === 6}
                style={{
                  padding: '0.5rem',
                  background: activeDay === 6 ? 'transparent' : 'rgba(255,255,255,0.05)',
                  border: '1px solid rgba(255,255,255,0.1)',
                  borderRadius: '8px',
                  color: activeDay === 6 ? 'rgba(255,255,255,0.3)' : '#fff',
                  cursor: activeDay === 6 ? 'not-allowed' : 'pointer',
                  minHeight: '44px',
                  minWidth: '44px',
                  touchAction: 'manipulation'
                }}
              >
                <ChevronRight size={20} />
              </button>
            </div>
            
            {/* Day Dots */}
            <div style={{
              display: 'flex',
              justifyContent: 'center',
              gap: '0.5rem'
            }}>
              {weekDays.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setActiveDay(index)}
                  style={{
                    width: '8px',
                    height: '8px',
                    borderRadius: '50%',
                    background: index === activeDay 
                      ? '#10b981' 
                      : 'rgba(255,255,255,0.2)',
                    border: 'none',
                    cursor: 'pointer',
                    transition: 'all 0.3s ease'
                  }}
                />
              ))}
            </div>
          </div>
          
          {/* Day Meals */}
          <div style={{
            display: 'flex',
            flexDirection: 'column',
            gap: '0.75rem'
          }}>
            {getCurrentDayMeals().map((slot, index) => (
              <div key={index} style={{
                background: 'rgba(255,255,255,0.03)',
                borderRadius: '10px',
                border: slot.meal?.forced 
                  ? '1px solid rgba(245, 158, 11, 0.3)'
                  : '1px solid rgba(255,255,255,0.1)',
                padding: isMobile ? '0.75rem' : '1rem',
                position: 'relative'
              }}>
                {/* Forced Badge */}
                {slot.meal?.forced && (
                  <div style={{
                    position: 'absolute',
                    top: '-8px',
                    right: '10px',
                    background: '#f59e0b',
                    borderRadius: '4px',
                    padding: '2px 6px',
                    fontSize: '0.65rem',
                    fontWeight: '600',
                    color: '#fff',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '2px'
                  }}>
                    <Lock size={10} />
                    Verplicht
                  </div>
                )}
                
                {/* AI Score Badge */}
                {slot.meal?.aiScore > 0 && (
                  <div style={{
                    position: 'absolute',
                    top: '-8px',
                    left: '10px',
                    background: 'linear-gradient(135deg, #10b981, #059669)',
                    borderRadius: '4px',
                    padding: '2px 6px',
                    fontSize: '0.65rem',
                    fontWeight: '600',
                    color: '#fff'
                  }}>
                    AI: {slot.meal.aiScore}
                  </div>
                )}
                
                {/* Slot Header */}
                <div style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  marginBottom: '0.5rem'
                }}>
                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.5rem'
                  }}>
                    <Clock size={14} style={{ color: 'rgba(255,255,255,0.4)' }} />
                    <span style={{
                      fontSize: '0.8rem',
                      color: 'rgba(255,255,255,0.5)'
                    }}>
                      {slot.time}
                    </span>
                    <span style={{
                      fontSize: '0.9rem',
                      fontWeight: '600',
                      color: slot.color || '#fff'
                    }}>
                      {slot.label}
                    </span>
                  </div>
                </div>
                
                {/* Meal Info */}
                {slot.meal && (
                  <>
                    <h4 style={{
                      fontSize: isMobile ? '0.95rem' : '1.05rem',
                      fontWeight: '600',
                      color: '#fff',
                      marginBottom: '0.5rem'
                    }}>
                      {slot.meal.name}
                    </h4>
                    
                    {/* Macros */}
                    <div style={{
                      display: 'grid',
                      gridTemplateColumns: 'repeat(4, 1fr)',
                      gap: '0.5rem',
                      fontSize: '0.75rem',
                      paddingTop: '0.5rem',
                      borderTop: '1px solid rgba(255,255,255,0.05)'
                    }}>
                      <div>
                        <div style={{ color: 'rgba(255,255,255,0.4)' }}>kcal</div>
                        <strong style={{ color: '#fff' }}>
                          {Math.round(slot.meal.calories || 0)}
                        </strong>
                      </div>
                      <div>
                        <div style={{ color: 'rgba(255,255,255,0.4)' }}>eiwit</div>
                        <strong style={{ color: '#10b981' }}>
                          {Math.round(slot.meal.protein || 0)}g
                        </strong>
                      </div>
                      <div>
                        <div style={{ color: 'rgba(255,255,255,0.4)' }}>carbs</div>
                        <strong style={{ color: '#3b82f6' }}>
                          {Math.round(slot.meal.carbs || 0)}g
                        </strong>
                      </div>
                      <div>
                        <div style={{ color: 'rgba(255,255,255,0.4)' }}>vet</div>
                        <strong style={{ color: '#f59e0b' }}>
                          {Math.round(slot.meal.fat || 0)}g
                        </strong>
                      </div>
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
          
          {/* Day Totals & Accuracy */}
          <div style={{
            padding: '1rem',
            background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.05) 0%, rgba(16, 185, 129, 0.02) 100%)',
            borderRadius: '10px',
            border: '1px solid rgba(16, 185, 129, 0.2)'
          }}>
            <h4 style={{
              fontSize: '0.9rem',
              fontWeight: '600',
              color: '#10b981',
              marginBottom: '0.75rem'
            }}>
              Dag Analyse
            </h4>
            
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(2, 1fr)',
              gap: '1rem'
            }}>
              {/* Totals */}
              <div>
                <div style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.5)', marginBottom: '0.5rem' }}>
                  Totalen
                </div>
                <div style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(2, 1fr)',
                  gap: '0.5rem',
                  fontSize: '0.8rem'
                }}>
                  {(() => {
                    const totals = getCurrentDayTotals()
                    return (
                      <>
                        <div>
                          <span style={{ color: 'rgba(255,255,255,0.5)' }}>kcal: </span>
                          <strong style={{ 
                            color: Math.abs(totals.kcal - dailyTargets.calories) < 100 
                              ? '#10b981' : '#f59e0b' 
                          }}>
                            {Math.round(totals.kcal)}
                          </strong>
                        </div>
                        <div>
                          <span style={{ color: 'rgba(255,255,255,0.5)' }}>P: </span>
                          <strong style={{ 
                            color: totals.protein >= dailyTargets.protein * 0.9 
                              ? '#10b981' : '#f59e0b' 
                          }}>
                            {Math.round(totals.protein)}g
                          </strong>
                        </div>
                        <div>
                          <span style={{ color: 'rgba(255,255,255,0.5)' }}>C: </span>
                          <strong style={{ color: '#3b82f6' }}>
                            {Math.round(totals.carbs)}g
                          </strong>
                        </div>
                        <div>
                          <span style={{ color: 'rgba(255,255,255,0.5)' }}>F: </span>
                          <strong style={{ color: '#f59e0b' }}>
                            {Math.round(totals.fat)}g
                          </strong>
                        </div>
                      </>
                    )
                  })()}
                </div>
              </div>
              
              {/* Accuracy */}
              <div>
                <div style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.5)', marginBottom: '0.5rem' }}>
                  Nauwkeurigheid
                </div>
                <div style={{
                  fontSize: '1.5rem',
                  fontWeight: '700',
                  color: getCurrentDayAccuracy().total >= 90 ? '#10b981' :
                         getCurrentDayAccuracy().total >= 75 ? '#f59e0b' : '#ef4444'
                }}>
                  {getCurrentDayAccuracy().total}%
                </div>
                <div style={{
                  fontSize: '0.7rem',
                  color: 'rgba(255,255,255,0.5)'
                }}>
                  Cal: {getCurrentDayAccuracy().calories}% | 
                  Prot: {getCurrentDayAccuracy().protein}%
                </div>
              </div>
            </div>
          </div>
          
          {/* Regenerate Button */}
          <button
            onClick={handleGeneratePlan}
            disabled={generating}
            style={{
              padding: '0.875rem',
              background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.1) 0%, rgba(16, 185, 129, 0.05) 100%)',
              border: '1px solid rgba(16, 185, 129, 0.3)',
              borderRadius: '10px',
              color: '#10b981',
              fontSize: '0.95rem',
              fontWeight: '600',
              cursor: generating ? 'not-allowed' : 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '0.5rem',
              minHeight: '44px',
              touchAction: 'manipulation'
            }}
          >
            <RefreshCw size={18} />
            Regenereer met AI
          </button>
        </>
      )}
      
      {/* Info Box */}
      <div style={{
        padding: '1rem',
        background: 'linear-gradient(135deg, rgba(139, 92, 246, 0.05) 0%, rgba(139, 92, 246, 0.02) 100%)',
        borderRadius: '12px',
        border: '1px solid rgba(139, 92, 246, 0.2)'
      }}>
        <div style={{
          display: 'flex',
          gap: '0.75rem'
        }}>
          <Brain size={20} style={{ color: '#8b5cf6', flexShrink: 0, marginTop: '0.1rem' }} />
          <div style={{ fontSize: isMobile ? '0.85rem' : '0.9rem', color: 'rgba(255,255,255,0.7)' }}>
            <strong>AI Engine:</strong> Dit systeem gebruikt geavanceerde AI scoring om het perfecte 
            weekplan te genereren. Elke maaltijd wordt beoordeeld op goal alignment, macro fit, 
            voorkeuren, praktische aspecten en budget. <span style={{ color: '#10b981' }}>
            Gewenste ingrediënten krijgen +10 bonus punten</span>, <span style={{ color: '#ef4444' }}>
            uitgesloten ingrediënten worden automatisch gefilterd</span> en verplichte maaltijden 
            intelligent ingepland.
          </div>
        </div>
      </div>
      
      {/* CSS */}
      <style>{`
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  )
}
