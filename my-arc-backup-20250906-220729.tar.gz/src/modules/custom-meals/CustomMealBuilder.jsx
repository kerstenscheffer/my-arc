// src/modules/custom-meals/CustomMealBuilder.jsx
import React, { useState, useEffect } from 'react'
import { 
  Search, Plus, Minus, Save, X, Camera,
  Flame, Target, Zap, Droplets, Euro,
  ChefHat, Clock, AlertCircle, Check
} from 'lucide-react'

export default function CustomMealBuilder({ 
  isOpen, 
  onClose, 
  onSave,
  db,
  clientId 
}) {
  const isMobile = window.innerWidth <= 768
  
  // State
  const [mealName, setMealName] = useState('')
  const [searchTerm, setSearchTerm] = useState('')
  const [searchResults, setSearchResults] = useState([])
  const [selectedIngredients, setSelectedIngredients] = useState([])
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [activeCategory, setActiveCategory] = useState('all')
  const [instructions, setInstructions] = useState('')
  const [mealType, setMealType] = useState(['lunch'])
  const [savedMessage, setSavedMessage] = useState('')
  
  // Categories
  const categories = [
    { id: 'all', label: 'Alles', color: '#10b981' },
    { id: 'protein', label: 'Eiwit', color: '#8b5cf6' },
    { id: 'carbs', label: 'Koolhydraten', color: '#ef4444' },
    { id: 'fats', label: 'Vetten', color: '#3b82f6' },
    { id: 'vegetables', label: 'Groenten', color: '#10b981' },
    { id: 'fruit', label: 'Fruit', color: '#fbbf24' },
    { id: 'dairy', label: 'Zuivel', color: '#ec4899' }
  ]
  
  // Search ingredients
  const searchIngredients = async () => {
    if (searchTerm.length < 2) {
      setSearchResults([])
      return
    }
    
    setLoading(true)
    try {
      let query = db.supabase
        .from('ai_ingredients')
        .select('*')
        .ilike('name', `%${searchTerm}%`)
        .limit(20)
      
      if (activeCategory !== 'all') {
        query = query.eq('category', activeCategory)
      }
      
      const { data, error } = await query
      
      if (error) throw error
      setSearchResults(data || [])
    } catch (error) {
      console.error('Search error:', error)
      setSearchResults([])
    } finally {
      setLoading(false)
    }
  }
  
  // Search on term change
  useEffect(() => {
    const timer = setTimeout(() => {
      searchIngredients()
    }, 300)
    
    return () => clearTimeout(timer)
  }, [searchTerm, activeCategory])
  
  // Add ingredient
  const addIngredient = (ingredient) => {
    const existing = selectedIngredients.find(i => i.id === ingredient.id)
    if (existing) {
      // Update amount
      updateIngredientAmount(ingredient.id, existing.amount + 100)
    } else {
      // Add new
      setSelectedIngredients([...selectedIngredients, {
        ...ingredient,
        amount: ingredient.default_portion_gram || 100
      }])
    }
    setSearchTerm('')
    setSearchResults([])
  }
  
  // Update ingredient amount
  const updateIngredientAmount = (id, amount) => {
    if (amount <= 0) {
      removeIngredient(id)
      return
    }
    
    setSelectedIngredients(selectedIngredients.map(ing => 
      ing.id === id ? { ...ing, amount: Math.min(1000, amount) } : ing
    ))
  }
  
  // Remove ingredient
  const removeIngredient = (id) => {
    setSelectedIngredients(selectedIngredients.filter(ing => ing.id !== id))
  }
  
  // Calculate totals
  const calculateTotals = () => {
    const totals = {
      calories: 0,
      protein: 0,
      carbs: 0,
      fat: 0,
      cost: 0
    }
    
    selectedIngredients.forEach(ing => {
      const factor = ing.amount / 100
      totals.calories += (ing.calories_per_100g || 0) * factor
      totals.protein += (ing.protein_per_100g || 0) * factor
      totals.carbs += (ing.carbs_per_100g || 0) * factor
      totals.fat += (ing.fat_per_100g || 0) * factor
      totals.cost += (ing.price_per_unit || 0) * (ing.amount / 1000)
    })
    
    return {
      calories: Math.round(totals.calories),
      protein: Math.round(totals.protein),
      carbs: Math.round(totals.carbs),
      fat: Math.round(totals.fat),
      cost: totals.cost.toFixed(2)
    }
  }
  
  const totals = calculateTotals()
  
  // Save meal
  const saveMeal = async () => {
    if (!mealName || selectedIngredients.length === 0) {
      alert('Geef je maaltijd een naam en voeg ingrediënten toe')
      return
    }
    
    setSaving(true)
    try {
      // Format ingredients for storage
      const ingredientsList = selectedIngredients.map(ing => ({
        ingredient_id: ing.id,
        amount: ing.amount,
        unit: 'gram'
      }))
      
      // Create meal object
      const mealData = {
        client_id: clientId,
        name: mealName,
        ingredients: ingredientsList,
        calories: totals.calories,
        protein: totals.protein,
        carbs: totals.carbs,
        fat: totals.fat,
        total_cost: parseFloat(totals.cost),
        meal_type: mealType,
        instructions: instructions || null,
        is_favorite: true, // Auto favorite
        status: 'draft'
      }
      
      // Save to database
      const { data, error } = await db.supabase
        .from('custom_meals')
        .insert(mealData)
        .select()
        .single()
      
      if (error) throw error
      
      // Success feedback
      setSavedMessage('Maaltijd opgeslagen! 🎉')
      setTimeout(() => {
        if (onSave) onSave(data)
        onClose()
      }, 1500)
      
    } catch (error) {
      console.error('Save error:', error)
      alert('Fout bij opslaan: ' + error.message)
    } finally {
      setSaving(false)
    }
  }
  
  if (!isOpen) return null
  
  return (
    <div style={{
      position: 'fixed',
      inset: 0,
      background: 'rgba(0, 0, 0, 0.9)',
      backdropFilter: 'blur(20px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 1001,
      padding: isMobile ? '1rem' : '2rem',
      animation: 'fadeIn 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
    }}>
      <div style={{
        background: 'linear-gradient(135deg, rgba(26, 26, 26, 0.98) 0%, rgba(15, 15, 15, 0.98) 100%)',
        backdropFilter: 'blur(30px)',
        borderRadius: isMobile ? '20px' : '28px',
        width: '100%',
        maxWidth: isMobile ? '100%' : '800px',
        maxHeight: '90vh',
        display: 'flex',
        flexDirection: 'column',
        border: '1px solid rgba(139, 92, 246, 0.15)',
        boxShadow: '0 25px 80px rgba(0, 0, 0, 0.5), 0 0 60px rgba(139, 92, 246, 0.05)',
        overflow: 'hidden'
      }}>
        {/* Header */}
        <div style={{
          padding: isMobile ? '1.25rem' : '1.5rem',
          borderBottom: '1px solid rgba(139, 92, 246, 0.08)',
          background: 'rgba(0, 0, 0, 0.4)'
        }}>
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '1rem'
          }}>
            <h2 style={{
              fontSize: isMobile ? '1.25rem' : '1.5rem',
              fontWeight: '700',
              background: 'linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
              margin: 0,
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem'
            }}>
              <ChefHat size={24} />
              Eigen Maaltijd Maken
            </h2>
            <button
              onClick={onClose}
              style={{
                width: '36px',
                height: '36px',
                borderRadius: '10px',
                background: 'rgba(255, 255, 255, 0.05)',
                border: '1px solid rgba(255, 255, 255, 0.1)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
                transition: 'all 0.3s ease'
              }}
            >
              <X size={20} color="rgba(255, 255, 255, 0.6)" />
            </button>
          </div>
          
          {/* Meal name input */}
          <input
            type="text"
            placeholder="Naam van je maaltijd..."
            value={mealName}
            onChange={(e) => setMealName(e.target.value)}
            style={{
              width: '100%',
              padding: '0.75rem',
              background: 'rgba(255, 255, 255, 0.05)',
              border: '1px solid rgba(139, 92, 246, 0.2)',
              borderRadius: '10px',
              color: 'white',
              fontSize: '1rem',
              fontWeight: '500',
              outline: 'none',
              transition: 'all 0.2s ease'
            }}
            onFocus={(e) => {
              e.target.style.borderColor = 'rgba(139, 92, 246, 0.4)'
              e.target.style.background = 'rgba(139, 92, 246, 0.05)'
            }}
            onBlur={(e) => {
              e.target.style.borderColor = 'rgba(139, 92, 246, 0.2)'
              e.target.style.background = 'rgba(255, 255, 255, 0.05)'
            }}
          />
        </div>
        
        {/* Content */}
        <div style={{
          flex: 1,
          overflowY: 'auto',
          padding: isMobile ? '1.25rem' : '1.5rem'
        }}>
          {/* Search section */}
          <div style={{
            marginBottom: '1.5rem'
          }}>
            {/* Categories */}
            <div style={{
              display: 'flex',
              gap: '0.5rem',
              marginBottom: '1rem',
              overflowX: 'auto',
              paddingBottom: '0.5rem'
            }}>
              {categories.map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  style={{
                    padding: '0.5rem 1rem',
                    background: activeCategory === cat.id
                      ? `linear-gradient(135deg, ${cat.color}20 0%, ${cat.color}10 100%)`
                      : 'rgba(255, 255, 255, 0.03)',
                    border: `1px solid ${activeCategory === cat.id ? cat.color + '40' : 'rgba(255, 255, 255, 0.08)'}`,
                    borderRadius: '8px',
                    color: activeCategory === cat.id ? cat.color : 'rgba(255, 255, 255, 0.6)',
                    fontSize: '0.875rem',
                    fontWeight: '600',
                    cursor: 'pointer',
                    transition: 'all 0.2s ease',
                    whiteSpace: 'nowrap'
                  }}
                >
                  {cat.label}
                </button>
              ))}
            </div>
            
            {/* Search input */}
            <div style={{
              position: 'relative'
            }}>
              <Search 
                size={20} 
                style={{
                  position: 'absolute',
                  left: '1rem',
                  top: '50%',
                  transform: 'translateY(-50%)',
                  color: 'rgba(255, 255, 255, 0.4)'
                }}
              />
              <input
                type="text"
                placeholder="Zoek ingrediënt..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                style={{
                  width: '100%',
                  padding: '0.75rem 1rem 0.75rem 3rem',
                  background: 'rgba(255, 255, 255, 0.05)',
                  border: '1px solid rgba(255, 255, 255, 0.1)',
                  borderRadius: '10px',
                  color: 'white',
                  fontSize: '0.95rem',
                  outline: 'none'
                }}
              />
            </div>
            
            {/* Search results */}
            {searchResults.length > 0 && (
              <div style={{
                marginTop: '0.5rem',
                maxHeight: '200px',
                overflowY: 'auto',
                background: 'rgba(0, 0, 0, 0.3)',
                borderRadius: '10px',
                border: '1px solid rgba(255, 255, 255, 0.05)'
              }}>
                {searchResults.map(ing => (
                  <button
                    key={ing.id}
                    onClick={() => addIngredient(ing)}
                    style={{
                      width: '100%',
                      padding: '0.75rem',
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      background: 'transparent',
                      border: 'none',
                      borderBottom: '1px solid rgba(255, 255, 255, 0.03)',
                      color: 'white',
                      cursor: 'pointer',
                      transition: 'all 0.2s ease'
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.background = 'rgba(139, 92, 246, 0.05)'
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = 'transparent'
                    }}
                  >
                    <span style={{ fontSize: '0.9rem' }}>{ing.name}</span>
                    <div style={{
                      display: 'flex',
                      gap: '0.5rem',
                      fontSize: '0.75rem',
                      color: 'rgba(255, 255, 255, 0.5)'
                    }}>
                      <span>{Math.round(ing.calories_per_100g)} kcal</span>
                      <Plus size={16} color="#8b5cf6" />
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
          
          {/* Selected ingredients */}
          <div style={{
            marginBottom: '1.5rem'
          }}>
            <h3 style={{
              fontSize: '1rem',
              fontWeight: '600',
              color: 'rgba(255, 255, 255, 0.7)',
              marginBottom: '0.75rem'
            }}>
              Geselecteerde Ingrediënten
            </h3>
            
            {selectedIngredients.length === 0 ? (
              <div style={{
                padding: '2rem',
                background: 'rgba(255, 255, 255, 0.03)',
                borderRadius: '10px',
                border: '1px solid rgba(255, 255, 255, 0.05)',
                textAlign: 'center',
                color: 'rgba(255, 255, 255, 0.4)'
              }}>
                Zoek en voeg ingrediënten toe
              </div>
            ) : (
              <div style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '0.5rem'
              }}>
                {selectedIngredients.map(ing => {
                  const macros = {
                    calories: Math.round((ing.calories_per_100g || 0) * ing.amount / 100),
                    protein: Math.round((ing.protein_per_100g || 0) * ing.amount / 100),
                    carbs: Math.round((ing.carbs_per_100g || 0) * ing.amount / 100),
                    fat: Math.round((ing.fat_per_100g || 0) * ing.amount / 100)
                  }
                  
                  return (
                    <div
                      key={ing.id}
                      style={{
                        padding: '0.75rem',
                        background: 'rgba(139, 92, 246, 0.05)',
                        borderRadius: '10px',
                        border: '1px solid rgba(139, 92, 246, 0.1)'
                      }}
                    >
                      <div style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        marginBottom: '0.5rem'
                      }}>
                        <span style={{
                          fontWeight: '500',
                          color: 'white'
                        }}>
                          {ing.name}
                        </span>
                        <button
                          onClick={() => removeIngredient(ing.id)}
                          style={{
                            background: 'rgba(239, 68, 68, 0.1)',
                            border: '1px solid rgba(239, 68, 68, 0.2)',
                            borderRadius: '6px',
                            padding: '0.25rem',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center'
                          }}
                        >
                          <X size={16} color="#ef4444" />
                        </button>
                      </div>
                      
                      {/* Amount controls */}
                      <div style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.75rem',
                        marginBottom: '0.5rem'
                      }}>
                        <button
                          onClick={() => updateIngredientAmount(ing.id, ing.amount - 10)}
                          style={{
                            width: '32px',
                            height: '32px',
                            borderRadius: '8px',
                            background: 'rgba(255, 255, 255, 0.05)',
                            border: '1px solid rgba(255, 255, 255, 0.1)',
                            color: 'white',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center'
                          }}
                        >
                          <Minus size={16} />
                        </button>
                        
                        <input
                          type="number"
                          value={ing.amount}
                          onChange={(e) => updateIngredientAmount(ing.id, parseInt(e.target.value) || 0)}
                          style={{
                            width: '80px',
                            padding: '0.375rem',
                            background: 'rgba(255, 255, 255, 0.05)',
                            border: '1px solid rgba(255, 255, 255, 0.1)',
                            borderRadius: '6px',
                            color: 'white',
                            textAlign: 'center',
                            fontSize: '0.9rem'
                          }}
                        />
                        
                        <span style={{
                          color: 'rgba(255, 255, 255, 0.5)',
                          fontSize: '0.875rem'
                        }}>
                          gram
                        </span>
                        
                        <button
                          onClick={() => updateIngredientAmount(ing.id, ing.amount + 10)}
                          style={{
                            width: '32px',
                            height: '32px',
                            borderRadius: '8px',
                            background: 'rgba(255, 255, 255, 0.05)',
                            border: '1px solid rgba(255, 255, 255, 0.1)',
                            color: 'white',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center'
                          }}
                        >
                          <Plus size={16} />
                        </button>
                      </div>
                      
                      {/* Macros */}
                      <div style={{
                        display: 'flex',
                        gap: '1rem',
                        fontSize: '0.75rem',
                        color: 'rgba(255, 255, 255, 0.5)'
                      }}>
                        <span style={{ color: '#f59e0b' }}>{macros.calories} kcal</span>
                        <span style={{ color: '#8b5cf6' }}>{macros.protein}g eiwit</span>
                        <span style={{ color: '#ef4444' }}>{macros.carbs}g carbs</span>
                        <span style={{ color: '#3b82f6' }}>{macros.fat}g vet</span>
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </div>
          
          {/* Instructions (optional) */}
          <div style={{
            marginBottom: '1.5rem'
          }}>
            <h3 style={{
              fontSize: '1rem',
              fontWeight: '600',
              color: 'rgba(255, 255, 255, 0.7)',
              marginBottom: '0.75rem'
            }}>
              Bereidingswijze (optioneel)
            </h3>
            <textarea
              placeholder="Hoe maak je deze maaltijd..."
              value={instructions}
              onChange={(e) => setInstructions(e.target.value)}
              style={{
                width: '100%',
                minHeight: '100px',
                padding: '0.75rem',
                background: 'rgba(255, 255, 255, 0.05)',
                border: '1px solid rgba(255, 255, 255, 0.1)',
                borderRadius: '10px',
                color: 'white',
                fontSize: '0.9rem',
                resize: 'vertical',
                outline: 'none'
              }}
            />
          </div>
        </div>
        
        {/* Footer with totals */}
        <div style={{
          padding: isMobile ? '1.25rem' : '1.5rem',
          borderTop: '1px solid rgba(139, 92, 246, 0.08)',
          background: 'rgba(0, 0, 0, 0.4)'
        }}>
          {/* Macro totals */}
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '1rem'
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'baseline',
              gap: '0.25rem'
            }}>
              <Flame size={18} color="#f59e0b" />
              <span style={{
                fontSize: '1.5rem',
                fontWeight: '800',
                color: '#f59e0b'
              }}>
                {totals.calories}
              </span>
              <span style={{
                fontSize: '0.65rem',
                color: 'rgba(245, 158, 11, 0.5)',
                textTransform: 'uppercase'
              }}>
                kcal
              </span>
            </div>
            
            <div style={{
              display: 'flex',
              gap: '1.25rem'
            }}>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.25rem'
              }}>
                <Target size={16} color="#8b5cf6" />
                <span style={{ fontWeight: '700', color: '#8b5cf6' }}>
                  {totals.protein}g
                </span>
              </div>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.25rem'
              }}>
                <Zap size={16} color="#ef4444" />
                <span style={{ fontWeight: '700', color: '#ef4444' }}>
                  {totals.carbs}g
                </span>
              </div>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.25rem'
              }}>
                <Droplets size={16} color="#3b82f6" />
                <span style={{ fontWeight: '700', color: '#3b82f6' }}>
                  {totals.fat}g
                </span>
              </div>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.25rem'
              }}>
                <Euro size={16} color="#10b981" />
                <span style={{ fontWeight: '700', color: '#10b981' }}>
                  €{totals.cost}
                </span>
              </div>
            </div>
          </div>
          
          {/* Save button */}
          <button
            onClick={saveMeal}
            disabled={!mealName || selectedIngredients.length === 0 || saving}
            style={{
              width: '100%',
              padding: '0.875rem',
              background: savedMessage 
                ? 'linear-gradient(135deg, #10b981 0%, #059669 100%)'
                : 'linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%)',
              border: 'none',
              borderRadius: '12px',
              color: 'white',
              fontSize: '1rem',
              fontWeight: '600',
              cursor: !mealName || selectedIngredients.length === 0 || saving ? 'not-allowed' : 'pointer',
              opacity: !mealName || selectedIngredients.length === 0 || saving ? 0.5 : 1,
              transition: 'all 0.3s ease',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '0.5rem'
            }}
          >
            {savedMessage ? (
              <>
                <Check size={20} />
                {savedMessage}
              </>
            ) : saving ? (
              'Opslaan...'
            ) : (
              <>
                <Save size={20} />
                Maaltijd Opslaan
              </>
            )}
          </button>
        </div>
      </div>
      
      <style>{`
        @keyframes fadeIn {
          from { 
            opacity: 0;
            transform: scale(0.95);
          }
          to { 
            opacity: 1;
            transform: scale(1);
          }
        }
      `}</style>
    </div>
  )
}
