// Temporary stub - replace with full component
import React from 'react'

export default function Analytics({ plans }) {
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold">Analytics</h2>
      <p className="text-gray-600">Analytics component coming soon...</p>
    </div>
  )
}
