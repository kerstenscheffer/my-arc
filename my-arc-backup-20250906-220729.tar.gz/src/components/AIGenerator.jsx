
import DatabaseService from '../services/DatabaseService'
const db = DatabaseService
import { saveWorkoutSchema } from '../lib/schemaDatabase'


import { useState, useEffect, useRef } from 'react'

// ===== SPECIFIC GOALS SYSTEM =====
const SPECIFIC_GOALS = {
  // Strength Specialization
  bench_strength: {
    name: "Bench Press Strength",
    description: "Focus on increasing bench press 1RM",
    priorityExercises: ["Barbell Bench Press", "Pause Barbell Bench Press", "Close-Grip Barbell Bench Press", "Incline Dumbbell Press", "Low-Incline Barbell Bench Press"],
    volumeBonus: { chest: 4, triceps: 2 },
    repRangeOverride: { compound: [3, 6], isolation: [6, 8] },
    intensityMethods: ["pause_reps", "pin_press", "board_press"],
    notes: "Extra volume on bench variations, pause work for strength"
  },
  squat_strength: {
    name: "Squat Strength", 
    description: "Focus on increasing squat 1RM",
    priorityExercises: ["High-Bar Back Squat", "Front Squat", "Leg Press", "Bulgarian Split Squat", "Hack Squat"],
    volumeBonus: { legs: 4 },
    repRangeOverride: { compound: [3, 6], isolation: [6, 8] },
    intensityMethods: ["pause_squats", "box_squats", "pin_squats"],
    notes: "Heavy squat focus with accessory support"
  },
  deadlift_strength: {
    name: "Deadlift Strength",
    description: "Focus on increasing deadlift 1RM", 
    priorityExercises: ["Romanian Deadlift", "Trap Bar Deadlift", "Barbell Bent-Over Row", "Single-Arm Dumbbell Row"],
    volumeBonus: { back: 3, legs: 3 },
    repRangeOverride: { compound: [3, 6], isolation: [6, 8] },
    intensityMethods: ["deficit_pulls", "rack_pulls", "pause_deads"],
    notes: "Heavy pulling patterns with posterior chain focus"
  },
  ohp_strength: {
    name: "Overhead Press Strength",
    description: "Focus on increasing overhead press 1RM",
    priorityExercises: ["Standing Barbell Overhead Press (Strict Press)", "Seated Barbell Overhead Press", "Dumbbell Shoulder Press", "Z-Press", "Push Press"],
    volumeBonus: { shoulders: 4, triceps: 2 },
    repRangeOverride: { compound: [3, 6], isolation: [6, 8] },
    intensityMethods: ["pin_press", "push_press", "pause_press"],
    notes: "Heavy overhead pressing with strict form emphasis"
  },
  pullup_strength: {
    name: "Pull-up Strength (10+ reps)",
    description: "Build up to 10+ consecutive pull-ups",
    priorityExercises: ["Weighted Pull-Ups", "Weighted Chin-Ups", "Lat Pulldown", "Inverted Row"],
    volumeBonus: { back: 4, biceps: 2 },
    repRangeOverride: { compound: [5, 8], isolation: [8, 12] },
    intensityMethods: ["assisted_pullups", "negative_pullups", "cluster_sets"],
    notes: "Progressive overload towards bodyweight mastery"
  },

  // Hypertrophy Specialization  
  lat_width: {
    name: "Lat Width Development",
    description: "Maximize lat width for V-taper",
    priorityExercises: ["Weighted Pull-Ups", "Lat Pulldown", "Cable Pullovers", "Single-Arm Lat Pulldown", "One-Arm Cable Pullover"],
    volumeBonus: { back: 6 },
    repRangeOverride: { compound: [8, 12], isolation: [12, 15] },
    intensityMethods: ["myo_reps", "drop_sets", "stretch_pause"],
    notes: "Width-focused pulling with stretch emphasis"
  },
  shoulder_width: {
    name: "Shoulder Width (V-Shape)",
    description: "Build massive lateral delts for shoulder width",
    priorityExercises: ["Cable Lateral Raises", "Lean-Away Cable Lateral Raise", "Machine Lateral Raises", "Cuffed Cable Lateral Raise", "Lying Incline Lateral Raise"],
    volumeBonus: { shoulders: 8 },
    repRangeOverride: { compound: [8, 12], isolation: [12, 20] },
    intensityMethods: ["myo_reps", "mechanical_drop_sets", "partial_reps"],
    notes: "High volume lateral delt specialization"
  },
  tricep_size: {
    name: "Tricep Mass",
    description: "Maximize tricep size for arm development",
    priorityExercises: ["Cable Overhead Triceps Extension", "Single-Arm Overhead Cable Extension", "Incline Skull Crushers", "Crossbody Cable Extension", "Dumbbell Overhead Extension"],
    volumeBonus: { triceps: 6 },
    repRangeOverride: { compound: [8, 12], isolation: [10, 15] },
    intensityMethods: ["myo_reps", "drop_sets", "lengthened_partials"],
    notes: "Overhead emphasis for long head development"
  },
  bicep_peaks: {
    name: "Bicep Peaks", 
    description: "Build impressive bicep peaks and size",
    priorityExercises: ["Incline Dumbbell Curl", "Bayesian Cable Curl", "Preacher Curls", "Spider Curl", "Concentration Curl"],
    volumeBonus: { biceps: 6 },
    repRangeOverride: { compound: [8, 12], isolation: [10, 15] },
    intensityMethods: ["myo_reps", "drop_sets", "21s"],
    notes: "Stretch position curls for peak development"
  },
  glute_dev: {
    name: "Glute Development",
    description: "Build powerful, shapely glutes",
    priorityExercises: ["Hip Thrust", "Romanian Deadlift", "Bulgarian Split Squat", "Cable Glute Kickback", "Hip Abduction Machine"],
    volumeBonus: { legs: 6 },
    repRangeOverride: { compound: [8, 12], isolation: [12, 15] },
    intensityMethods: ["pause_reps", "1.5_reps", "pulse_reps"],
    notes: "Hip-dominant movements with glute focus"
  },
  chest_thickness: {
    name: "Chest Thickness",
    description: "Build thick, powerful pecs",
    priorityExercises: ["Incline Dumbbell Press", "Machine Chest Press", "Weighted Dips", "Incline Cable Flies", "Seated Cable Fly"],
    volumeBonus: { chest: 6 },
    repRangeOverride: { compound: [8, 12], isolation: [10, 15] },
    intensityMethods: ["myo_reps", "drop_sets", "stretch_pause"],
    notes: "Stretch-focused movements for thickness"
  },
  back_thickness: {
    name: "Back Thickness",
    description: "Build thick, dense back musculature", 
    priorityExercises: ["T-Bar Row (Chest-Supported)", "Pendlay Row", "Machine Row", "Single-Arm Dumbbell Row", "Cable Row"],
    volumeBonus: { back: 6 },
    repRangeOverride: { compound: [8, 12], isolation: [10, 15] },
    intensityMethods: ["pause_reps", "cluster_sets", "myo_reps"],
    notes: "Rowing emphasis for back thickness"
  },

  // Skill & Performance
  handstand_prog: {
    name: "Handstand Progression",
    description: "Build towards freestanding handstand",
    priorityExercises: ["Overhead Press", "Dumbbell Shoulder Press", "Pike Push-Ups", "Weighted Push-Ups"],
    volumeBonus: { shoulders: 4, triceps: 2 },
    repRangeOverride: { compound: [5, 10], isolation: [8, 15] },
    intensityMethods: ["wall_walks", "hollow_holds", "handstand_holds"],
    notes: "Overhead strength for handstand development"
  },
  pistol_squat: {
    name: "Pistol Squat Progression",
    description: "Build single-leg squat strength",
    priorityExercises: ["Bulgarian Split Squat", "Step-Up", "Single-Leg Leg Extension", "Walking Lunge"],
    volumeBonus: { legs: 4 },
    repRangeOverride: { compound: [6, 12], isolation: [8, 15] },
    intensityMethods: ["assisted_pistols", "box_pistols", "negative_pistols"],
    notes: "Unilateral leg strength development"
  },
  muscle_up: {
    name: "Muscle-up Progression",
    description: "Build towards muscle-up mastery",
    priorityExercises: ["Weighted Pull-Ups", "Weighted Dips", "Lat Pulldown", "Triceps Pushdown"],
    volumeBonus: { back: 3, triceps: 3 },
    repRangeOverride: { compound: [5, 10], isolation: [8, 12] },
    intensityMethods: ["kipping_practice", "transition_work", "band_assistance"],
    notes: "Pull-up and dip strength for muscle-up transition"
  }
};

// ===== AI SCHEMA GENERATOR CLASS =====
class AISchemaGenerator {
  constructor() {
    this.exerciseDatabase = this.initializeExerciseDatabase()
    this.volumeGuidelines = this.initializeVolumeGuidelines()
    this.splitTemplates = this.initializeSplitTemplates()
    this.specificGoals = SPECIFIC_GOALS
  }

  initializeExerciseDatabase() {
    return {
      chest: {
        compound: [
          { name: "Machine Chest Press", equipment: "machine", stretch: true, rom: "excellent", overload: "excellent", painFree: true, priority: 1, primary: "chest", ratings: { strength: 5, hypertrophy: 5, personal: 5 } },
          { name: "Incline Dumbbell Press", equipment: "dumbbells", stretch: true, rom: "excellent", overload: "good", painFree: true, priority: 2, primary: "chest", ratings: { strength: 8, hypertrophy: 8, personal: 8 } },
          { name: "Barbell Bench Press", equipment: "barbell", stretch: false, rom: "good", overload: "excellent", painFree: false, priority: 3, primary: "chest", ratings: { strength: 10, hypertrophy: 8, personal: 10 } },
          { name: "Weighted Dips", equipment: "bodyweight", stretch: true, rom: "excellent", overload: "good", painFree: false, priority: 4, primary: "chest", ratings: { strength: 9, hypertrophy: 9, personal: 7 } },
          { name: "Low-Incline Barbell Bench Press", equipment: "barbell", stretch: true, rom: "excellent", overload: "excellent", painFree: true, priority: 2, primary: "chest", ratings: { strength: 9, hypertrophy: 9, personal: 9 } },
          { name: "Flat Dumbbell Bench Press", equipment: "dumbbells", stretch: true, rom: "excellent", overload: "good", painFree: true, priority: 3, primary: "chest", ratings: { strength: 8, hypertrophy: 8, personal: 8 } }
        ],
        isolation: [
          { name: "Incline Cable Flies", equipment: "cables", stretch: true, rom: "excellent", overload: "excellent", painFree: true, priority: 1, primary: "chest", ratings: { strength: 8, hypertrophy: 10, personal: 8 } },
          { name: "Machine Pec Deck", equipment: "machine", stretch: true, rom: "excellent", overload: "excellent", painFree: true, priority: 2, primary: "chest", ratings: { strength: 8, hypertrophy: 10, personal: 8 } },
          { name: "Seated Cable Fly", equipment: "cables", stretch: true, rom: "excellent", overload: "excellent", painFree: true, priority: 2, primary: "chest", ratings: { strength: 10, hypertrophy: 10, personal: 10 } },
          { name: "Low-to-High Cable Fly", equipment: "cables", stretch: true, rom: "excellent", overload: "excellent", painFree: true, priority: 2, primary: "chest", ratings: { strength: 8, hypertrophy: 10, personal: 10 } },
          { name: "Dumbbell Flies", equipment: "dumbbells", stretch: true, rom: "excellent", overload: "good", painFree: true, priority: 3, primary: "chest", ratings: { strength: 5, hypertrophy: 7, personal: 7 } }
        ]
      },
      back: {
        compound: [
          { name: "Lat Pulldown", equipment: "cables", stretch: true, rom: "excellent", overload: "excellent", painFree: true, priority: 1, primary: "back", ratings: { strength: 8, hypertrophy: 9, personal: 9 } },
          { name: "Weighted Pull-Ups", equipment: "bodyweight", stretch: true, rom: "excellent", overload: "good", painFree: true, priority: 1, primary: "back", ratings: { strength: 10, hypertrophy: 10, personal: 10 } },
          { name: "T-Bar Row (Chest-Supported)", equipment: "machine", stretch: true, rom: "excellent", overload: "excellent", painFree: true, priority: 2, primary: "back", ratings: { strength: 8, hypertrophy: 10, personal: 9 } },
          { name: "Cable Row", equipment: "cables", stretch: true, rom: "excellent", overload: "excellent", painFree: true, priority: 3, primary: "back", ratings: { strength: 7, hypertrophy: 8, personal: 8 } },
          { name: "Barbell Bent-Over Row", equipment: "barbell", stretch: true, rom: "excellent", overload: "excellent", painFree: false, priority: 3, primary: "back", ratings: { strength: 9, hypertrophy: 8, personal: 7 } },
          { name: "Single-Arm Dumbbell Row", equipment: "dumbbells", stretch: true, rom: "excellent", overload: "good", painFree: true, priority: 4, primary: "back", ratings: { strength: 8, hypertrophy: 8, personal: 8 } }
        ],
        isolation: [
          { name: "Cable Pullovers", equipment: "cables", stretch: true, rom: "excellent", overload: "excellent", painFree: true, priority: 1, primary: "back", ratings: { strength: 6, hypertrophy: 9, personal: 9 } },
          { name: "Straight-Arm Pulldown (Rope)", equipment: "cables", stretch: true, rom: "excellent", overload: "excellent", painFree: true, priority: 1, primary: "back", ratings: { strength: 5, hypertrophy: 8, personal: 8 } },
          { name: "Face Pulls", equipment: "cables", stretch: false, rom: "good", overload: "good", painFree: true, priority: 3, primary: "back", ratings: { strength: 5, hypertrophy: 7, personal: 7 } },
          { name: "Single-Arm Lat Pulldown", equipment: "cables", stretch: true, rom: "excellent", overload: "excellent", painFree: true, priority: 2, primary: "back", ratings: { strength: 7, hypertrophy: 8, personal: 8 } }
        ]
      },
      shoulders: {
        compound: [
          { name: "Machine Shoulder Press", equipment: "machine", stretch: false, rom: "good", overload: "excellent", painFree: true, priority: 1, primary: "shoulders", ratings: { strength: 8, hypertrophy: 8, personal: 8 } },
          { name: "Dumbbell Shoulder Press", equipment: "dumbbells", stretch: false, rom: "excellent", overload: "good", painFree: true, priority: 2, primary: "shoulders", ratings: { strength: 8, hypertrophy: 8, personal: 8 } },
          { name: "Overhead Press", equipment: "barbell", stretch: false, rom: "good", overload: "excellent", painFree: false, priority: 3, primary: "shoulders", ratings: { strength: 9, hypertrophy: 7, personal: 7 } },
          { name: "Seated Barbell Overhead Press", equipment: "barbell", stretch: false, rom: "good", overload: "excellent", painFree: true, priority: 2, primary: "shoulders", ratings: { strength: 9, hypertrophy: 7, personal: 7 } }
        ],
        isolation: [
          { name: "Cable Lateral Raises", equipment: "cables", stretch: true, rom: "excellent", overload: "excellent", painFree: true, priority: 1, primary: "shoulders", ratings: { strength: 8, hypertrophy: 10, personal: 10 } },
          { name: "Lean-Away Cable Lateral Raise", equipment: "cables", stretch: true, rom: "excellent", overload: "excellent", painFree: true, priority: 1, primary: "shoulders", ratings: { strength: 5, hypertrophy: 10, personal: 10 } },
          { name: "Machine Lateral Raises", equipment: "machine", stretch: true, rom: "excellent", overload: "excellent", painFree: true, priority: 2, primary: "shoulders", ratings: { strength: 5, hypertrophy: 9, personal: 9 } },
          { name: "Dumbbell Lateral Raises", equipment: "dumbbells", stretch: false, rom: "good", overload: "good", painFree: true, priority: 3, primary: "shoulders", ratings: { strength: 5, hypertrophy: 7, personal: 7 } },
          { name: "Lying Incline Lateral Raise", equipment: "dumbbells", stretch: true, rom: "excellent", overload: "good", painFree: true, priority: 2, primary: "shoulders", ratings: { strength: 5, hypertrophy: 9, personal: 9 } }
        ]
      },
      legs: {
        compound: [
          { name: "Leg Press", equipment: "machine", stretch: true, rom: "excellent", overload: "excellent", painFree: true, priority: 1, primary: "legs", ratings: { strength: 8, hypertrophy: 9, personal: 9 } },
          { name: "Romanian Deadlift", equipment: "barbell", stretch: true, rom: "excellent", overload: "excellent", painFree: true, priority: 2, primary: "legs", ratings: { strength: 9, hypertrophy: 10, personal: 10 } },
          { name: "Hip Thrust", equipment: "barbell", stretch: true, rom: "excellent", overload: "excellent", painFree: true, priority: 3, primary: "legs", ratings: { strength: 8, hypertrophy: 9, personal: 9 } },
          { name: "High-Bar Back Squat", equipment: "barbell", stretch: true, rom: "excellent", overload: "excellent", painFree: false, priority: 2, primary: "legs", ratings: { strength: 9, hypertrophy: 8, personal: 7 } },
          { name: "Bulgarian Split Squat", equipment: "dumbbells", stretch: true, rom: "excellent", overload: "good", painFree: true, priority: 4, primary: "legs", ratings: { strength: 7, hypertrophy: 8, personal: 8 } },
          { name: "Hack Squat", equipment: "machine", stretch: true, rom: "excellent", overload: "excellent", painFree: true, priority: 1, primary: "legs", ratings: { strength: 8, hypertrophy: 9, personal: 9 } }
        ],
        isolation: [
          { name: "Leg Extension", equipment: "machine", stretch: true, rom: "excellent", overload: "excellent", painFree: true, priority: 1, primary: "legs", ratings: { strength: 5, hypertrophy: 9, personal: 9 } },
          { name: "Leg Curl", equipment: "machine", stretch: true, rom: "excellent", overload: "excellent", painFree: true, priority: 2, primary: "legs", ratings: { strength: 5, hypertrophy: 9, personal: 9 } },
          { name: "Calf Raises", equipment: "machine", stretch: true, rom: "excellent", overload: "excellent", painFree: true, priority: 3, primary: "legs", ratings: { strength: 6, hypertrophy: 7, personal: 7 } },
          { name: "Single-Leg Leg Extension", equipment: "machine", stretch: true, rom: "excellent", overload: "excellent", painFree: true, priority: 1, primary: "legs", ratings: { strength: 5, hypertrophy: 8, personal: 8 } }
        ]
      },
      biceps: {
        compound: [],
        isolation: [
          { name: "Incline Dumbbell Curl", equipment: "dumbbells", stretch: true, rom: "excellent", overload: "good", painFree: true, priority: 1, primary: "biceps", ratings: { strength: 5, hypertrophy: 10, personal: 10 } },
          { name: "Bayesian Cable Curl", equipment: "cables", stretch: true, rom: "excellent", overload: "excellent", painFree: true, priority: 1, primary: "biceps", ratings: { strength: 5, hypertrophy: 10, personal: 10 } },
          { name: "Cable Bicep Curls", equipment: "cables", stretch: true, rom: "excellent", overload: "excellent", painFree: true, priority: 1, primary: "biceps", ratings: { strength: 5, hypertrophy: 9, personal: 9 } },
          { name: "Preacher Curls", equipment: "dumbbells", stretch: true, rom: "excellent", overload: "good", painFree: true, priority: 2, primary: "biceps", ratings: { strength: 6, hypertrophy: 9, personal: 9 } },
          { name: "Hammer Curls", equipment: "dumbbells", stretch: false, rom: "good", overload: "good", painFree: true, priority: 3, primary: "biceps", ratings: { strength: 6, hypertrophy: 8, personal: 8 } },
          { name: "Barbell Curls", equipment: "barbell", stretch: false, rom: "good", overload: "excellent", painFree: true, priority: 4, primary: "biceps", ratings: { strength: 7, hypertrophy: 8, personal: 7 } }
        ]
      },
      triceps: {
        compound: [
          { name: "Close-Grip Bench Press", equipment: "barbell", stretch: false, rom: "good", overload: "excellent", painFree: false, priority: 2, primary: "triceps", ratings: { strength: 8, hypertrophy: 6, personal: 6 } },
          { name: "Weighted Dips", equipment: "bodyweight", stretch: true, rom: "excellent", overload: "good", painFree: false, priority: 1, primary: "triceps", ratings: { strength: 9, hypertrophy: 9, personal: 7 } }
        ],
        isolation: [
          { name: "Cable Overhead Triceps Extension", equipment: "cables", stretch: true, rom: "excellent", overload: "excellent", painFree: true, priority: 1, primary: "triceps", ratings: { strength: 5, hypertrophy: 10, personal: 10 } },
          { name: "Single-Arm Overhead Cable Extension", equipment: "cables", stretch: true, rom: "excellent", overload: "excellent", painFree: true, priority: 1, primary: "triceps", ratings: { strength: 5, hypertrophy: 9, personal: 9 } },
          { name: "Crossbody Cable Extension", equipment: "cables", stretch: true, rom: "excellent", overload: "excellent", painFree: true, priority: 1, primary: "triceps", ratings: { strength: 5, hypertrophy: 9, personal: 9 } },
          { name: "Incline Skull Crushers", equipment: "barbell", stretch: true, rom: "excellent", overload: "excellent", painFree: true, priority: 2, primary: "triceps", ratings: { strength: 6, hypertrophy: 9, personal: 9 } },
          { name: "Triceps Pushdown", equipment: "cables", stretch: false, rom: "good", overload: "excellent", painFree: true, priority: 2, primary: "triceps", ratings: { strength: 6, hypertrophy: 8, personal: 8 } },
          { name: "Dumbbell Overhead Extension", equipment: "dumbbells", stretch: true, rom: "excellent", overload: "good", painFree: true, priority: 3, primary: "triceps", ratings: { strength: 5, hypertrophy: 9, personal: 9 } }
        ]
      }
    }
  }

  initializeVolumeGuidelines() {
    return {
      beginner: {
        chest: { min: 8, max: 10 }, back: { min: 8, max: 10 }, shoulders: { min: 8, max: 10 },
        legs: { min: 8, max: 10 }, biceps: { min: 8, max: 10 }, triceps: { min: 8, max: 10 }
      },
      intermediate: {
        chest: { min: 10, max: 14 }, back: { min: 10, max: 14 }, shoulders: { min: 12, max: 16 },
        legs: { min: 12, max: 16 }, biceps: { min: 10, max: 14 }, triceps: { min: 10, max: 14 }
      },
      advanced: {
        chest: { min: 12, max: 16 }, back: { min: 12, max: 16 }, shoulders: { min: 14, max: 18 },
        legs: { min: 14, max: 18 }, biceps: { min: 12, max: 16 }, triceps: { min: 12, max: 16 }
      }
    }
  }

  initializeSplitTemplates() {
    return {
      3: [
        { name: "Push/Pull/Legs", type: "ppl", days: ["Push", "Pull", "Legs"] },
        { name: "Full Body", type: "full_body", days: ["Full Body A", "Full Body B", "Full Body C"] },
        { name: "Upper/Lower + Full", type: "upper_lower", days: ["Upper", "Lower", "Full Body"] }
      ],
      4: [
        { name: "Upper/Lower", type: "upper_lower", days: ["Upper A", "Lower A", "Upper B", "Lower B"] },
        { name: "Arnold Split", type: "arnold", days: ["Chest/Back", "Shoulders/Arms", "Legs", "Chest/Back"] },
        { name: "Push/Pull/Legs + Upper", type: "ppl", days: ["Push", "Pull", "Legs", "Upper"] }
      ],
      5: [
        { name: "Push/Pull/Legs + Upper/Lower", type: "ppl", days: ["Push", "Pull", "Legs", "Upper", "Lower"] },
        { name: "Bro Split", type: "bro", days: ["Chest", "Back", "Shoulders", "Arms", "Legs"] }
      ],
      6: [
        { name: "Push/Pull/Legs x2", type: "ppl_x2", days: ["Push A", "Pull A", "Legs A", "Push B", "Pull B", "Legs B"] },
        { name: "Arnold Split x2", type: "arnold", days: ["Chest/Back", "Shoulders/Arms", "Legs", "Chest/Back", "Shoulders/Arms", "Legs"] }
      ]
    }
  }

  generateSchema(clientData, options = {}) {
    console.log('🧠 AI generating schema for:', clientData)
    console.log('🎯 Specific goal:', clientData.specificGoal || 'None')
    
    const split = this.determineSplit(clientData)
    const weekStructure = this.generateWeekStructure(clientData, split, options)
    const volumeAnalysis = this.calculateVolumeDistribution(clientData, weekStructure)

    let schemaName = `AI Generated - ${clientData.primaryGoal} ${clientData.experience} ${clientData.daysPerWeek}-Day`
    if (clientData.specificGoal && this.specificGoals[clientData.specificGoal]) {
      const goalName = this.specificGoals[clientData.specificGoal].name
      schemaName += ` + ${goalName}`
    }

    return {
      name: schemaName,
      description: `AI-generated schema optimized for ${clientData.primaryGoal} goals with personal ratings`,
      conditions: {
        goal: clientData.primaryGoal,
        experience: clientData.experience,
        daysPerWeek: clientData.daysPerWeek,
        equipment: clientData.equipment,
        specificGoal: clientData.specificGoal || null
      },
      splitOverview: {
        schema: split.name,
        type: split.type,
        description: `AI-optimized ${split.name} for ${clientData.primaryGoal} development`
      },
      weekStructure: weekStructure,
      volumeAnalysis: volumeAnalysis,
      specificGoal: clientData.specificGoal ? this.specificGoals[clientData.specificGoal] : null,
      mode: 'ai_generated',
      generated: true
    }
  }

  determineSplit(clientData) {
    const templates = this.splitTemplates[clientData.daysPerWeek]
    if (!templates || templates.length === 0) {
      return { name: "Custom", type: "custom", days: Array(clientData.daysPerWeek).fill("Training Day") }
    }

    // Use split preferences if provided
    if (clientData.splitPreferences) {
      const preferences = Object.entries(clientData.splitPreferences)
        .filter(([_, rank]) => rank > 0)
        .sort(([,a], [,b]) => a - b)
      
      if (preferences.length > 0) {
        const [preferredSplitType] = preferences[0]
        const preferredSplit = templates.find(t => t.type === preferredSplitType)
        if (preferredSplit) {
          console.log(`🎯 Using preferred split: ${preferredSplit.name}`)
          return preferredSplit
        }
      }
    }

    // Goal-based selection (fallback)
    if (clientData.primaryGoal === 'strength' && clientData.daysPerWeek <= 4) {
      return templates.find(t => t.type === 'upper_lower') || templates[0]
    }
    
    if (clientData.primaryGoal === 'v_shape' && clientData.daysPerWeek >= 5) {
      return templates.find(t => t.type === 'ppl' || t.type === 'ppl_x2') || templates[0]
    }

    if (clientData.primaryGoal === 'hypertrophy' && clientData.daysPerWeek >= 4) {
      return templates.find(t => t.type === 'ppl' || t.type === 'arnold') || templates[0]
    }

    return templates[0]
  }

  generateWeekStructure(clientData, split, options) {
    const weekStructure = {}
    
    split.days.forEach((dayName, index) => {
      const dayKey = `dag${index + 1}`
      weekStructure[dayKey] = this.generateDayStructure(dayName, clientData, index, options)
    })

    return weekStructure
  }

  generateDayStructure(dayName, clientData, dayIndex, options = {}) {
    const muscleGroups = this.determineMuscleGroups(dayName, clientData.primaryGoal)
    const exercises = this.selectExercises(muscleGroups, clientData, options)
    
    return {
      name: dayName.toUpperCase(),
      focus: muscleGroups.join(', '),
      geschatteTijd: `${clientData.timePerSession || 75} minutes`,
      exercises: exercises
    }
  }

  determineMuscleGroups(dayName, goal) {
    const dayNameLower = dayName.toLowerCase()
    
    if (dayNameLower.includes('push')) {
      return ['chest', 'shoulders', 'triceps']
    } else if (dayNameLower.includes('pull')) {
      return ['back', 'biceps']
    } else if (dayNameLower.includes('legs') || dayNameLower.includes('lower')) {
      return ['legs']
    } else if (dayNameLower.includes('upper')) {
      return ['chest', 'back', 'shoulders', 'biceps', 'triceps']
    } else if (dayNameLower.includes('chest')) {
      return ['chest']
    } else if (dayNameLower.includes('back')) {
      return ['back']
    } else if (dayNameLower.includes('shoulders')) {
      return ['shoulders']
    } else if (dayNameLower.includes('arms')) {
      return ['biceps', 'triceps']
    } else if (dayNameLower.includes('full body')) {
      return ['chest', 'back', 'legs', 'shoulders']
    } else {
      return ['chest', 'back', 'legs', 'shoulders']
    }
  }

  selectExercises(muscleGroups, clientData, options = {}) {
    const exercises = []
    const usedExerciseNames = new Set()
    const availableEquipment = clientData.equipment
    const goal = clientData.primaryGoal
    const specificGoal = clientData.specificGoal ? this.specificGoals[clientData.specificGoal] : null
    
    // Get priority exercises for specific goal
    const priorityExercises = specificGoal ? specificGoal.priorityExercises : []
    console.log(`🎯 Priority exercises for ${specificGoal?.name || 'No specific goal'}:`, priorityExercises)
    
    muscleGroups.forEach(muscleGroup => {
      let dbCategory = muscleGroup
      if (['quads', 'hamstrings', 'glutes', 'calves'].includes(muscleGroup)) {
        dbCategory = 'legs'
      }
      
      const muscleExercises = this.exerciseDatabase[dbCategory]
      if (!muscleExercises) return
      
      const availableCompounds = muscleExercises.compound.filter(ex => 
        (availableEquipment.length === 0 || availableEquipment.some(eq => ex.equipment.includes(eq) || eq === 'full_gym')) &&
        !usedExerciseNames.has(ex.name)
      )
      
      const availableIsolations = muscleExercises.isolation.filter(ex => 
        (availableEquipment.length === 0 || availableEquipment.some(eq => ex.equipment.includes(eq) || eq === 'full_gym')) &&
        !usedExerciseNames.has(ex.name)
      )
      
      // Sort by specific goal priority first, then by score
      const sortByGoalPriority = (a, b) => {
        const aIsGoalPriority = priorityExercises.includes(a.name) ? 1000 : 0
        const bIsGoalPriority = priorityExercises.includes(b.name) ? 1000 : 0
        
        const scoreA = this.calculateExerciseScore(a, goal, 'compound') + aIsGoalPriority
        const scoreB = this.calculateExerciseScore(b, goal, 'compound') + bIsGoalPriority
        return scoreB - scoreA
      }
      
      availableCompounds.sort(sortByGoalPriority)
      availableIsolations.sort(sortByGoalPriority)
      
      // Exercise selection based on goal and specific priorities
      if (goal === 'hypertrophy' || goal === 'v_shape') {
        // Prioritize stretch-tension isolation exercises
        const topIsolations = availableIsolations.filter(ex => ex.stretch === true)
        if (topIsolations.length > 0) {
          const exercise = this.formatExercise(topIsolations[0], clientData, 'isolation', muscleGroup, specificGoal)
          exercises.push(exercise)
          usedExerciseNames.add(exercise.name)
        }
        
        // Add best compound
        if (availableCompounds.length > 0) {
          const exercise = this.formatExercise(availableCompounds[0], clientData, 'compound', muscleGroup, specificGoal)
          exercises.push(exercise)
          usedExerciseNames.add(exercise.name)
        }
        
        // Extra exercises for specific goal muscle groups
        const hasGoalBonus = specificGoal && specificGoal.volumeBonus && specificGoal.volumeBonus[muscleGroup]
        if (hasGoalBonus || (clientData.experience === 'advanced' && topIsolations.length > 1)) {
          const exercise = this.formatExercise(topIsolations[1] || availableIsolations[0], clientData, 'isolation', muscleGroup, specificGoal)
          if (exercise && !usedExerciseNames.has(exercise.name)) {
            exercises.push(exercise)
            usedExerciseNames.add(exercise.name)
          }
        }
      } else {
        // Strength: compounds first
        if (availableCompounds.length > 0) {
          const exercise = this.formatExercise(availableCompounds[0], clientData, 'compound', muscleGroup, specificGoal)
          exercises.push(exercise)
          usedExerciseNames.add(exercise.name)
        }
        
        if (availableIsolations.length > 0 && clientData.experience !== 'beginner') {
          const exercise = this.formatExercise(availableIsolations[0], clientData, 'isolation', muscleGroup, specificGoal)
          exercises.push(exercise)
          usedExerciseNames.add(exercise.name)
        }
        
        // Extra volume for strength specific goals
        const hasGoalBonus = specificGoal && specificGoal.volumeBonus && specificGoal.volumeBonus[muscleGroup]
        if (hasGoalBonus && availableCompounds.length > 1) {
          const exercise = this.formatExercise(availableCompounds[1], clientData, 'compound', muscleGroup, specificGoal)
          if (exercise && !usedExerciseNames.has(exercise.name)) {
            exercises.push(exercise)
            usedExerciseNames.add(exercise.name)
          }
        }
      }
    })

    return exercises.slice(0, 8) // Allow more exercises for specific goals
  }

  calculateExerciseScore(exercise, goal, type) {
    const ratings = exercise.ratings || { strength: 5, hypertrophy: 5, personal: 5 }
    let baseScore = 0
    
    if (goal === 'hypertrophy' || goal === 'v_shape') {
      baseScore = (ratings.hypertrophy || 5) * (ratings.personal || 5)
      if (exercise.stretch === true) baseScore *= 1.5
      if (exercise.painFree === true) baseScore *= 1.2
    } else if (goal === 'strength') {
      baseScore = (ratings.strength || 5) * (ratings.personal || 5)
      if (exercise.overload === 'excellent') baseScore *= 1.3
    }
    
    const priorityBonus = (6 - (exercise.priority || 5)) * 0.1
    return baseScore + priorityBonus
  }

  formatExercise(exercise, clientData, type, originalMuscleGroup, specificGoal = null) {
    const goal = clientData.primaryGoal
    let repRanges = goal === 'strength' ? 
      { compound: [3, 6], isolation: [6, 8] } : 
      { compound: [6, 10], isolation: [8, 12] }
    
    // Override rep ranges for specific goals
    if (specificGoal && specificGoal.repRangeOverride) {
      repRanges = specificGoal.repRangeOverride
    }
    
    let sets = 3
    if (clientData.experience === 'beginner') {
      sets = type === 'compound' ? 3 : 2
    } else if (clientData.experience === 'intermediate') {
      sets = type === 'compound' ? 3 : 3
    } else {
      sets = type === 'compound' ? 4 : 3
    }
    
    // Extra sets for priority exercises
    const isPriorityExercise = specificGoal && specificGoal.priorityExercises.includes(exercise.name)
    if (isPriorityExercise) {
      sets += 1 // Extra set for goal-specific exercises
      console.log(`🎯 Added bonus set to priority exercise: ${exercise.name}`)
    }
    
    const reps = type === 'compound' ? 
      `${repRanges.compound[0]}-${repRanges.compound[1]}` : 
      `${repRanges.isolation[0]}-${repRanges.isolation[1]}`
    
    const restTime = type === 'compound' ? '2-3 min' : '60-90s'
    const rpe = goal === 'strength' ? '8-9' : '9-10'
    
    let notes = ""
    if (goal === 'hypertrophy' || goal === 'v_shape') {
      if (exercise.stretch) {
        notes = "🔥 Focus on stretch position"
      }
      if (rpe === '9-10') {
        notes += notes ? " • Train to failure" : "Train to failure"
      }
    }

    if (isPriorityExercise) {
      const goalNote = `🎯 ${specificGoal.name} priority`
      notes = notes ? `${goalNote} • ${notes}` : goalNote
    }

    return {
      name: exercise.name,
      sets: sets,
      reps: reps,
      rust: restTime,
      rpe: rpe,
      equipment: exercise.equipment,
      primairSpieren: originalMuscleGroup || exercise.primary,
      type: type,
      stretch: exercise.stretch || false,
      priority: exercise.priority || 999,
      goalPriority: isPriorityExercise,
      notes: notes
    }
  }

  calculateVolumeDistribution(clientData, weekStructure) {
    const volumeCount = {}
    const guidelines = this.volumeGuidelines[clientData.experience]
    const specificGoal = clientData.specificGoal ? this.specificGoals[clientData.specificGoal] : null
    
    Object.values(weekStructure).forEach(day => {
      if (day.exercises) {
        day.exercises.forEach(exercise => {
          const muscle = exercise.primairSpieren
          if (!volumeCount[muscle]) volumeCount[muscle] = 0
          volumeCount[muscle] += exercise.sets
        })
      }
    })

    const volumeAnalysis = {
      weeklyVolume: volumeCount,
      guidelines: guidelines,
      warnings: [],
      recommendations: [],
      specificGoal: specificGoal
    }

    Object.keys(volumeCount).forEach(muscle => {
      const currentSets = volumeCount[muscle]
      let guideline = guidelines[muscle]
      
      // Adjust guidelines for specific goal bonuses
      if (specificGoal && specificGoal.volumeBonus && specificGoal.volumeBonus[muscle]) {
        const bonus = specificGoal.volumeBonus[muscle]
        guideline = {
          min: guideline.min + Math.floor(bonus / 2),
          max: guideline.max + bonus
        }
        console.log(`🎯 ${muscle} volume boosted for ${specificGoal.name}: +${bonus} sets`)
      }
      
      if (guideline) {
        if (currentSets < guideline.min) {
          volumeAnalysis.warnings.push(`${muscle}: ${currentSets} sets (below minimum ${guideline.min})`)
        } else if (currentSets > guideline.max) {
          volumeAnalysis.warnings.push(`${muscle}: ${currentSets} sets (above maximum ${guideline.max})`)
        }
      }
    })

    if (clientData.primaryGoal === 'hypertrophy' || clientData.primaryGoal === 'v_shape') {
      volumeAnalysis.recommendations.push("🎯 Train to failure (RPE 9-10)")
      volumeAnalysis.recommendations.push("🔥 Focus on stretch-tension exercises")
      volumeAnalysis.recommendations.push("⬇️ Controlled negative, explosive positive")
      volumeAnalysis.recommendations.push("💪 Using your personal exercise ratings")
    }

    if (specificGoal) {
      volumeAnalysis.recommendations.push(`🎯 ${specificGoal.name} specialization applied`)
      volumeAnalysis.recommendations.push(`📈 Priority exercises: ${specificGoal.priorityExercises.slice(0, 3).join(', ')}`)
    }

    return volumeAnalysis
  }
}

// ===== TOAST NOTIFICATION SYSTEM =====
function showToast(message, type = 'success') {
  const toast = document.createElement('div')
  toast.className = `fixed top-4 right-4 myarc-btn myarc-btn-primary font-semibold z-50 transform translate-x-full transition-transform duration-300 ${
    type === 'success' ? 'myarc-btn-primary' : 'myarc-btn-secondary'
  }`
  toast.textContent = message
  document.body.appendChild(toast)
  
  setTimeout(() => {
    toast.classList.remove('translate-x-full')
  }, 100)
  
  setTimeout(() => {
    toast.classList.add('translate-x-full')
    setTimeout(() => {
      if (document.body.contains(toast)) {
        document.body.removeChild(toast)
      }
    }, 300)
  }, 3000)
}

// ===== MAIN COMPONENT =====
export default function EnhancedAIWorkoutGenerator() {
  const [currentMode, setCurrentMode] = useState('generate')
  
  const [clientName, setClientName] = useState('')
  const [primaryGoal, setPrimaryGoal] = useState('')
  const [specificGoal, setSpecificGoal] = useState('') // NEW: Specific goal selection
  const [experience, setExperience] = useState('')
  const [daysPerWeek, setDaysPerWeek] = useState('')
  const [timePerSession, setTimePerSession] = useState('75')
  const [equipment, setEquipment] = useState(['full_gym'])
  
  // NEW: Split preferences system
  const [splitPreferences, setSplitPreferences] = useState({
    full_body: 0,
    upper_lower: 2,
    ppl: 1,
    arnold: 3,
    bro: 0,
    ppl_x2: 4
  })
  
  const [emphasizeStretch, setEmphasizeStretch] = useState(true)
  const [includeWeakpoint, setIncludeWeakpoint] = useState(false)
  const [prioritizeCompounds, setPrioritizeCompounds] = useState(true)
  const [addIntensityMethods, setAddIntensityMethods] = useState(false)
  const [usePersonalRatings, setUsePersonalRatings] = useState(true)
  const [applySpecificGoals, setApplySpecificGoals] = useState(true) // NEW
  const [generationType, setGenerationType] = useState('smart')

  const [currentSchema, setCurrentSchema] = useState(null)
  const [isGenerating, setIsGenerating] = useState(false)
  const [schemas, setSchemas] = useState(new Map())

  const [showExportMenu, setShowExportMenu] = useState(false)
  const [showExercisePicker, setShowExercisePicker] = useState(false)
  const [editingDayIndex, setEditingDayIndex] = useState(null)
  const [editingExerciseIndex, setEditingExerciseIndex] = useState(null)
  const [exerciseSearchTerm, setExerciseSearchTerm] = useState('')

  const [aiGenerator] = useState(() => new AISchemaGenerator())

  const equipmentOptions = [
    { value: 'full_gym', label: 'Full Gym' },
    { value: 'dumbbells', label: 'Dumbbells Only' },
    { value: 'barbell', label: 'Barbell Setup' },
    { value: 'home_minimal', label: 'Minimal Home' }
  ]

  // NEW: Split names mapping
  const splitNames = {
    'full_body': 'Full Body',
    'upper_lower': 'Upper/Lower', 
    'ppl': 'Push/Pull/Legs',
    'arnold': 'Arnold Split',
    'bro': 'Bro Split',
    'ppl_x2': 'PPL x2'
  }

  const handleEquipmentChange = (equipmentType) => {
    setEquipment(prev => 
      prev.includes(equipmentType)
        ? prev.filter(e => e !== equipmentType)
        : [...prev, equipmentType]
    )
  }

  // NEW: Split preference handler
  const handleSplitPreferenceChange = (splitType, value) => {
    setSplitPreferences(prev => ({
      ...prev,
      [splitType]: parseInt(value)
    }))
  }

  // NEW: Get top split preferences for display
  const getTopSplitPreferences = () => {
    return Object.entries(splitPreferences)
      .filter(([_, rank]) => rank > 0)
      .sort(([,a], [,b]) => a - b)
      .slice(0, 3)
      .map(([key, rank], index) => {
        const medal = ['🥇', '🥈', '🥉'][index] || '🏅'
        return `${medal} ${splitNames[key]}`
      }).join(' • ')
  }

  const generateAISchema = async () => {
    if (!primaryGoal || !experience || !daysPerWeek) {
      showToast('Please fill in all required fields', 'error')
      return
    }

    setIsGenerating(true)
    
    try {
      const clientData = {
        name: clientName || 'Client',
        primaryGoal,
        specificGoal: specificGoal || null, // NEW
        experience,
        daysPerWeek: parseInt(daysPerWeek),
        timePerSession: parseInt(timePerSession) || 75,
        equipment,
        splitPreferences, // NEW
        limitations: []
      }

      const options = {
        emphasizeStretch,
        includeWeakpoint,
        prioritizeCompounds,
        addIntensityMethods,
        usePersonalRatings,
        applySpecificGoals, // NEW
        generationType
      }

      console.log('🧠 Generating AI schema with options:', options)
      
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      const generatedSchema = aiGenerator.generateSchema(clientData, options)
      setCurrentSchema(generatedSchema)
      setCurrentMode('edit')
      
      setSchemas(prev => new Map(prev.set(generatedSchema.name, generatedSchema)))
      
      // NEW: Enhanced success message for specific goals
      let message = '🧠 AI Schema generated successfully!'
      if (specificGoal && SPECIFIC_GOALS[specificGoal]) {
        message = `🧠 AI Schema with ${SPECIFIC_GOALS[specificGoal]?.name} focus generated!`
      }
      
      showToast(message)
      
    } catch (error) {
      console.error('Error generating schema:', error)
      showToast('Error generating schema. Please try again.', 'error')
    } finally {
      setIsGenerating(false)
    }
  }

  const updateExercise = (dayIndex, exerciseIndex, field, value) => {
    if (!currentSchema) return
    
    const days = Object.keys(currentSchema.weekStructure)
    const dayKey = days[dayIndex]
    
    if (field === 'sets') {
      value = parseInt(value) || 1
    }
    
    setCurrentSchema(prev => {
      const updated = { ...prev }
      updated.weekStructure[dayKey].exercises[exerciseIndex][field] = value
      return updated
    })
  }

  const addExercise = (dayIndex) => {
    console.log('🔥 Add Exercise clicked for day:', dayIndex)
    setEditingDayIndex(dayIndex)
    setEditingExerciseIndex(-1)
    setShowExercisePicker(true)
    console.log('🔥 State updated - showExercisePicker should be true')
  }

  const removeExercise = (dayIndex, exerciseIndex) => {
    if (!currentSchema) return
    
    const days = Object.keys(currentSchema.weekStructure)
    const dayKey = days[dayIndex]
    
    setCurrentSchema(prev => {
      const updated = { ...prev }
      updated.weekStructure[dayKey].exercises.splice(exerciseIndex, 1)
      return updated
    })
  }

  const selectExercise = (exercise) => {
    if (!currentSchema || editingDayIndex === null) {
      console.log('❌ Cannot select exercise: missing schema or day index')
      return
    }
    
    // Prevent double execution
    if (showExercisePicker === false) {
      console.log('❌ Modal already closed, ignoring selection')
      return
    }
    
    const days = Object.keys(currentSchema.weekStructure)
    const dayKey = days[editingDayIndex]
    
    console.log('✅ Adding exercise:', exercise.name, 'to day:', dayKey)
    
    const newExercise = {
      name: exercise.name,
      sets: 3,
      reps: exercise.type === 'compound' ? '6-8' : '8-12',
      rust: exercise.type === 'compound' ? '2-3 minutes' : '60-90 seconds',
      rpe: '8-9',
      equipment: exercise.equipment,
      primairSpieren: exercise.primary || exercise.muscleGroup,
      type: exercise.type,
      stretch: exercise.stretch || false,
      goalPriority: false,
      notes: exercise.stretch ? "🔥 Focus on stretch position" : ""
    }
    
    // Close modal immediately to prevent double execution
    setShowExercisePicker(false)
    setExerciseSearchTerm('')
    setEditingDayIndex(null)
    setEditingExerciseIndex(null)
    
    setCurrentSchema(prev => {
      const updated = { ...prev }
      if (editingExerciseIndex === -1) {
        // Adding new exercise
        if (!updated.weekStructure[dayKey].exercises) {
          updated.weekStructure[dayKey].exercises = []
        }
        updated.weekStructure[dayKey].exercises.push(newExercise)
        console.log('✅ Exercise added successfully')
      } else {
        // Replacing existing exercise
        updated.weekStructure[dayKey].exercises[editingExerciseIndex] = newExercise
        console.log('✅ Exercise replaced successfully')
      }
      return updated
    })
    
    showToast(`Exercise "${exercise.name}" added successfully!`)
  }

  const getAllExercises = () => {
    const allExercises = []
    const db = aiGenerator.exerciseDatabase
    
    Object.keys(db).forEach(muscleGroup => {
      if (db[muscleGroup].compound) {
        db[muscleGroup].compound.forEach(exercise => {
          allExercises.push({
            ...exercise,
            muscleGroup: muscleGroup,
            type: 'compound'
          })
        })
      }
      if (db[muscleGroup].isolation) {
        db[muscleGroup].isolation.forEach(exercise => {
          allExercises.push({
            ...exercise,
            muscleGroup: muscleGroup,
            type: 'isolation'
          })
        })
      }
    })
    
    console.log('📊 All exercises loaded:', allExercises.length)
    return allExercises
  }

  const getFilteredExercises = () => {
    const allExercises = getAllExercises()
    
    return allExercises.filter(exercise => {
      const matchesSearch = !exerciseSearchTerm || 
        exercise.name.toLowerCase().includes(exerciseSearchTerm.toLowerCase())
      
      return matchesSearch
    }).sort((a, b) => {
      const avgA = a.ratings ? (a.ratings.strength + a.ratings.hypertrophy + a.ratings.personal) / 3 : 2
      const avgB = b.ratings ? (b.ratings.strength + b.ratings.hypertrophy + b.ratings.personal) / 3 : 2
      return avgB - avgA
    })
  }

  const calculateVolumeSummary = () => {
    if (!currentSchema?.weekStructure) return {}
    
    const volumeCount = {}
    Object.values(currentSchema.weekStructure).forEach(day => {
      if (day.exercises) {
        day.exercises.forEach(exercise => {
          const muscle = exercise.primairSpieren || 'unknown'
          if (!volumeCount[muscle]) volumeCount[muscle] = 0
          volumeCount[muscle] += parseInt(exercise.sets) || 0
        })
      }
    })
    
    return volumeCount
  }

  const exportSchema = (format) => {
    if (!currentSchema) {
      showToast('No schema to export', 'error')
      return
    }

    let exportText = ''
    
    switch (format) {
      case 'json':
        exportText = JSON.stringify(currentSchema, null, 2)
        break
      case 'text':
        exportText = formatSchemaAsText(currentSchema)
        break
      case 'code':
        exportText = `const schema = ${JSON.stringify(currentSchema, null, 2)};`
        break
      case 'workout':
        exportText = formatWorkoutOnly(currentSchema)
        break
      default:
        showToast('Unknown export format', 'error')
        return
    }

    navigator.clipboard.writeText(exportText).then(() => {
      showToast(`Schema exported as ${format.toUpperCase()}!`)
    }).catch(() => {
      showToast('Failed to export schema', 'error')
    })

    setShowExportMenu(false)
  }

  const formatSchemaAsText = (schema) => {
    let text = `🧬 ${schema.name}\n`
    text += `${schema.description}\n\n`
    
    // NEW: Include specific goal info
    if (schema.specificGoal) {
      text += `🎯 SPECIFIC GOAL: ${schema.specificGoal.name}\n`
      text += `${schema.specificGoal.description}\n\n`
    }
    
    if (schema.weekStructure) {
      text += `📅 WEEK STRUCTURE\n`
      Object.keys(schema.weekStructure).forEach(dayKey => {
        const day = schema.weekStructure[dayKey]
        text += `\n${day.name}\n`
        text += `Focus: ${day.focus}\n`
        text += `Duration: ${day.geschatteTijd}\n\n`
        
        if (day.exercises) {
          day.exercises.forEach((exercise, index) => {
            const goalIndicator = exercise.goalPriority ? '🎯 ' : '' // NEW
            const stretchIndicator = exercise.stretch ? '🔥 ' : ''
            text += `${index + 1}. ${goalIndicator}${stretchIndicator}${exercise.name}\n`
            text += `   ${exercise.sets} sets × ${exercise.reps} reps\n`
            text += `   Rest: ${exercise.rust} | RPE: ${exercise.rpe}\n`
            if (exercise.notes) text += `   Notes: ${exercise.notes}\n`
            text += `\n`
          })
        }
      })
    }
    
    return text
  }

  const formatWorkoutOnly = (schema) => {
    let text = `🏋️ WORKOUT PLAN\n\n`
    
    // NEW: Include specific goal in workout export
    if (schema.specificGoal) {
      text += `🎯 SPECIFIC GOAL: ${schema.specificGoal.name}\n`
      text += `${schema.specificGoal.description}\n\n`
    }
    
    if (schema.weekStructure) {
      Object.keys(schema.weekStructure).forEach(dayKey => {
        const day = schema.weekStructure[dayKey]
        text += `${day.name}\n`
        text += `${'-'.repeat(day.name.length)}\n`
        text += `Focus: ${day.focus}\n`
        text += `Duration: ${day.geschatteTijd}\n\n`
        
        if (day.exercises && day.exercises.length > 0) {
          day.exercises.forEach((exercise, index) => {
            const goalIndicator = exercise.goalPriority ? '🎯 ' : '' // NEW
            const stretchIndicator = exercise.stretch ? '🔥 ' : ''
            text += `${index + 1}. ${goalIndicator}${stretchIndicator}${exercise.name}\n`
            text += `   Sets: ${exercise.sets} | Reps: ${exercise.reps} | Rest: ${exercise.rust}\n`
            text += `   RPE: ${exercise.rpe} | Equipment: ${exercise.equipment}\n`
            if (exercise.notes) text += `   Notes: ${exercise.notes}\n`
            text += `\n`
          })
        }
        text += '\n'
      })
    }
    
    return text
  }

  const volumeSummary = calculateVolumeSummary()

  if (currentMode === 'edit' && currentSchema) {
    return (
      <div className="myarc-animate-in">
        <h1 className="myarc-text-green myarc-mb-xl" style={{fontSize: 'var(--text-2xl)', fontWeight: '900', textAlign: 'center'}}>✏️ Schema Editor</h1>
        
        {/* Header */}
        <div className="myarc-card myarc-mb-lg">
          <div className="myarc-flex myarc-items-center myarc-justify-between">
            <div>
              <h2 className="myarc-card-title">{currentSchema.name}</h2>
              <p className="myarc-text-gray">{currentSchema.description}</p>
            </div>
            <button 
              onClick={() => setCurrentMode('generate')}
              className="myarc-btn myarc-btn-secondary"
            >
              ← Back to Generator
            </button>
          </div>
        </div>

        {/* NEW: Specific Goal Info */}
        {currentSchema.specificGoal && (
          <div className="myarc-card myarc-mb-lg" style={{background: 'var(--c-bg-card)', border: '1px solid var(--c-accent)'}}>
            <div className="myarc-text-green" style={{fontWeight: 'medium', marginBottom: 'var(--s-2)'}}>
              🎯 {currentSchema.specificGoal.name}
            </div>
            <div className="myarc-text-white" style={{fontSize: 'var(--text-sm)', marginBottom: 'var(--s-2)'}}>
              {currentSchema.specificGoal.description}
            </div>
            <div className="myarc-text-gray" style={{fontSize: 'var(--text-xs)'}}>
              Priority exercises: {currentSchema.specificGoal.priorityExercises.slice(0, 5).join(', ')}
            </div>
          </div>
        )}

        {/* Schema Info Editor */}
        <div className="myarc-card myarc-mb-lg">
          <h3 className="myarc-card-title">📝 Schema Information</h3>
          <div className="myarc-grid myarc-grid-2 myarc-gap-md">
            <div>
              <label className="block myarc-text-gray myarc-mb-sm" style={{fontSize: 'var(--text-sm)'}}>Schema Name</label>
              <input 
                type="text" 
                value={currentSchema.name}
                onChange={(e) => setCurrentSchema(prev => ({ ...prev, name: e.target.value }))}
                className="myarc-input"
              />
            </div>
            <div>
              <label className="block myarc-text-gray myarc-mb-sm" style={{fontSize: 'var(--text-sm)'}}>Split Type</label>
              <select 
                value={currentSchema.splitOverview?.type || 'custom'}
                onChange={(e) => setCurrentSchema(prev => ({ 
                  ...prev, 
                  splitOverview: { ...prev.splitOverview, type: e.target.value }
                }))}
                className="myarc-input"
              >
                <option value="full_body">Full Body</option>
                <option value="upper_lower">Upper/Lower</option>
                <option value="ppl">Push/Pull/Legs</option>
                <option value="bro_split">Bro Split</option>
                <option value="custom">Custom</option>
              </select>
            </div>
            <div className="myarc-grid-2" style={{gridColumn: 'span 2'}}>
              <label className="block myarc-text-gray myarc-mb-sm" style={{fontSize: 'var(--text-sm)'}}>Description</label>
              <textarea 
                value={currentSchema.description}
                onChange={(e) => setCurrentSchema(prev => ({ ...prev, description: e.target.value }))}
                className="myarc-input"
                rows="2"
              />
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="myarc-flex myarc-gap-md myarc-mb-lg">
          <button 
onClick={async () => {
  try {
    if (!currentSchema) { showToast('No schema', 'error'); return }
    const user = await db.getCurrentUser()
    if (!user) { showToast('Please log in', 'error'); return }
    await saveWorkoutSchema(currentSchema, user)
    showToast('Saved to database! 💾')
  } catch (error) {
    showToast('Error saving', 'error')
  }
}}
            className="myarc-btn myarc-btn-primary"
          >
            💾 Save Schema
          </button>
          <div className="relative">
            <button 
              onClick={() => setShowExportMenu(!showExportMenu)}
              className="myarc-btn myarc-btn-secondary"
            >
              📤 Export ▼
            </button>
            {showExportMenu && (
              <div className="absolute top-full left-0 mt-2 myarc-card myarc-p-sm z-50" style={{minWidth: '200px'}}>
                <button onClick={() => exportSchema('json')} className="block w-full text-left myarc-p-sm hover:bg-var(--c-bg-card) myarc-text-gray">📄 JSON Format</button>
                <button onClick={() => exportSchema('text')} className="block w-full text-left myarc-p-sm hover:bg-var(--c-bg-card) myarc-text-gray">📝 Formatted Text</button>
                <button onClick={() => exportSchema('code')} className="block w-full text-left myarc-p-sm hover:bg-var(--c-bg-card) myarc-text-gray">💻 JavaScript Code</button>
                <button onClick={() => exportSchema('workout')} className="block w-full text-left myarc-p-sm hover:bg-var(--c-bg-card) myarc-text-gray">🏋️ Workout Plan Only</button>
              </div>
            )}
          </div>
        </div>

        {/* Days Editor */}
        <div className="myarc-flex myarc-flex-col myarc-gap-lg myarc-mb-lg">
          {currentSchema.weekStructure && Object.keys(currentSchema.weekStructure).map((dayKey, dayIndex) => {
            const day = currentSchema.weekStructure[dayKey]
            return (
              <div key={dayIndex} className="myarc-card">
                <div className="myarc-flex myarc-items-center myarc-justify-between myarc-mb-lg">
                  <div style={{flex: 1}}>
                    <input 
                      type="text" 
                      value={day.name}
                      onChange={(e) => setCurrentSchema(prev => {
                        const updated = { ...prev }
                        updated.weekStructure[dayKey].name = e.target.value
                        return updated
                      })}
                      className="myarc-text-green" 
                      style={{fontSize: 'var(--text-lg)', fontWeight: 'bold', background: 'transparent', border: 'none', outline: 'none'}}
                    />
                    <div className="myarc-text-gray myarc-mt-sm" style={{fontSize: 'var(--text-sm)'}}>
                      Focus: <span className="myarc-text-white">{day.focus}</span>
                    </div>
                    <div className="myarc-text-gray myarc-mt-sm" style={{fontSize: 'var(--text-xs)'}}>
                      Time: <span className="myarc-text-gray">{day.geschatteTijd || '75 minutes'}</span>
                    </div>
                  </div>
                  <div className="myarc-flex myarc-gap-sm">
                    <button 
                      onClick={() => addExercise(dayIndex)}
                      className="myarc-btn myarc-btn-primary"
                      style={{fontSize: 'var(--text-xs)', padding: 'var(--s-2) var(--s-3)'}}
                    >
                      ➕ Add Exercise
                    </button>
                  </div>
                </div>
                
                <div className="myarc-flex myarc-flex-col myarc-gap-sm">
                  {day.exercises && day.exercises.map((exercise, exerciseIndex) => {
                    const stretchIndicator = exercise.stretch ? '🔥 ' : ''
                    const goalPriorityIndicator = exercise.goalPriority ? '🎯 ' : '' // NEW
                    
                    return (
                      <div 
                        key={exerciseIndex} 
                        className="myarc-p-md" 
                        style={{
                          background: 'var(--c-bg-dark)', 
                          border: exercise.goalPriority ? '1px solid #fbbf24' : '1px solid var(--c-border)', // NEW: Golden border for priority
                          borderRadius: 'var(--radius)'
                        }}
                      >
                        <div className="myarc-flex myarc-items-center myarc-justify-between myarc-mb-sm">
                          <div style={{flex: 1}}>
                            <div className="myarc-text-white myarc-mb-sm" style={{fontWeight: 'medium'}}>
                              {goalPriorityIndicator}{stretchIndicator}
                              <input 
                                type="text"
                                value={exercise.name}
                                onChange={(e) => updateExercise(dayIndex, exerciseIndex, 'name', e.target.value)}
                                className="myarc-text-white"
                                style={{background: 'transparent', border: 'none', outline: 'none'}}
                              />
                              {/* NEW: Goal Priority Badge */}
                              {exercise.goalPriority && (
                                <span className="myarc-ml-sm" style={{
                                  background: '#fbbf24', 
                                  color: 'black', 
                                  padding: '2px 6px', 
                                  borderRadius: '4px',
                                  fontSize: 'var(--text-xs)',
                                  fontWeight: 'bold'
                                }}>⭐ Goal Priority</span>
                              )}
                            </div>
                            <div className="myarc-text-gray" style={{fontSize: 'var(--text-sm)'}}>
                              Equipment: {exercise.equipment} • Target: <span className="myarc-text-green">{exercise.primairSpieren}</span>
                            </div>
                            {exercise.notes && (
                              <div className="myarc-text-green myarc-mt-sm" style={{fontSize: 'var(--text-xs)'}}>{exercise.notes}</div>
                            )}
                          </div>
                          <button 
                            onClick={() => removeExercise(dayIndex, exerciseIndex)}
                            className="myarc-text-gray hover:myarc-text-white myarc-ml-md" 
                            style={{fontSize: 'var(--text-sm)'}}
                          >
                            ✕
                          </button>
                        </div>
                        <div className="myarc-grid myarc-grid-4 myarc-gap-md" style={{fontSize: 'var(--text-sm)'}}>
                          <div>
                            <label className="block myarc-text-gray myarc-mb-sm" style={{fontSize: 'var(--text-xs)'}}>Sets</label>
                            <input 
                              type="number" 
                              value={exercise.sets}
                              onChange={(e) => updateExercise(dayIndex, exerciseIndex, 'sets', e.target.value)}
                              className="myarc-input"
                              style={{fontSize: 'var(--text-xs)', padding: 'var(--s-1) var(--s-2)'}}
                            />
                          </div>
                          <div>
                            <label className="block myarc-text-gray myarc-mb-sm" style={{fontSize: 'var(--text-xs)'}}>Reps</label>
                            <input 
                              type="text" 
                              value={exercise.reps}
                              onChange={(e) => updateExercise(dayIndex, exerciseIndex, 'reps', e.target.value)}
                              className="myarc-input"
                              style={{fontSize: 'var(--text-xs)', padding: 'var(--s-1) var(--s-2)'}}
                            />
                          </div>
                          <div>
                            <label className="block myarc-text-gray myarc-mb-sm" style={{fontSize: 'var(--text-xs)'}}>Rest</label>
                            <input 
                              type="text" 
                              value={exercise.rust || '60s'}
                              onChange={(e) => updateExercise(dayIndex, exerciseIndex, 'rust', e.target.value)}
                              className="myarc-input"
                              style={{fontSize: 'var(--text-xs)', padding: 'var(--s-1) var(--s-2)'}}
                            />
                          </div>
                          <div>
                            <label className="block myarc-text-gray myarc-mb-sm" style={{fontSize: 'var(--text-xs)'}}>RPE</label>
                            <input 
                              type="text" 
                              value={exercise.rpe || '8'}
                              onChange={(e) => updateExercise(dayIndex, exerciseIndex, 'rpe', e.target.value)}
                              className="myarc-input"
                              style={{fontSize: 'var(--text-xs)', padding: 'var(--s-1) var(--s-2)'}}
                            />
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            )
          })}
        </div>

        {/* Volume Summary */}
        <div className="myarc-card">
          <h3 className="myarc-card-title">📊 Volume Summary</h3>
          <div className="myarc-grid myarc-grid-4 myarc-gap-lg">
            {Object.keys(volumeSummary).map(muscle => {
              const sets = volumeSummary[muscle]
              let colorClass = 'myarc-text-green'
              if (sets < 8) colorClass = 'text-red-400'
              else if (sets > 16) colorClass = 'text-yellow-400'
              
              return (
                <div key={muscle} style={{textAlign: 'center'}}>
                  <div className="myarc-text-gray" style={{fontSize: 'var(--text-sm)', textTransform: 'capitalize'}}>{muscle}</div>
                  <div className={`${colorClass}`} style={{fontSize: 'var(--text-lg)', fontWeight: 'bold'}}>{sets} sets</div>
                  <div className="myarc-text-gray" style={{fontSize: 'var(--text-xs)'}}>Target: 10-16</div>
                </div>
              )
            })}
          </div>
        </div>

        {/* Exercise Picker Modal */}
        {showExercisePicker && (
          <div 
            style={{
              position: 'fixed',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              backgroundColor: 'rgba(0, 0, 0, 0.8)',
              zIndex: 999999,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              padding: '20px'
            }}
          >
            <div 
              style={{
                backgroundColor: '#1a1a1a',
                border: '2px solid #10b981',
                borderRadius: '8px',
                maxHeight: '80vh',
                width: '100%',
                maxWidth: '800px',
                display: 'flex',
                flexDirection: 'column',
                boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)'
              }}
            >
              {/* Header */}
              <div 
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  padding: '20px',
                  borderBottom: '1px solid #374151',
                  backgroundColor: '#111'
                }}
              >
                <h3 style={{fontSize: '20px', fontWeight: 'bold', color: '#10b981', margin: 0}}>
                  🏋️ Select Exercise
                </h3>
                <button 
                  onClick={() => {
                    console.log('🔥 Closing modal')
                    setShowExercisePicker(false)
                    setExerciseSearchTerm('')
                  }}
                  style={{
                    color: '#9ca3af',
                    fontSize: '24px',
                    background: 'none',
                    border: 'none',
                    cursor: 'pointer'
                  }}
                >
                  ×
                </button>
              </div>
              
              {/* Search */}
              <div style={{padding: '20px', borderBottom: '1px solid #374151'}}>
                <input 
                  type="text" 
                  value={exerciseSearchTerm}
                  onChange={(e) => setExerciseSearchTerm(e.target.value)}
                  placeholder="Search exercises..."
                  style={{
                    width: '100%',
                    padding: '12px',
                    borderRadius: '6px',
                    backgroundColor: '#374151',
                    border: '1px solid #10b981',
                    color: 'white',
                    fontSize: '14px'
                  }}
                />
                <div style={{color: '#9ca3af', fontSize: '12px', marginTop: '8px'}}>
                  Showing {getFilteredExercises().length} exercises
                </div>
              </div>
              
              {/* Exercise List */}
              <div style={{padding: '20px', overflowY: 'auto', flex: 1, minHeight: '300px'}}>
                <div style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fit, minmax(350px, 1fr))',
                  gap: '16px'
                }}>
                  {getFilteredExercises().map((exercise, index) => {
                    const stretchIndicator = exercise.stretch ? '🔥 ' : ''
                    const priorityIndicator = exercise.priority === 1 ? '⭐ ' : ''
                    const painFreeIndicator = exercise.painFree ? '✅ ' : '⚠️ '
                    
                    const ratings = exercise.ratings || { strength: 5, hypertrophy: 5, personal: 5 }
                    
                    return (
                      <div 
                        key={`${exercise.muscleGroup}-${exercise.type}-${index}`}
                        onClick={() => {
                          console.log('🔥 Exercise selected:', exercise.name)
                          selectExercise(exercise)
                        }}
                        style={{
                          padding: '16px',
                          cursor: 'pointer',
                          borderRadius: '6px',
                          border: '1px solid #374151',
                          backgroundColor: '#1f2937',
                          transition: 'background-color 0.2s'
                        }}
                        onMouseEnter={(e) => e.target.style.backgroundColor = '#374151'}
                        onMouseLeave={(e) => e.target.style.backgroundColor = '#1f2937'}
                      >
                        <div style={{color: 'white', fontWeight: '500', fontSize: '14px', marginBottom: '8px'}}>
                          {priorityIndicator}{stretchIndicator}{painFreeIndicator}{exercise.name}
                        </div>
                        <div style={{color: '#9ca3af', fontSize: '12px', marginBottom: '8px'}}>
                          {exercise.muscleGroup} • {exercise.type} • {exercise.equipment}
                        </div>
                        <div style={{display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap'}}>
                          {ratings.strength > 5 && (
                            <span style={{
                              fontSize: '12px',
                              padding: '2px 6px',
                              borderRadius: '4px',
                              backgroundColor: '#3b82f6',
                              color: 'white'
                            }}>
                              💪{ratings.strength}
                            </span>
                          )}
                          {ratings.hypertrophy > 5 && (
                            <span style={{
                              fontSize: '12px',
                              padding: '2px 6px',
                              borderRadius: '4px',
                              backgroundColor: '#ef4444',
                              color: 'white'
                            }}>
                              🔥{ratings.hypertrophy}
                            </span>
                          )}
                          {ratings.personal > 5 && (
                            <span style={{
                              fontSize: '12px',
                              padding: '2px 6px',
                              borderRadius: '4px',
                              backgroundColor: '#ec4899',
                              color: 'white'
                            }}>
                              ❤️{ratings.personal}
                            </span>
                          )}
                          {exercise.stretch && (
                            <div style={{fontSize: '12px', color: '#10b981'}}>
                              Stretch-tension
                            </div>
                          )}
                        </div>
                      </div>
                    )
                  })}
                </div>
                
                {getFilteredExercises().length === 0 && (
                  <div style={{textAlign: 'center', color: '#9ca3af', padding: '48px 0'}}>
                    <div style={{fontSize: '32px', marginBottom: '16px'}}>🔍</div>
                    <div style={{fontSize: '18px', fontWeight: '500', marginBottom: '8px'}}>
                      No exercises found
                    </div>
                    <div style={{fontSize: '14px'}}>
                      Try a different search term or clear the search to see all exercises
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    )
  }

  return (
    <div className="myarc-animate-in">
      <h1 className="myarc-text-green myarc-mb-xl" style={{fontSize: 'var(--text-2xl)', fontWeight: '900', textAlign: 'center'}}>🧬 AI Workout Generator + Editor</h1>
      <p className="myarc-text-gray myarc-mb-xl" style={{textAlign: 'center', fontSize: 'var(--text-lg)', fontWeight: 'medium'}}>Generate with AI • Edit Everything • Export Perfect Plans</p>

      <div className="myarc-grid myarc-grid-2 myarc-gap-xl">
        {/* Input Form */}
        <div className="myarc-card">
          <div className="myarc-flex myarc-items-center myarc-justify-between myarc-mb-lg">
            <h2 className="myarc-card-title">🧠 AI Schema Generator</h2>
          </div>
          
          <div className="myarc-flex myarc-flex-col myarc-gap-lg">
            {/* Basic Info */}
            <div>
              <label className="block myarc-text-gray myarc-mb-sm" style={{fontSize: 'var(--text-sm)', fontWeight: 'medium'}}>Client Name</label>
              <input 
                type="text" 
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                placeholder="Enter client name"
                className="myarc-input"
              />
            </div>

            {/* Primary Goal */}
            <div>
              <label className="block myarc-text-gray myarc-mb-md" style={{fontSize: 'var(--text-sm)', fontWeight: 'medium'}}>🎯 Primary Goal</label>
              <div className="myarc-flex myarc-flex-col myarc-gap-md">
                {[
                  { value: 'strength', label: '💪 Strength', desc: 'Main lifts, 3-6 reps, progressive overload' },
                  { value: 'hypertrophy', label: '🔥 Hypertrophy', desc: 'Muscle growth, stretch-tension focus' },
                  { value: 'v_shape', label: '📐 V-Shape', desc: 'Lat width + lateral delt specialization' }
                ].map(goal => (
                  <label 
                    key={goal.value}
                    className={`block myarc-p-lg myarc-card cursor-pointer transition-colors ${
                      primaryGoal === goal.value 
                        ? 'border-green-500 bg-green-900/20' 
                        : 'hover:bg-var(--c-bg-card)'
                    }`}
                    style={{border: primaryGoal === goal.value ? '1px solid var(--c-accent)' : '1px solid var(--c-border)'}}
                  >
                    <input 
                      type="radio" 
                      name="primaryGoal" 
                      value={goal.value}
                      checked={primaryGoal === goal.value}
                      onChange={(e) => setPrimaryGoal(e.target.value)}
                      className="myarc-checkbox"
                      style={{marginRight: 'var(--s-3)'}}
                    />
                    <div style={{display: 'inline-block'}}>
                      <div className="myarc-text-green" style={{fontWeight: 'medium'}}>{goal.label}</div>
                      <div className="myarc-text-gray" style={{fontSize: 'var(--text-sm)'}}>{goal.desc}</div>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            {/* NEW: Specific Goals Section */}
            <div className="myarc-card" style={{background: 'var(--c-bg-dark)', border: '1px solid var(--c-accent)'}}>
              <label className="block myarc-text-gray myarc-mb-md" style={{fontSize: 'var(--text-sm)', fontWeight: 'medium'}}>
                🎯 Specific Focus Goal (Optional)
                <div className="myarc-text-gray" style={{fontSize: 'var(--text-xs)', marginTop: 'var(--s-1)'}}>Add a specific priority to your main goal</div>
              </label>
              <select 
                value={specificGoal}
                onChange={(e) => setSpecificGoal(e.target.value)}
                className="myarc-input"
              >
                <option value="">No specific focus</option>
                <optgroup label="🏋️ Strength Specialization">
                  <option value="bench_strength">Bench Press Strength</option>
                  <option value="squat_strength">Squat Strength</option>
                  <option value="deadlift_strength">Deadlift Strength</option>
                  <option value="ohp_strength">Overhead Press Strength</option>
                  <option value="pullup_strength">Pull-up Strength (10+ reps)</option>
                </optgroup>
                <optgroup label="🔥 Hypertrophy Specialization">
                  <option value="lat_width">Lat Width Development</option>
                  <option value="shoulder_width">Shoulder Width (V-Shape)</option>
                  <option value="tricep_size">Tricep Mass</option>
                  <option value="bicep_peaks">Bicep Peaks</option>
                  <option value="glute_dev">Glute Development</option>
                  <option value="chest_thickness">Chest Thickness</option>
                  <option value="back_thickness">Back Thickness</option>
                </optgroup>
                <optgroup label="🎪 Skill & Performance">
                  <option value="handstand_prog">Handstand Progression</option>
                  <option value="pistol_squat">Pistol Squat Progression</option>
                  <option value="muscle_up">Muscle-up Progression</option>
                </optgroup>
              </select>
              
              {/* NEW: Goal Combination Preview */}
              {specificGoal && SPECIFIC_GOALS[specificGoal] && (
                <div className="myarc-card myarc-mt-md" style={{background: 'var(--c-bg-card)', border: '1px solid var(--c-accent)'}}>
                  <div className="myarc-text-green" style={{fontWeight: 'medium', marginBottom: 'var(--s-2)'}}>🎯 Goal Combination:</div>
                  <div className="myarc-text-white" style={{fontSize: 'var(--text-sm)'}}>
                    {primaryGoal.charAt(0).toUpperCase() + primaryGoal.slice(1)} + {SPECIFIC_GOALS[specificGoal].name}
                  </div>
                  <div className="myarc-text-yellow-400" style={{fontSize: 'var(--text-xs)', marginTop: 'var(--s-2)'}}>
                    Priority exercises: {SPECIFIC_GOALS[specificGoal].priorityExercises.slice(0, 3).join(', ')}
                  </div>
                </div>
              )}
            </div>

            {/* Experience Level */}
            <div>
              <label className="block myarc-text-gray myarc-mb-sm" style={{fontSize: 'var(--text-sm)', fontWeight: 'medium'}}>📈 Experience Level</label>
              <select 
                value={experience}
                onChange={(e) => setExperience(e.target.value)}
                className="myarc-input"
              >
                <option value="">Select experience level</option>
                <option value="beginner">Beginner (0-18 months)</option>
                <option value="intermediate">Intermediate (1.5-3 years)</option>
                <option value="advanced">Advanced (3+ years)</option>
              </select>
            </div>

            {/* Days per Week */}
            <div>
              <label className="block myarc-text-gray myarc-mb-sm" style={{fontSize: 'var(--text-sm)', fontWeight: 'medium'}}>📅 Training Days per Week</label>
              <select 
                value={daysPerWeek}
                onChange={(e) => setDaysPerWeek(e.target.value)}
                className="myarc-input"
              >
                <option value="">Select training frequency</option>
                <option value="3">3 days per week</option>
                <option value="4">4 days per week</option>
                <option value="5">5 days per week</option>
                <option value="6">6 days per week</option>
              </select>
            </div>

            {/* Time per Session */}
            <div>
              <label className="block myarc-text-gray myarc-mb-sm" style={{fontSize: 'var(--text-sm)', fontWeight: 'medium'}}>⏱️ Time per Session</label>
              <select 
                value={timePerSession}
                onChange={(e) => setTimePerSession(e.target.value)}
                className="myarc-input"
              >
                <option value="">Select session duration</option>
                <option value="45">45 minutes</option>
                <option value="60">60 minutes</option>
                <option value="75">75 minutes</option>
                <option value="90">90 minutes</option>
              </select>
            </div>

            {/* NEW: Split Preferences */}
            <div className="myarc-card" style={{background: 'var(--c-bg-dark)', border: '1px solid var(--c-accent)'}}>
              <label className="block myarc-text-gray myarc-mb-md" style={{fontSize: 'var(--text-sm)', fontWeight: 'medium'}}>
                📊 Split Preferences (Rank 1-5)
                <div className="myarc-text-gray" style={{fontSize: 'var(--text-xs)', marginTop: 'var(--s-1)'}}>AI will create schemas for your top 3 preferred splits</div>
              </label>
              <div className="myarc-flex myarc-flex-col myarc-gap-md">
                {Object.entries(splitNames).map(([key, name]) => (
                  <div key={key} className="myarc-flex myarc-items-center myarc-justify-between myarc-p-md myarc-card" style={{background: 'var(--c-bg)', border: '1px solid var(--c-border)'}}>
                    <div style={{flex: 1}}>
                      <div className="myarc-text-white" style={{fontWeight: 'medium'}}>
                        {key === 'full_body' && '💪 '}
                        {key === 'upper_lower' && '🔄 '}
                        {key === 'ppl' && '🔄 '}
                        {key === 'arnold' && '💪 '}
                        {key === 'bro' && '🎯 '}
                        {key === 'ppl_x2' && '🔥 '}
                        {name}
                      </div>
                      <div className="myarc-text-gray" style={{fontSize: 'var(--text-xs)'}}>
                        {key === 'full_body' && '3 exercises per muscle group, perfect for beginners'}
                        {key === 'upper_lower' && 'Classic split, great for strength and balance'}
                        {key === 'ppl' && 'Popular 3-day cycle, excellent for hypertrophy'}
                        {key === 'arnold' && 'Chest/Back, Shoulders/Arms, Legs - classic combo'}
                        {key === 'bro' && '1 muscle per day, maximum focus per session'}
                        {key === 'ppl_x2' && 'Push/Pull/Legs twice per week, high volume'}
                      </div>
                    </div>
                    <select 
                      value={splitPreferences[key]}
                      onChange={(e) => handleSplitPreferenceChange(key, e.target.value)}
                      className="myarc-input"
                      style={{width: '80px', fontSize: 'var(--text-sm)'}}
                    >
                      <option value="0">Skip</option>
                      <option value="1">1st</option>
                      <option value="2">2nd</option>
                      <option value="3">3rd</option>
                      <option value="4">4th</option>
                      <option value="5">5th</option>
                    </select>
                  </div>
                ))}
              </div>
              
              {/* NEW: Rankings Preview */}
              {getTopSplitPreferences() && (
                <div className="myarc-card myarc-mt-md" style={{background: 'var(--c-bg-card)', border: '1px solid var(--c-accent)'}}>
                  <div className="myarc-text-green" style={{fontWeight: 'medium', marginBottom: 'var(--s-2)'}}>📊 Your Split Rankings:</div>
                  <div className="myarc-text-white" style={{fontSize: 'var(--text-sm)'}}>{getTopSplitPreferences()}</div>
                  <div className="myarc-text-yellow-400" style={{fontSize: 'var(--text-xs)', marginTop: 'var(--s-2)'}}>AI will create schemas for your top 3 choices</div>
                </div>
              )}
            </div>

            {/* Equipment */}
            <div>
              <label className="block myarc-text-gray myarc-mb-md" style={{fontSize: 'var(--text-sm)', fontWeight: 'medium'}}>🏋️ Available Equipment</label>
              <div className="myarc-grid myarc-grid-2 myarc-gap-md">
                {equipmentOptions.map(eq => (
                  <label key={eq.value} className="myarc-flex myarc-items-center myarc-text-gray cursor-pointer">
                    <input 
                      type="checkbox" 
                      value={eq.value}
                      checked={equipment.includes(eq.value)}
                      onChange={() => handleEquipmentChange(eq.value)}
                      className="myarc-checkbox"
                      style={{marginRight: 'var(--s-2)'}}
                    />
                    <span style={{fontSize: 'var(--text-sm)'}}>{eq.label}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Generate Button */}
            <button 
              onClick={generateAISchema}
              disabled={isGenerating || !primaryGoal || !experience || !daysPerWeek}
              className="myarc-btn myarc-btn-primary"
              style={{fontSize: 'var(--text-lg)', fontWeight: 'bold', padding: 'var(--s-4) var(--s-6)'}}
            >
              {isGenerating ? (
                <>
                  <div className="inline-block animate-spin rounded-full h-4 w-4 mr-2" style={{border: '2px solid var(--c-bg)', borderTop: '2px solid transparent'}}></div>
                  🧠 Generating AI Plan...
                </>
              ) : (
                '⚡ Generate AI Workout Plan'
              )}
            </button>
            
            {(!primaryGoal || !experience || !daysPerWeek) && (
              <p className="myarc-text-gray" style={{fontSize: 'var(--text-sm)', textAlign: 'center'}}>Please fill in all required fields (*) to generate</p>
            )}
          </div>
        </div>

        {/* AI Generation Options */}
        <div className="myarc-card">
          <h2 className="myarc-card-title">⚙️ Generation Options</h2>
          
          <div className="myarc-flex myarc-flex-col myarc-gap-lg myarc-mb-lg">
            <div 
              onClick={() => setGenerationType('smart')}
              className={`myarc-p-lg cursor-pointer transition-colors ${
                generationType === 'smart' 
                  ? 'border-green-500 bg-green-900/20' 
                  : 'hover:bg-var(--c-bg-card)'
              }`}
              style={{border: generationType === 'smart' ? '1px solid var(--c-accent)' : '1px solid var(--c-border)', borderRadius: 'var(--radius)'}}
            >
              <div className="myarc-text-green myarc-mb-sm" style={{fontWeight: 'medium'}}>🧠 Smart Generation</div>
              <div className="myarc-text-gray" style={{fontSize: 'var(--text-sm)'}}>AI analyzes your inputs and creates optimal schema using Nippard principles + your personal ratings + specific goals</div>
            </div>
            
            <div 
              onClick={() => setGenerationType('hybrid')}
              className={`myarc-p-lg cursor-pointer transition-colors ${
                generationType === 'hybrid' 
                  ? 'border-green-500 bg-green-900/20' 
                  : 'hover:bg-var(--c-bg-card)'
              }`}
              style={{border: generationType === 'hybrid' ? '1px solid var(--c-accent)' : '1px solid var(--c-border)', borderRadius: 'var(--radius)'}}
            >
              <div className="myarc-text-green myarc-mb-sm" style={{fontWeight: 'medium'}}>🔀 Hybrid Approach</div>
              <div className="myarc-text-gray" style={{fontSize: 'var(--text-sm)'}}>Combines existing schemas with AI modifications for your specific needs</div>
            </div>
            
            <div 
              onClick={() => setGenerationType('template')}
              className={`myarc-p-lg cursor-pointer transition-colors ${
                generationType === 'template' 
                  ? 'border-green-500 bg-green-900/20' 
                  : 'hover:bg-var(--c-bg-card)'
              }`}
              style={{border: generationType === 'template' ? '1px solid var(--c-accent)' : '1px solid var(--c-border)', borderRadius: 'var(--radius)'}}
            >
              <div className="myarc-text-green myarc-mb-sm" style={{fontWeight: 'medium'}}>📋 Template Base</div>
              <div className="myarc-text-gray" style={{fontSize: 'var(--text-sm)'}}>Starts with proven template and customizes for your goals</div>
            </div>
          </div>

          <div className="myarc-mt-lg">
            <h3 className="myarc-text-white myarc-mb-md" style={{fontWeight: 'medium'}}>🎛️ Fine-tuning Options</h3>
            <div className="myarc-flex myarc-flex-col myarc-gap-md">
              <label className="myarc-flex myarc-items-center myarc-text-gray cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={emphasizeStretch}
                  onChange={(e) => setEmphasizeStretch(e.target.checked)}
                  className="myarc-checkbox"
                  style={{marginRight: 'var(--s-2)'}}
                />
                <span style={{fontSize: 'var(--text-sm)'}}>Emphasize stretch-tension exercises</span>
              </label>
              <label className="myarc-flex myarc-items-center myarc-text-gray cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={includeWeakpoint}
                  onChange={(e) => setIncludeWeakpoint(e.target.checked)}
                  className="myarc-checkbox"
                  style={{marginRight: 'var(--s-2)'}}
                />
                <span style={{fontSize: 'var(--text-sm)'}}>Include weak-point blocks</span>
              </label>
              <label className="myarc-flex myarc-items-center myarc-text-gray cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={prioritizeCompounds}
                  onChange={(e) => setPrioritizeCompounds(e.target.checked)}
                  className="myarc-checkbox"
                  style={{marginRight: 'var(--s-2)'}}
                />
                <span style={{fontSize: 'var(--text-sm)'}}>Prioritize compound movements</span>
              </label>
              <label className="myarc-flex myarc-items-center myarc-text-gray cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={addIntensityMethods}
                  onChange={(e) => setAddIntensityMethods(e.target.checked)}
                  className="myarc-checkbox"
                  style={{marginRight: 'var(--s-2)'}}
                />
                <span style={{fontSize: 'var(--text-sm)'}}>Add intensity methods (myo-reps, drop sets)</span>
              </label>
              <label className="myarc-flex myarc-items-center myarc-text-gray cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={usePersonalRatings}
                  onChange={(e) => setUsePersonalRatings(e.target.checked)}
                  className="myarc-checkbox"
                  style={{marginRight: 'var(--s-2)'}}
                />
                <span style={{fontSize: 'var(--text-sm)'}}>Use personal exercise ratings for selection</span>
              </label>
              {/* NEW: Apply Specific Goals Option */}
              <label className="myarc-flex myarc-items-center myarc-text-gray cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={applySpecificGoals}
                  onChange={(e) => setApplySpecificGoals(e.target.checked)}
                  className="myarc-checkbox"
                  style={{marginRight: 'var(--s-2)'}}
                />
                <span style={{fontSize: 'var(--text-sm)'}}>Apply specific goal priorities</span>
              </label>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}


