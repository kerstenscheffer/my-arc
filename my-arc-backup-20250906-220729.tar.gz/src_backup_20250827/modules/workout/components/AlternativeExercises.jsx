// src/modules/workout/components/AlternativeExercises.jsx
import { useState, useEffect } from 'react'
import { ChevronRight, Search, X, Activity, Dumbbell, Filter, TrendingUp } from 'lucide-react'
import WorkoutService from '../WorkoutService'
import EXERCISE_DATABASE from '../constants/exerciseDatabase'

export default function AlternativeExercises({ exercise, onSelect, onClose, db }) {
  const [alternatives, setAlternatives] = useState([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('all')
  const isMobile = window.innerWidth <= 768
  
  // Create service instance with db
  const workoutService = new WorkoutService(db)
  
  useEffect(() => {
    loadAlternatives()
  }, [exercise])
  
  const loadAlternatives = async () => {
    setLoading(true)
    
    try {
      // Try database first
      const dbAlternatives = await workoutService.getAlternativeExercises(
        exercise.muscleGroup || 'chest'
      )
      
      if (dbAlternatives.length > 0) {
        setAlternatives(dbAlternatives)
      } else {
        // Fallback to local database
        const localAlternatives = getLocalAlternatives(exercise.muscleGroup || 'chest')
        setAlternatives(localAlternatives)
      }
    } catch (error) {
      console.error('Error loading alternatives:', error)
      // Use local database as fallback
      const localAlternatives = getLocalAlternatives(exercise.muscleGroup || 'chest')
      setAlternatives(localAlternatives)
    }
    
    setLoading(false)
  }
  
  const getLocalAlternatives = (muscleGroup) => {
    const group = muscleGroup.toLowerCase()
    const alternatives = []
    
    if (EXERCISE_DATABASE[group]) {
      // Add compound exercises
      if (EXERCISE_DATABASE[group].compound) {
        EXERCISE_DATABASE[group].compound.forEach(name => {
          alternatives.push({
            name,
            type: 'compound',
            id: `${group}_compound_${name}`
          })
        })
      }
      
      // Add isolation exercises
      if (EXERCISE_DATABASE[group].isolation) {
        EXERCISE_DATABASE[group].isolation.forEach(name => {
          alternatives.push({
            name,
            type: 'isolation',
            id: `${group}_isolation_${name}`
          })
        })
      }
    }
    
    return alternatives
  }
  
  // Filter alternatives based on search and category
  const filteredAlternatives = alternatives.filter(alt => {
    const matchesSearch = alt.name.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === 'all' || alt.type === selectedCategory
    return matchesSearch && matchesCategory
  })
  
  // Group alternatives by type
  const groupedAlternatives = {
    compound: filteredAlternatives.filter(a => a.type === 'compound'),
    isolation: filteredAlternatives.filter(a => a.type === 'isolation')
  }
  
  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: 'rgba(0,0,0,0.95)',
      zIndex: 1001,
      display: 'flex',
      alignItems: 'flex-end',
      animation: 'fadeIn 0.2s ease',
      backdropFilter: 'blur(20px)'
    }}
    onClick={onClose}
    >
      <div 
        style={{
          width: '100%',
          background: 'linear-gradient(180deg, #171717 0%, #0a0a0a 100%)',
          borderRadius: '24px 24px 0 0',
          padding: '1.5rem 1rem 2rem',
          maxHeight: isMobile ? '90vh' : '85vh',
          display: 'flex',
          flexDirection: 'column',
          animation: 'slideUp 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
          boxShadow: '0 -10px 40px rgba(249, 115, 22, 0.1)',
          border: '1px solid rgba(249, 115, 22, 0.1)',
          borderBottom: 'none'
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Handle Bar */}
        <div style={{
          width: '48px',
          height: '5px',
          background: 'rgba(249, 115, 22, 0.3)',
          borderRadius: '3px',
          margin: '0 auto 1.5rem',
          cursor: 'grab'
        }} />
        
        {/* Header */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: '1rem'
        }}>
          <div>
            <h3 style={{
              fontSize: isMobile ? '1.2rem' : '1.3rem',
              background: 'linear-gradient(135deg, #f97316 0%, #ea580c 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              margin: '0 0 0.25rem 0',
              fontWeight: '800'
            }}>
              Alternatieve Oefeningen
            </h3>
            <p style={{
              fontSize: '0.85rem',
              color: 'rgba(255,255,255,0.5)',
              margin: 0,
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem'
            }}>
              <Dumbbell size={14} />
              {exercise.muscleGroup 
                ? `${exercise.muscleGroup.charAt(0).toUpperCase() + exercise.muscleGroup.slice(1)} oefeningen`
                : 'Selecteer vervanging'}
            </p>
          </div>
          <button
            onClick={onClose}
            style={{
              background: 'rgba(255,255,255,0.05)',
              border: '1px solid rgba(255,255,255,0.1)',
              borderRadius: '12px',
              width: '40px',
              height: '40px',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              transition: 'all 0.2s ease'
            }}
          >
            <X size={18} color="rgba(255,255,255,0.5)" />
          </button>
        </div>
        
        {/* Current Exercise */}
        <div style={{
          background: 'linear-gradient(135deg, rgba(249, 115, 22, 0.1) 0%, rgba(234, 88, 12, 0.05) 100%)',
          border: '1px solid rgba(249, 115, 22, 0.2)',
          borderRadius: '14px',
          padding: '1rem',
          marginBottom: '1rem',
          display: 'flex',
          alignItems: 'center',
          gap: '0.75rem'
        }}>
          <div style={{
            width: '40px',
            height: '40px',
            borderRadius: '10px',
            background: 'linear-gradient(135deg, #f97316 0%, #ea580c 100%)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexShrink: 0
          }}>
            <Activity size={18} color="#fff" />
          </div>
          <div>
            <p style={{
              fontSize: '0.7rem',
              color: '#f97316',
              margin: '0 0 0.15rem 0',
              fontWeight: '700',
              textTransform: 'uppercase',
              letterSpacing: '0.05em'
            }}>
              Huidige oefening
            </p>
            <p style={{
              fontSize: isMobile ? '0.95rem' : '1rem',
              color: '#fff',
              margin: 0,
              fontWeight: '700'
            }}>
              {exercise.name}
            </p>
          </div>
        </div>
        
        {/* Search Bar */}
        <div style={{
          position: 'relative',
          marginBottom: '1rem'
        }}>
          <Search 
            size={18} 
            style={{
              position: 'absolute',
              left: '14px',
              top: '50%',
              transform: 'translateY(-50%)',
              color: 'rgba(249, 115, 22, 0.4)'
            }}
          />
          <input
            type="text"
            placeholder="Zoek oefeningen..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            style={{
              width: '100%',
              padding: isMobile ? '0.875rem 0.875rem 0.875rem 2.75rem' : '0.875rem 0.875rem 0.875rem 2.75rem',
              background: 'rgba(255,255,255,0.03)',
              border: '1px solid rgba(249, 115, 22, 0.1)',
              borderRadius: '12px',
              color: '#fff',
              fontSize: '0.9rem',
              outline: 'none',
              transition: 'all 0.2s ease'
            }}
            onFocus={(e) => {
              e.currentTarget.style.borderColor = 'rgba(249, 115, 22, 0.3)'
              e.currentTarget.style.background = 'rgba(255,255,255,0.05)'
            }}
            onBlur={(e) => {
              e.currentTarget.style.borderColor = 'rgba(249, 115, 22, 0.1)'
              e.currentTarget.style.background = 'rgba(255,255,255,0.03)'
            }}
          />
        </div>
        
        {/* Category Filters */}
        <div style={{
          display: 'flex',
          gap: '0.5rem',
          marginBottom: '1rem',
          overflowX: 'auto',
          paddingBottom: '0.25rem'
        }}>
          {['all', 'compound', 'isolation'].map(category => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              style={{
                padding: isMobile ? '0.6rem 1.25rem' : '0.5rem 1rem',
                background: selectedCategory === category
                  ? 'linear-gradient(135deg, #f97316 0%, #ea580c 100%)'
                  : 'rgba(255,255,255,0.03)',
                border: `1px solid ${
                  selectedCategory === category 
                    ? '#f97316' 
                    : 'rgba(255,255,255,0.1)'
                }`,
                borderRadius: '10px',
                color: selectedCategory === category ? '#fff' : 'rgba(255,255,255,0.5)',
                fontSize: '0.85rem',
                fontWeight: '700',
                cursor: 'pointer',
                textTransform: 'capitalize',
                transition: 'all 0.2s ease',
                whiteSpace: 'nowrap',
                display: 'flex',
                alignItems: 'center',
                gap: '0.4rem'
              }}
            >
              {category === 'all' && <Filter size={14} />}
              {category === 'compound' && <TrendingUp size={14} />}
              {category === 'isolation' && <Activity size={14} />}
              {category === 'all' ? 'Alle' : category}
            </button>
          ))}
        </div>
        
        {/* Exercise List */}
        <div style={{
          flex: 1,
          overflowY: 'auto',
          paddingRight: '0.25rem'
        }}>
          {loading ? (
            <div style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              padding: '3rem',
              color: 'rgba(255,255,255,0.5)'
            }}>
              <div style={{
                width: '48px',
                height: '48px',
                border: '3px solid rgba(249, 115, 22, 0.2)',
                borderTopColor: '#f97316',
                borderRadius: '50%',
                animation: 'spin 1s linear infinite'
              }} />
              <p style={{ marginTop: '1rem' }}>Alternatieven laden...</p>
            </div>
          ) : filteredAlternatives.length === 0 ? (
            <div style={{
              textAlign: 'center',
              padding: '3rem',
              color: 'rgba(255,255,255,0.5)'
            }}>
              <Dumbbell size={48} color="rgba(249, 115, 22, 0.2)" style={{ marginBottom: '1rem' }} />
              <p>Geen oefeningen gevonden</p>
              <p style={{ fontSize: '0.85rem', marginTop: '0.5rem', color: 'rgba(255,255,255,0.3)' }}>
                Probeer je zoekopdracht aan te passen
              </p>
            </div>
          ) : (
            <div style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '0.75rem'
            }}>
              {/* Compound Exercises */}
              {groupedAlternatives.compound.length > 0 && (
                <>
                  <div style={{
                    fontSize: '0.75rem',
                    color: 'rgba(255,255,255,0.4)',
                    fontWeight: '700',
                    textTransform: 'uppercase',
                    letterSpacing: '0.1em',
                    marginTop: '0.5rem',
                    marginBottom: '0.25rem',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.5rem'
                  }}>
                    <TrendingUp size={14} color="rgba(249, 115, 22, 0.5)" />
                    Compound Bewegingen
                  </div>
                  {groupedAlternatives.compound.map((alt) => (
                    <ExerciseOption
                      key={alt.id}
                      exercise={alt}
                      onSelect={() => {
                        onSelect(exercise, alt)
                        onClose()
                      }}
                      isCompound={true}
                      isMobile={isMobile}
                    />
                  ))}
                </>
              )}
              
              {/* Isolation Exercises */}
              {groupedAlternatives.isolation.length > 0 && (
                <>
                  <div style={{
                    fontSize: '0.75rem',
                    color: 'rgba(255,255,255,0.4)',
                    fontWeight: '700',
                    textTransform: 'uppercase',
                    letterSpacing: '0.1em',
                    marginTop: '0.75rem',
                    marginBottom: '0.25rem',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.5rem'
                  }}>
                    <Activity size={14} color="rgba(249, 115, 22, 0.5)" />
                    Isolatie Bewegingen
                  </div>
                  {groupedAlternatives.isolation.map((alt) => (
                    <ExerciseOption
                      key={alt.id}
                      exercise={alt}
                      onSelect={() => {
                        onSelect(exercise, alt)
                        onClose()
                      }}
                      isCompound={false}
                      isMobile={isMobile}
                    />
                  ))}
                </>
              )}
            </div>
          )}
        </div>
      </div>
      
      {/* Animations */}
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        
        @keyframes slideUp {
          from { transform: translateY(100%); }
          to { transform: translateY(0); }
        }
        
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  )
}

// Exercise Option Component - Orange styled
function ExerciseOption({ exercise, onSelect, isCompound, isMobile }) {
  return (
    <button 
      onClick={onSelect}
      style={{
        padding: isMobile ? '1rem' : '1.125rem',
        background: 'linear-gradient(135deg, rgba(23, 23, 23, 0.9) 0%, rgba(10, 10, 10, 0.9) 100%)',
        border: '1px solid rgba(249, 115, 22, 0.08)',
        borderRadius: '12px',
        color: '#fff',
        fontSize: '0.95rem',
        fontWeight: '600',
        cursor: 'pointer',
        textAlign: 'left',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        transition: 'all 0.2s ease',
        position: 'relative',
        overflow: 'hidden'
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.background = 'linear-gradient(135deg, rgba(249, 115, 22, 0.1) 0%, rgba(234, 88, 12, 0.05) 100%)'
        e.currentTarget.style.borderColor = 'rgba(249, 115, 22, 0.2)'
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.background = 'linear-gradient(135deg, rgba(23, 23, 23, 0.9) 0%, rgba(10, 10, 10, 0.9) 100%)'
        e.currentTarget.style.borderColor = 'rgba(249, 115, 22, 0.08)'
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
        <div style={{
          width: '8px',
          height: '8px',
          borderRadius: '50%',
          background: isCompound 
            ? 'linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)'
            : 'linear-gradient(135deg, #f97316 0%, #ea580c 100%)',
          flexShrink: 0,
          boxShadow: isCompound 
            ? '0 0 10px rgba(59, 130, 246, 0.4)'
            : '0 0 10px rgba(249, 115, 22, 0.4)'
        }} />
        <span>{exercise.name || exercise}</span>
      </div>
      <ChevronRight size={16} color="rgba(249, 115, 22, 0.5)" />
    </button>
  )
}
