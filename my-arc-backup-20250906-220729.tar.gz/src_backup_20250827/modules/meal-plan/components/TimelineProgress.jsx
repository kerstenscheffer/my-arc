// src/modules/meal-plan/components/TimelineProgress.jsx
import React from 'react'
import { 
  Flame, Dumbbell, Zap, Droplets, CheckCircle2,
  RefreshCw, Utensils, Coffee, Sun, Moon, Apple,
  Clock
} from 'lucide-react'

export default function TimelineProgress({ 
  meals, 
  checkedMeals, 
  onToggleMeal,
  currentProgress,
  targets,
  nextMeal,
  waterIntake,
  onAddWater,
  onSwapMeal
}) {
  const isMobile = window.innerWidth <= 768
  const currentHour = new Date().getHours() + new Date().getMinutes() / 60
  
  const getMealIcon = (slot) => {
    if (!slot) return Utensils
    const lowerSlot = slot.toLowerCase()
    if (lowerSlot.includes('ontbijt') || lowerSlot.includes('breakfast')) return Coffee
    if (lowerSlot.includes('lunch')) return Sun
    if (lowerSlot.includes('diner') || lowerSlot.includes('dinner')) return Moon
    if (lowerSlot.includes('snack')) return Apple
    return Utensils
  }
  
  const getTimeUntilMeal = (meal) => {
    if (!meal || !meal.plannedTime) return 'Binnenkort'
    const now = new Date().getHours() + new Date().getMinutes() / 60
    const diff = meal.plannedTime - now
    
    if (Math.abs(diff) < 0.25) return 'Nu'
    if (diff > 0) {
      const hours = Math.floor(diff)
      const minutes = Math.round((diff - hours) * 60)
      return `over ${hours > 0 ? `${hours}u ` : ''}${minutes}m`
    }
    return 'Nu'
  }
  
  return (
    <div style={{
      padding: isMobile ? '1rem' : '1.5rem',
      paddingBottom: '0.5rem'
    }}>
      {/* Next Meal Card - Uit originele code */}
      {nextMeal && !nextMeal.isPast && (
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '0.75rem',
          padding: '0.75rem',
          background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.1) 0%, rgba(16, 185, 129, 0.05) 100%)',
          borderRadius: '12px',
          marginBottom: '1rem',
          border: '1px solid rgba(16, 185, 129, 0.2)'
        }}>
          <div style={{
            width: '40px',
            height: '40px',
            borderRadius: '8px',
            background: nextMeal.image_url 
              ? `url(${nextMeal.image_url}) center/cover`
              : 'rgba(16, 185, 129, 0.1)',
            flexShrink: 0
          }}>
            {!nextMeal.image_url && (
              <div style={{
                width: '100%',
                height: '100%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                <Utensils size={18} style={{ color: 'rgba(16, 185, 129, 0.5)' }} />
              </div>
            )}
          </div>
          
          <div style={{ flex: 1 }}>
            <div style={{
              color: 'rgba(16, 185, 129, 0.7)',
              fontSize: '0.75rem',
              fontWeight: '600',
              textTransform: 'uppercase',
              marginBottom: '2px'
            }}>
              Volgende: {getTimeUntilMeal(nextMeal)}
            </div>
            <div style={{
              color: '#fff',
              fontSize: '0.9rem',
              fontWeight: '600'
            }}>
              {nextMeal.name}
            </div>
          </div>
          
          <div style={{ display: 'flex', gap: '0.5rem' }}>
            <button
              onClick={() => onSwapMeal && onSwapMeal(nextMeal)}
              style={{
                background: 'linear-gradient(135deg, rgba(59, 130, 246, 0.15) 0%, rgba(59, 130, 246, 0.08) 100%)',
                border: '1px solid rgba(59, 130, 246, 0.3)',
                borderRadius: '8px',
                padding: '0.5rem',
                color: 'rgba(59, 130, 246, 0.9)',
                fontWeight: '600',
                fontSize: '0.8rem',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '0.3rem'
              }}
            >
              <RefreshCw size={14} />
              Swap
            </button>
            
            <button
              onClick={() => {
                if (onToggleMeal && nextMeal.index !== undefined) {
                  onToggleMeal(nextMeal.index)
                }
              }}
              style={{
                background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.9) 0%, rgba(5, 150, 105, 0.9) 100%)',
                border: 'none',
                borderRadius: '8px',
                padding: '0.5rem 0.75rem',
                color: '#fff',
                fontWeight: '600',
                fontSize: '0.8rem',
                cursor: 'pointer',
                boxShadow: '0 2px 8px rgba(16, 185, 129, 0.3)'
              }}
            >
              <CheckCircle2 size={14} style={{ display: 'inline', marginRight: '0.3rem' }} />
              Klaar
            </button>
          </div>
        </div>
      )}
      
      {/* Macro Cards Grid - Met zichtbare doelen */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(5, 1fr)',
        gap: isMobile ? '0.4rem' : '0.6rem',
        marginBottom: '1.25rem'
      }}>
        {/* Enhanced Macro Cards */}
        {[
          { key: 'kcal', icon: Flame, color: '#f59e0b', label: 'Kcal', hideTarget: true },
          { key: 'protein', icon: Dumbbell, color: '#3b82f6', label: 'Eiwit' },
          { key: 'carbs', icon: Zap, color: '#ef4444', label: 'Koolh' },
          { key: 'fat', icon: Droplets, color: '#8b5cf6', label: 'Vet' }
        ].map((macro) => {
          const Icon = macro.icon
          const value = currentProgress[macro.key] || 0
          const target = targets[macro.key] || 1
          const percentage = Math.min((value / target) * 100, 100)
          
          return (
            <div
              key={macro.key}
              style={{
                background: 'rgba(23, 23, 23, 0.6)',
                borderRadius: '12px',
                padding: isMobile ? '0.6rem' : '0.875rem',
                border: `1px solid ${macro.color}20`,
                position: 'relative',
                overflow: 'hidden',
                minHeight: isMobile ? '75px' : '85px',
                backdropFilter: 'blur(10px)'
              }}
            >
              <div style={{
                position: 'absolute',
                bottom: 0,
                left: 0,
                right: 0,
                height: `${percentage}%`,
                background: `linear-gradient(180deg, ${macro.color}25 0%, ${macro.color}10 100%)`,
                transition: 'height 0.8s cubic-bezier(0.4, 0, 0.2, 1)'
              }} />
              
              <div style={{
                position: 'relative',
                textAlign: 'center'
              }}>
                <Icon size={isMobile ? 13 : 15} style={{ 
                  color: macro.color, 
                  marginBottom: '2px'
                }} />
                <div style={{ 
                  color: '#fff', 
                  fontWeight: 'bold',
                  fontSize: isMobile ? '0.9rem' : '1rem',
                  lineHeight: 1
                }}>
                  {value}
                </div>
                {!macro.hideTarget && (
                  <div style={{
                    color: 'rgba(255,255,255,0.4)',
                    fontSize: '0.6rem',
                    marginTop: '2px'
                  }}>
                    /{target}
                  </div>
                )}
                <div style={{ 
                  color: 'rgba(255,255,255,0.4)', 
                  fontSize: '0.55rem',
                  marginTop: '2px'
                }}>
                  {macro.label}
                </div>
              </div>
            </div>
          )
        })}
        
        {/* Water Card */}
        <div
          style={{
            background: 'linear-gradient(135deg, rgba(59, 130, 246, 0.15) 0%, rgba(59, 130, 246, 0.05) 100%)',
            borderRadius: '12px',
            padding: isMobile ? '0.6rem' : '0.875rem',
            border: '1px solid rgba(59, 130, 246, 0.3)',
            position: 'relative',
            overflow: 'hidden',
            minHeight: isMobile ? '75px' : '85px',
            cursor: 'pointer'
          }}
          onClick={() => onAddWater(Math.min(waterIntake + 0.25, 3.0))}
        >
          <div style={{
            position: 'absolute',
            bottom: 0,
            left: 0,
            right: 0,
            height: `${Math.min((waterIntake / 2.0) * 100, 100)}%`,
            background: 'linear-gradient(180deg, rgba(59, 130, 246, 0.3) 0%, rgba(59, 130, 246, 0.15) 100%)',
            transition: 'height 0.8s cubic-bezier(0.4, 0, 0.2, 1)'
          }} />
          
          <div style={{
            position: 'relative',
            textAlign: 'center'
          }}>
            <Droplets size={isMobile ? 13 : 15} style={{ 
              color: 'rgba(59, 130, 246, 0.9)', 
              marginBottom: '2px'
            }} />
            <div style={{ 
              color: '#fff', 
              fontWeight: 'bold',
              fontSize: isMobile ? '0.9rem' : '1rem'
            }}>
              {waterIntake.toFixed(1)}L
            </div>
            <div style={{
              color: 'rgba(255,255,255,0.4)',
              fontSize: '0.6rem',
              marginTop: '2px'
            }}>
              /2.0L
            </div>
            <div style={{ 
              color: 'rgba(255,255,255,0.4)', 
              fontSize: '0.55rem',
              marginTop: '2px'
            }}>
              Water
            </div>
          </div>
          
          <div style={{
            position: 'absolute',
            top: '2px',
            right: '2px',
            background: 'rgba(59, 130, 246, 0.2)',
            borderRadius: '4px',
            padding: '2px 4px',
            fontSize: '0.5rem',
            color: 'rgba(59, 130, 246, 0.7)'
          }}>
            +
          </div>
        </div>
      </div>
      
      {/* Meal Timeline - Zonder groene achtergrond */}
      <div style={{
        height: '60px',
        background: 'rgba(255, 255, 255, 0.02)',
        borderRadius: '30px',
        position: 'relative',
        overflow: 'hidden',
        border: '1px solid rgba(255, 255, 255, 0.05)'
      }}>
        {/* Time markers */}
        <div style={{
          position: 'absolute',
          width: '100%',
          height: '100%',
          display: 'flex',
          justifyContent: 'space-between',
          padding: '0 20px',
          alignItems: 'center',
          color: 'rgba(255,255,255,0.3)',
          fontSize: '0.65rem',
          pointerEvents: 'none'
        }}>
          <span>6:00</span>
          <span>12:00</span>
          <span>18:00</span>
          <span>24:00</span>
        </div>

        {/* Current time indicator */}
        {currentHour >= 6 && currentHour <= 24 && (
          <div style={{
            position: 'absolute',
            left: `${((currentHour - 6) / 18) * 100}%`,
            top: '0',
            bottom: '0',
            width: '2px',
            background: 'linear-gradient(180deg, transparent, rgba(16, 185, 129, 0.8), transparent)',
            boxShadow: '0 0 10px rgba(16, 185, 129, 0.5)',
            animation: 'pulse 2s ease infinite',
            zIndex: 1
          }} />
        )}

        {/* Meal dots on timeline */}
        {meals && meals.length > 0 && meals.map((meal, idx) => {
          const Icon = getMealIcon(meal.timeSlot)
          const isEaten = checkedMeals[idx]
          const plannedTime = meal.plannedTime || (8 + (idx * 3))
          const position = Math.max(0, Math.min(100, ((plannedTime - 6) / 18) * 100))
          
          return (
            <div
              key={`timeline-meal-${meal.id || idx}`}
              onClick={() => onToggleMeal(idx)}
              style={{
                position: 'absolute',
                left: `${Math.min(Math.max(position, 0), 100)}%`,
                top: '50%',
                transform: 'translate(-50%, -50%)',
                width: '44px',
                height: '44px',
                borderRadius: '50%',
                background: isEaten 
                  ? 'linear-gradient(135deg, rgba(16, 185, 129, 0.9) 0%, rgba(5, 150, 105, 0.9) 100%)'
                  : 'rgba(0, 0, 0, 0.6)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
                transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                border: isEaten 
                  ? '2px solid rgba(16, 185, 129, 0.8)' 
                  : '2px solid rgba(16, 185, 129, 0.2)',
                zIndex: 2,
                boxShadow: isEaten 
                  ? '0 0 20px rgba(16, 185, 129, 0.4)'
                  : '0 2px 8px rgba(0, 0, 0, 0.3)'
              }}
              title={`${meal.timeSlot}: ${meal.name}`}
            >
              <Icon size={20} style={{ 
                color: isEaten ? '#fff' : 'rgba(16, 185, 129, 0.6)'
              }} />
            </div>
          )
        })}
      </div>
      
      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 0.5; }
          50% { opacity: 1; }
        }
      `}</style>
    </div>
  )
}
