// src/modules/meal-plan/components/MealGoalCard.jsx
import React, { useState, useEffect } from 'react'
import { TrendingUp, Target, Info } from 'lucide-react'

export default function MealGoalCard({ progress, targets, plan, waterIntake, onAddWater }) {
  const [animatedProgress, setAnimatedProgress] = useState(0)
  const progressPercent = targets.kcal > 0 
    ? Math.min(100, Math.round((progress.kcal / targets.kcal) * 100))
    : 0
  
  useEffect(() => {
    setTimeout(() => setAnimatedProgress(progressPercent), 100)
  }, [progressPercent])
  
  const isMobile = window.innerWidth <= 768
  
  return (
    <div style={{
      padding: isMobile ? '0.75rem' : '1rem',
      marginBottom: '0.75rem'
    }}>
      {/* Main Goal Card - Enhanced Neon */}
      <div style={{
        background: 'linear-gradient(135deg, #0a0a0a 0%, #0f0f0f 100%)',
        borderRadius: '14px',
        padding: isMobile ? '1rem' : '1.25rem',
        position: 'relative',
        overflow: 'hidden',
        border: '1px solid rgba(16, 185, 129, 0.3)',
        boxShadow: '0 0 40px rgba(16, 185, 129, 0.2), 0 4px 20px rgba(0, 0, 0, 0.5), inset 0 0 20px rgba(16, 185, 129, 0.05)'
      }}>
        {/* Enhanced accent line */}
        <div style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          height: '2px',
          background: 'linear-gradient(90deg, transparent, #10b981, #34d399, #10b981, transparent)',
          boxShadow: '0 0 15px rgba(16, 185, 129, 0.8)',
          animation: 'shimmerGreen 3s ease-in-out infinite'
        }} />
        
        {/* Corner glow effects */}
        <div style={{
          position: 'absolute',
          top: '-50px',
          left: '-50px',
          width: '100px',
          height: '100px',
          background: 'radial-gradient(circle, rgba(16, 185, 129, 0.2) 0%, transparent 70%)',
          animation: 'pulseGlow 4s ease-in-out infinite'
        }} />
        <div style={{
          position: 'absolute',
          bottom: '-50px',
          right: '-50px',
          width: '100px',
          height: '100px',
          background: 'radial-gradient(circle, rgba(16, 185, 129, 0.15) 0%, transparent 70%)',
          animation: 'pulseGlow 4s ease-in-out infinite 2s'
        }} />
        
        <div style={{ position: 'relative', zIndex: 1 }}>
          {/* Main Calorie Display */}
          <div style={{
            display: 'flex',
            alignItems: 'flex-end',
            justifyContent: 'space-between',
            marginBottom: '1rem'
          }}>
            <div>
              {/* Current/Target Display */}
              <div style={{
                display: 'flex',
                alignItems: 'baseline',
                gap: '0.5rem',
                marginBottom: '0.25rem'
              }}>
                <span style={{
                  fontSize: isMobile ? '1.75rem' : '2rem',
                  fontWeight: 'bold',
                  color: '#10b981',
                  lineHeight: 1,
                  textShadow: '0 0 10px rgba(16, 185, 129, 0.4)'
                }}>
                  {progress.kcal}
                </span>
                <span style={{
                  fontSize: '1rem',
                  color: 'rgba(16, 185, 129, 0.5)',
                  textShadow: '0 0 10px rgba(16, 185, 129, 0.3)'
                }}>
                  /
                </span>
                <span style={{
                  fontSize: '1rem',
                  color: 'rgba(16, 185, 129, 0.6)'
                }}>
                  {targets.kcal} kcal
                </span>
              </div>
              
              {/* Progress Text */}
              <p style={{
                fontSize: '0.75rem',
                color: '#10b981',
                margin: 0,
                opacity: 0.9,
                textShadow: '0 0 8px rgba(16, 185, 129, 0.5)'
              }}>
                {targets.kcal - progress.kcal > 0 
                  ? `Nog ${targets.kcal - progress.kcal} kcal te gaan`
                  : `Doel bereikt!`}
              </p>
            </div>
            
            {/* Circular Progress - Enhanced */}
            <div style={{ position: 'relative', width: '60px', height: '60px' }}>
              <svg width="60" height="60" style={{ transform: 'rotate(-90deg)', filter: 'drop-shadow(0 0 10px rgba(16, 185, 129, 0.4))' }}>
                <circle
                  cx="30"
                  cy="30"
                  r="26"
                  stroke="rgba(255, 255, 255, 0.05)"
                  strokeWidth="4"
                  fill="none"
                />
                <circle
                  cx="30"
                  cy="30"
                  r="26"
                  stroke="#10b981"
                  strokeWidth="4"
                  fill="none"
                  strokeDasharray={`${(animatedProgress / 100) * 163} 163`}
                  strokeLinecap="round"
                  style={{
                    transition: 'stroke-dasharray 1s ease',
                    filter: 'drop-shadow(0 0 6px rgba(16, 185, 129, 0.8))'
                  }}
                />
              </svg>
              <div style={{
                position: 'absolute',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                fontSize: '0.875rem',
                fontWeight: 'bold',
                color: '#10b981',
                textShadow: '0 0 10px rgba(16, 185, 129, 0.6)'
              }}>
                {animatedProgress}%
              </div>
            </div>
          </div>
          
          {/* Enhanced Progress Bar */}
          <div style={{
            background: 'rgba(0, 0, 0, 0.5)',
            borderRadius: '6px',
            height: '6px',
            overflow: 'hidden',
            marginBottom: '1rem',
            border: '1px solid rgba(16, 185, 129, 0.2)',
            boxShadow: 'inset 0 2px 4px rgba(0, 0, 0, 0.8)'
          }}>
            <div style={{
              background: 'linear-gradient(90deg, #059669, #10b981, #34d399, #10b981)',
              backgroundSize: '200% 100%',
              height: '100%',
              width: `${animatedProgress}%`,
              borderRadius: '6px',
              transition: 'width 1s cubic-bezier(0.4, 0, 0.2, 1)',
              position: 'relative',
              boxShadow: '0 0 15px rgba(16, 185, 129, 0.8)',
              animation: 'shimmerGreen 2s ease-in-out infinite'
            }} />
          </div>
          
          {/* Macro Cards with Enhanced Neon */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(4, 1fr)',
            gap: isMobile ? '0.5rem' : '0.625rem'
          }}>
            <MacroCard
              label="Eiwit"
              value={progress.protein}
              target={targets.protein}
              unit="g"
              color="#fbbf24"
              neonIntensity="high"
            />
            <MacroCard
              label="Koolh"
              value={progress.carbs}
              target={targets.carbs}
              unit="g"
              color="#60a5fa"
              neonIntensity="high"
            />
            <MacroCard
              label="Vet"
              value={progress.fat}
              target={targets.fat}
              unit="g"
              color="#f87171"
              neonIntensity="high"
            />
            {/* Water Card - Subtielere styling */}
            <div
              onClick={() => onAddWater && onAddWater(Math.min((waterIntake || 0) + 0.25, 3.0))}
              style={{
                background: 'rgba(59, 130, 246, 0.12)',
                borderRadius: '10px',
                padding: isMobile ? '0.625rem' : '0.75rem',
                border: '1px solid rgba(59, 130, 246, 0.25)',
                position: 'relative',
                overflow: 'hidden',
                cursor: 'pointer',
                // Realistische schaduw - links en onder (subtieler)
                boxShadow: '-2px 2px 4px rgba(0, 0, 0, 0.2), inset 0 0 8px rgba(59, 130, 246, 0.05)',
                transition: 'all 0.3s ease'
              }}
            >
              <div style={{
                position: 'absolute',
                bottom: 0,
                left: 0,
                right: 0,
                height: `${Math.min(((waterIntake || 0) / 2.0) * 100, 100)}%`,
                background: 'linear-gradient(180deg, rgba(59, 130, 246, 0.2) 0%, rgba(59, 130, 246, 0.08) 100%)',
                transition: 'height 0.8s ease'
              }} />
              
              <div style={{ position: 'relative', zIndex: 1 }}>
                <p style={{
                  color: 'rgba(255,255,255,0.5)',
                  fontSize: '0.65rem',
                  margin: '0 0 4px 0',
                  textTransform: 'uppercase',
                  letterSpacing: '0.05em'
                }}>
                  Water
                </p>
                
                <div style={{
                  display: 'flex',
                  alignItems: 'baseline',
                  gap: '2px',
                  marginBottom: '4px'
                }}>
                  <span style={{
                    color: '#60a5fa',
                    fontSize: isMobile ? '1.1rem' : '1.25rem',
                    fontWeight: 'bold',
                    lineHeight: 1,
                    textShadow: '0 0 8px rgba(96, 165, 250, 0.4)',
                    filter: 'brightness(1.1)'
                  }}>
                    {(waterIntake || 0).toFixed(1)}L
                  </span>
                  <span style={{
                    color: 'rgba(96, 165, 250, 0.6)',
                    fontSize: '0.65rem'
                  }}>
                    /2.0
                  </span>
                </div>
                
                <div style={{
                  background: 'rgba(0,0,0,0.4)',
                  height: '3px',
                  borderRadius: '2px',
                  overflow: 'hidden',
                  boxShadow: 'inset 0 1px 2px rgba(0,0,0,0.6)'
                }}>
                  <div style={{
                    background: '#60a5fa',
                    height: '100%',
                    width: `${Math.min(((waterIntake || 0) / 2.0) * 100, 100)}%`,
                    borderRadius: '2px',
                    transition: 'width 0.8s ease',
                    boxShadow: '0 0 6px rgba(96, 165, 250, 0.7)'
                  }} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Coach Note - Minimal */}
      {plan?.coach_note && (
        <div style={{
          background: 'rgba(4, 120, 87, 0.08)',
          borderRadius: '10px',
          padding: '0.75rem',
          marginTop: '0.75rem',
          display: 'flex',
          gap: '0.5rem',
          alignItems: 'flex-start',
          border: '1px solid rgba(4, 120, 87, 0.2)',
          boxShadow: '0 0 15px rgba(4, 120, 87, 0.1)'
        }}>
          <Info size={14} style={{ 
            color: '#059669',
            flexShrink: 0,
            marginTop: '2px',
            filter: 'drop-shadow(0 0 4px rgba(5, 150, 105, 0.6))'
          }} />
          <p style={{
            color: 'rgba(255,255,255,0.6)',
            fontSize: '0.8rem',
            lineHeight: 1.5,
            margin: 0
          }}>
            {plan.coach_note}
          </p>
        </div>
      )}
      
      <style>{`
        @keyframes shimmerGreen {
          0% { background-position: -100% 50%; opacity: 0.8; }
          50% { background-position: 100% 50%; opacity: 1; }
          100% { background-position: 200% 50%; opacity: 0.8; }
        }
        
        @keyframes pulseGlow {
          0%, 100% { opacity: 0.3; transform: scale(1); }
          50% { opacity: 0.6; transform: scale(1.2); }
        }
      `}</style>
    </div>
  )
}

function MacroCard({ label, value, target, unit, color, neonIntensity }) {
  const percent = target > 0 ? Math.min(100, Math.round((value / target) * 100)) : 0
  const [animatedPercent, setAnimatedPercent] = useState(0)
  const isMobile = window.innerWidth <= 768
  
  useEffect(() => {
    setTimeout(() => setAnimatedPercent(percent), 200)
  }, [percent])
  
  // Extract RGB values for dynamic shadows
  const getRGB = (hex) => {
    if (hex === '#fbbf24') return '251, 191, 36'
    if (hex === '#60a5fa') return '96, 165, 250'
    if (hex === '#f87171') return '248, 113, 113'
    return '255, 255, 255'
  }
  
  const rgb = getRGB(color)
  
  return (
    <div style={{
      background: `rgba(${rgb}, 0.12)`,
      borderRadius: '10px',
      padding: isMobile ? '0.625rem' : '0.75rem',
      border: `1px solid rgba(${rgb}, 0.25)`,
      position: 'relative',
      overflow: 'hidden',
      // Realistische schaduw - links en onder (subtieler)
      boxShadow: `-2px 2px 4px rgba(0, 0, 0, 0.2), inset 0 0 8px rgba(${rgb}, 0.05)`,
      transition: 'all 0.3s ease'
    }}>
      {/* Top glow line */}
      <div style={{
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        height: '1px',
        background: color,
        boxShadow: `0 0 8px rgba(${rgb}, 0.6)`,
        opacity: 0.7
      }} />
      
      {/* Progress fill */}
      <div style={{
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        height: `${animatedPercent}%`,
        background: `linear-gradient(180deg, rgba(${rgb}, 0.2) 0%, rgba(${rgb}, 0.08) 100%)`,
        transition: 'height 0.8s ease'
      }} />
      
      <div style={{ position: 'relative', zIndex: 1 }}>
        {/* Label */}
        <p style={{
          color: 'rgba(255,255,255,0.5)',
          fontSize: '0.65rem',
          margin: '0 0 4px 0',
          textTransform: 'uppercase',
          letterSpacing: '0.05em'
        }}>
          {label}
        </p>
        
        {/* Current Value - Subtielere glow */}
        <div style={{
          display: 'flex',
          alignItems: 'baseline',
          gap: '2px',
          marginBottom: '4px'
        }}>
          <span style={{
            color: color,
            fontSize: isMobile ? '1.1rem' : '1.25rem',
            fontWeight: 'bold',
            lineHeight: 1,
            textShadow: `0 0 8px rgba(${rgb}, 0.4)`,
            filter: `brightness(1.1)`
          }}>
            {value}
          </span>
          <span style={{
            color: `rgba(${rgb}, 0.6)`,
            fontSize: '0.65rem'
          }}>
            /{target}
          </span>
        </div>
        
        {/* Visual Progress Bar */}
        <div style={{
          background: 'rgba(0,0,0,0.4)',
          height: '3px',
          borderRadius: '2px',
          overflow: 'hidden',
          boxShadow: 'inset 0 1px 2px rgba(0,0,0,0.6)'
        }}>
          <div style={{
            background: color,
            height: '100%',
            width: `${animatedPercent}%`,
            borderRadius: '2px',
            transition: 'width 0.8s ease',
            boxShadow: `0 0 6px rgba(${rgb}, 0.7)`
          }} />
        </div>
      </div>
    </div>
  )
}
