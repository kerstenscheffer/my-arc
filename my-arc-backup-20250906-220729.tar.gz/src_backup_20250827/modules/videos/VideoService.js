// src/modules/videos/VideoService.js
import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

class VideoService {
  constructor() {
    this.supabase = createClient(supabaseUrl, supabaseAnonKey)
    this.cache = new Map()
    this.cacheTimeout = 5 * 60 * 1000 // 5 minutes
  }

  // ============================================
  // CLIENT VIDEO METHODS
  // ============================================
  
  async getVideosForPage(clientId, pageContext = 'home', contextData = {}, db) {
    try {
      console.log(`🎬 [VideoService] Getting videos for client: ${clientId}, context: ${pageContext}`)
      
      // Check cache
      const cacheKey = `${clientId}-${pageContext}`
      const cached = this.cache.get(cacheKey)
      if (cached && Date.now() - cached.timestamp < this.cacheTimeout) {
        console.log(`📦 [VideoService] Using cached data for ${pageContext}`)
        return cached.data
      }
      
      // Get assignments first
      const { data: assignments, error: assignError } = await this.supabase
        .from('video_assignments')
        .select('*')
        .eq('client_id', clientId)
        .eq('page_context', pageContext)
        .order('scheduled_for', { ascending: false })
      
      if (assignError) throw assignError
      
      // Then get video details for each assignment
      const videosWithData = []
      for (const assignment of (assignments || [])) {
        const { data: video, error: videoError } = await this.supabase
          .from('coach_videos')
          .select('*')
          .eq('id', assignment.video_id)
          .single()
        
        if (!videoError && video) {
          videosWithData.push({
            ...assignment,
            video: video
          })
        }
      }
      
      console.log(`✅ [VideoService] Found ${videosWithData.length} videos for ${pageContext}`)
      
      // Cache the results
      this.cache.set(cacheKey, {
        data: videosWithData,
        timestamp: Date.now()
      })
      
      return videosWithData
    } catch (error) {
      console.error('[VideoService] Error getting videos:', error)
      return []
    }
  }

  async getTodaysVideo(clientId, pageContext = 'home', db) {
    try {
      const today = new Date().toISOString().split('T')[0]
      
      const { data: assignment, error: assignError } = await this.supabase
        .from('video_assignments')
        .select('*')
        .eq('client_id', clientId)
        .eq('page_context', pageContext)
        .gte('scheduled_for', today)
        .lt('scheduled_for', `${today}T23:59:59`)
        .single()
      
      if (assignError && assignError.code !== 'PGRST116') {
        throw assignError
      }
      
      if (!assignment) return null
      
      // Get video details
      const { data: video, error: videoError } = await this.supabase
        .from('coach_videos')
        .select('*')
        .eq('id', assignment.video_id)
        .single()
      
      if (videoError || !video) return null
      
      return {
        ...assignment,
        video: video
      }
    } catch (error) {
      console.error('[VideoService] Error getting today\'s video:', error)
      return null
    }
  }

  async markVideoWatched(assignmentId, watchData = {}, db) {
    try {
      if (!assignmentId) {
        console.warn('No assignment ID provided')
        return null
      }
      
      const { error } = await this.supabase
        .from('video_assignments')
        .update({
          status: 'viewed',
          last_watched_at: new Date().toISOString(),
          watch_duration: watchData.duration || 0,
          updated_at: new Date().toISOString()
        })
        .eq('id', assignmentId)
      
      if (error) throw error
      
      // Clear cache for this client
      for (const [key] of this.cache) {
        if (key.includes(assignmentId.split('-')[0])) {
          this.cache.delete(key)
        }
      }
      
      return { success: true }
    } catch (error) {
      console.error('Error marking video watched:', error)
      return null
    }
  }

  async rateVideo(assignmentId, rating, db) {
    try {
      if (!assignmentId || !rating) return null
      
      const { error } = await this.supabase
        .from('video_assignments')
        .update({
          rating: rating,
          rated_at: new Date().toISOString()
        })
        .eq('id', assignmentId)
      
      if (error) throw error
      return { success: true }
    } catch (error) {
      console.error('Error rating video:', error)
      return null
    }
  }

  // ============================================
  // COACH VIDEO METHODS
  // ============================================

  async getCoachVideos(coachId) {
    try {
      const { data, error } = await this.supabase
        .from('coach_videos')
        .select('*')
        .eq('coach_id', coachId)
        .eq('is_active', true)
        .order('created_at', { ascending: false })

      if (error) throw error
      
      // Get view counts separately
      const videosWithStats = []
      for (const video of (data || [])) {
        const { count } = await this.supabase
          .from('video_assignments')
          .select('*', { count: 'exact', head: true })
          .eq('video_id', video.id)
        
        videosWithStats.push({
          ...video,
          view_count: count || 0,
          like_count: 0
        })
      }
      
      console.log(`✅ Loaded ${videosWithStats.length} coach videos`)
      return videosWithStats
    } catch (error) {
      console.error('Error loading coach videos:', error)
      return []
    }
  }

  async createVideo(videoData) {
    try {
      const { data, error } = await this.supabase
        .from('coach_videos')
        .insert({
          coach_id: videoData.coach_id,
          title: videoData.title,
          description: videoData.description,
          video_url: videoData.video_url,
          category: videoData.category,
          tags: videoData.tags || [],
          difficulty_level: videoData.difficulty_level || 'beginner',
          duration_seconds: videoData.duration_seconds,
          is_featured: false,
          is_active: true
        })
        .select()
        .single()

      if (error) throw error
      
      console.log('✅ Video created:', data)
      return { success: true, data }
    } catch (error) {
      console.error('Error creating video:', error)
      return { success: false, error }
    }
  }

  async assignVideo(videoId, clientIds, assignmentData) {
    try {
      const assignments = clientIds.map(clientId => ({
        video_id: videoId,
        client_id: clientId,
        scheduled_for: assignmentData.scheduledFor || new Date().toISOString(),
        page_context: assignmentData.pageContext || 'home',
        context_data: assignmentData.contextData || {},
        status: 'pending',
        notes: assignmentData.notes || ''
      }))

      const { data, error } = await this.supabase
        .from('video_assignments')
        .insert(assignments)

      if (error) throw error
      
      console.log(`✅ Video assigned to ${clientIds.length} clients`)
      return { success: true, data }
    } catch (error) {
      console.error('Error assigning video:', error)
      return { success: false, error }
    }
  }

  async updateVideo(videoId, updates) {
    try {
      const { data, error } = await this.supabase
        .from('coach_videos')
        .update({
          ...updates,
          updated_at: new Date().toISOString()
        })
        .eq('id', videoId)
        .select()
        .single()

      if (error) throw error
      
      console.log('✅ Video updated')
      return { success: true, data }
    } catch (error) {
      console.error('Error updating video:', error)
      return { success: false, error }
    }
  }

  async deleteVideo(videoId) {
    try {
      const { error } = await this.supabase
        .from('coach_videos')
        .update({
          is_active: false,
          updated_at: new Date().toISOString()
        })
        .eq('id', videoId)

      if (error) throw error
      
      console.log('✅ Video deleted')
      return { success: true }
    } catch (error) {
      console.error('Error deleting video:', error)
      return { success: false, error }
    }
  }

  async getFeaturedVideos(limit = 5) {
    try {
      const { data, error } = await this.supabase
        .from('coach_videos')
        .select('*')
        .eq('is_featured', true)
        .eq('is_active', true)
        .limit(limit)

      if (error) throw error
      return data || []
    } catch (error) {
      console.error('Error loading featured videos:', error)
      return []
    }
  }

  async incrementVideoView(videoId) {
    try {
      // First get current count
      const { data: current, error: fetchError } = await this.supabase
        .from('coach_videos')
        .select('view_count')
        .eq('id', videoId)
        .single()
      
      if (fetchError) throw fetchError
      
      // Then update with incremented value
      const { error } = await this.supabase
        .from('coach_videos')
        .update({ 
          view_count: (current.view_count || 0) + 1,
          updated_at: new Date().toISOString()
        })
        .eq('id', videoId)

      if (error) throw error
      return { success: true }
    } catch (error) {
      console.error('Error incrementing view:', error)
      return { success: false }
    }
  }

  // ============================================
  // UTILITY METHODS
  // ============================================

  extractYouTubeId(url) {
    if (!url) return null
    const match = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&\n?#]+)/)
    return match ? match[1] : null
  }

  clearCache() {
    this.cache.clear()
    console.log('📦 Video cache cleared')
  }

  getCacheStatus() {
    return {
      size: this.cache.size,
      keys: Array.from(this.cache.keys())
    }
  }
}

// Create singleton instance
const videoService = new VideoService()

export default videoService
