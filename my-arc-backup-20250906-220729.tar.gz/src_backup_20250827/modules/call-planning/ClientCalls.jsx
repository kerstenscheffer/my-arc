import React, { useState, useEffect } from 'react';
import { 
  Bell, RefreshCw, Plus, Sparkles, Gift, HelpCircle
} from 'lucide-react';
import PageVideoWidget from '../videos/PageVideoWidget';
import CallPlanningService from './CallPlanningService';
import { callTypeConfig } from './constants/callTypes';
import ProgressBar from './components/ProgressBar';
import CallCard from './components/CallCard';
import NextCallHighlight from './components/NextCallHighlight';
import BookingModal from './components/BookingModal';
import RequestModal from './components/RequestModal';
import './styles/animations.css';

export default function ClientCalls({ db, clientInfo }) {
  const [plans, setPlans] = useState([]);
  const [calls, setCalls] = useState([]);
  const [requests, setRequests] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedCall, setSelectedCall] = useState(null);
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [calendlyLoaded, setCalendlyLoaded] = useState(false);
  const [modalKey, setModalKey] = useState(0);
  const [userStats, setUserStats] = useState({
    totalCalls: 0,
    completedCalls: 0,
    scheduledCalls: 0
  });

  const isMobile = window.innerWidth <= 768;

  // Calculate user stats
  const calculateUserStats = (callsData) => {
    const completed = callsData.filter(c => c.status === 'completed').length;
    const scheduled = callsData.filter(c => c.status === 'scheduled').length;
    
    setUserStats({
      totalCalls: callsData.length,
      completedCalls: completed,
      scheduledCalls: scheduled
    });
  };

  // Load call data
  const loadCallData = async () => {
    try {
      setLoading(true);
      
      const plansData = await CallPlanningService.getClientPlans(clientInfo.id);
      setPlans(plansData || []);
      
      if (plansData && plansData.length > 0) {
        const activePlan = plansData.find(p => p.status === 'active') || plansData[0];
        
        if (activePlan.client_calls) {
          let callsData = activePlan.client_calls;
          
          // Auto unlock first call and subsequent calls if previous is completed
          callsData = callsData.map((call, index) => {
            if (call.call_number === 1 && call.status === 'locked') {
              return { ...call, status: 'available' };
            }
            
            if (call.call_number > 1 && call.status === 'locked') {
              const previousCall = callsData.find(c => c.call_number === call.call_number - 1);
              if (previousCall && previousCall.status === 'completed') {
                return { ...call, status: 'available' };
              }
            }
            
            return call;
          });
          
          setCalls(callsData);
          calculateUserStats(callsData);
        }
      }
      
      // Load requests and notifications
      try {
        if (CallPlanningService.getClientRequests) {
          const requestsData = await CallPlanningService.getClientRequests(clientInfo.id);
          setRequests(requestsData || []);
        }
      } catch (e) {
        console.log('Requests not available');
      }
      
      try {
        if (CallPlanningService.getCallNotifications) {
          const notificationsData = await CallPlanningService.getCallNotifications(clientInfo.id);
          setNotifications(notificationsData?.filter(n => !n.read) || []);
        }
      } catch (e) {
        console.log('Notifications not available');
      }
      
    } catch (error) {
      console.error('Error loading call data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (clientInfo?.id) {
      loadCallData();
    }
  }, [clientInfo]);

  const handleBookCall = (call) => {
    console.log('Opening booking for call:', call);
    
    let callWithLink = { ...call };
    
    // Add fallback Calendly links if needed
    if (!callWithLink.calendly_link) {
      const fallbackLinks = {
        1: 'https://calendly.com/kerstenscheffer/kennismaking-doelstelling-call',
        2: 'https://calendly.com/kerstenscheffer/persoonlijk-plan-pitch',
        3: 'https://calendly.com/kerstenscheffer/reflectie-bijsturen',
        4: 'https://calendly.com/kerstenscheffer/halfway-progressie-call',
        5: 'https://calendly.com/kerstenscheffer/final-sprint-call',
        6: 'https://calendly.com/kerstenscheffer/final-call'
      };
      
      if (fallbackLinks[callWithLink.call_number]) {
        callWithLink.calendly_link = fallbackLinks[callWithLink.call_number];
      }
    }
    
    if (!callWithLink.calendly_link || !callWithLink.calendly_link.includes('calendly.com')) {
      alert('Er is geen geldige Calendly link voor deze call. Neem contact op met je coach.');
      return;
    }

    // Add tracking parameters
    const separator = callWithLink.calendly_link.includes('?') ? '&' : '?';
    const clientEmail = clientInfo?.email || '';
    const fullCalendlyUrl = `${callWithLink.calendly_link}${separator}utm_content=call_${call.id}&email=${encodeURIComponent(clientEmail)}`;
    
    callWithLink.calendly_link = fullCalendlyUrl;
    
    // Reset calendly loaded state to force re-init
    setCalendlyLoaded(false);
    
    // Set selected call and open modal
    setSelectedCall(callWithLink);
    setShowBookingModal(true);
    setModalKey(prev => prev + 1);
  };

  const calculateProgress = () => {
    const completed = calls.filter(c => c.status === 'completed').length;
    return calls.length > 0 ? (completed / calls.length) * 100 : 0;
  };

  if (loading) {
    return (
      <div style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '400px',
        background: 'linear-gradient(135deg, #1a1a1a 0%, #0a0f0d 100%)',
        borderRadius: '20px'
      }}>
        <div style={{ textAlign: 'center' }}>
          <div className="spinner" />
          <div style={{ color: 'rgba(255, 255, 255, 0.6)', marginTop: '1rem' }}>Calls laden...</div>
        </div>
      </div>
    );
  }

  const activePlan = plans.find(p => p.status === 'active');
  const nextCall = calls.find(c => c.status === 'available' || c.status === 'scheduled');
  const progress = calculateProgress();

  return (
    <div style={{ 
      padding: '1rem', 
      background: 'linear-gradient(180deg, #0a0f0d 0%, #1a1a1a 100%)', 
      minHeight: '100vh' 
    }}>
      {/* Compact Header */}
      <div style={{
        background: 'linear-gradient(135deg, #3b82f6 0%, #2563eb 50%, #1d4ed8 100%)',
        borderRadius: isMobile ? '16px' : '20px',
        padding: isMobile ? '1.25rem 1rem' : '1.5rem',
        marginBottom: '1.5rem',
        position: 'relative',
        overflow: 'hidden',
        boxShadow: '0 10px 30px rgba(59, 130, 246, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.2)'
      }}>
        {/* Animated Background Pattern */}
        <div className="float-animation" style={{
          position: 'absolute',
          top: '-50%',
          right: '-10%',
          width: isMobile ? '200px' : '300px',
          height: isMobile ? '200px' : '300px',
          background: 'radial-gradient(circle, rgba(255, 255, 255, 0.1) 0%, transparent 70%)',
          borderRadius: '50%'
        }} />

        {/* Header Content */}
        <div style={{ position: 'relative', zIndex: 1 }}>
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: isMobile ? 'flex-start' : 'center',
            marginBottom: isMobile ? '1rem' : '1.25rem',
            flexDirection: isMobile ? 'column' : 'row',
            gap: isMobile ? '0.75rem' : '1rem'
          }}>
            <div>
              <h1 style={{
                fontSize: isMobile ? '1.5rem' : '1.75rem',
                fontWeight: 'bold',
                color: '#fff',
                marginBottom: '0.25rem',
                textShadow: '0 2px 10px rgba(0, 0, 0, 0.3)'
              }}>
                Jouw Coaching Journey
              </h1>
              <p style={{ 
                color: 'rgba(255, 255, 255, 0.9)', 
                fontSize: isMobile ? '0.85rem' : '0.95rem',
                lineHeight: '1.4'
              }}>
                6 strategische calls om je doelen te bereiken
              </p>
            </div>
            
            <div style={{ 
              display: 'flex', 
              gap: isMobile ? '0.5rem' : '0.75rem',
              width: isMobile ? '100%' : 'auto'
            }}>
              <button
                onClick={loadCallData}
                className="button-hover"
                style={{
                  flex: isMobile ? 1 : 'none',
                  padding: isMobile ? '0.65rem' : '0.75rem 1.25rem',
                  background: 'rgba(255, 255, 255, 0.2)',
                  backdropFilter: 'blur(10px)',
                  border: '2px solid rgba(255, 255, 255, 0.3)',
                  borderRadius: '10px',
                  color: '#fff',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '0.4rem',
                  cursor: 'pointer',
                  transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                  fontWeight: '600',
                  fontSize: isMobile ? '0.8rem' : '0.875rem',
                  touchAction: 'manipulation',
                  WebkitTapHighlightColor: 'transparent'
                }}
              >
                <RefreshCw size={isMobile ? 16 : 18} />
                <span>Refresh</span>
              </button>
              
              {activePlan && (
                <div style={{ position: 'relative' }}>
                  {/* Tooltip/Info bubble */}
                  <div className="bounce-animation" style={{
                    position: 'absolute',
                    bottom: '120%',
                    right: '0',
                    background: 'linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%)',
                    padding: isMobile ? '0.5rem 0.75rem' : '0.625rem 1rem',
                    borderRadius: '10px',
                    fontSize: isMobile ? '0.65rem' : '0.7rem',
                    color: '#fff',
                    fontWeight: '600',
                    whiteSpace: 'nowrap',
                    boxShadow: '0 4px 15px rgba(139, 92, 246, 0.4)',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.3rem'
                  }}>
                    <Gift size={12} />
                    Extra hulp nodig?
                    <div style={{
                      position: 'absolute',
                      bottom: '-5px',
                      right: '20px',
                      width: '10px',
                      height: '10px',
                      background: 'linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%)',
                      transform: 'rotate(45deg)'
                    }} />
                  </div>
                  
                  <button
                    onClick={() => setShowRequestModal(true)}
                    className="bonus-button"
                    style={{
                      padding: isMobile ? '0.65rem' : '0.75rem 1.25rem',
                      background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.95) 0%, rgba(255, 255, 255, 0.9) 100%)',
                      border: 'none',
                      borderRadius: '10px',
                      color: '#7c3aed',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '0.4rem',
                      cursor: 'pointer',
                      fontWeight: '700',
                      transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                      boxShadow: '0 4px 15px rgba(255, 255, 255, 0.3)',
                      fontSize: isMobile ? '0.8rem' : '0.875rem',
                      touchAction: 'manipulation',
                      WebkitTapHighlightColor: 'transparent',
                      position: 'relative'
                    }}
                  >
                    <Plus size={isMobile ? 16 : 18} />
                    <span>Bonus Call</span>
                    <Sparkles size={12} style={{ marginLeft: '-0.2rem' }} />
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Info Section */}
          <div style={{
            background: 'rgba(255, 255, 255, 0.15)',
            backdropFilter: 'blur(10px)',
            borderRadius: '12px',
            padding: isMobile ? '0.875rem' : '1rem',
            marginBottom: isMobile ? '1rem' : '1.25rem',
            border: '1px solid rgba(255, 255, 255, 0.2)'
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'flex-start',
              gap: '0.75rem'
            }}>
              <HelpCircle size={isMobile ? 18 : 20} style={{ color: '#fff', marginTop: '2px', flexShrink: 0 }} />
              <div style={{ flex: 1 }}>
                <p style={{
                  color: '#fff',
                  fontSize: isMobile ? '0.8rem' : '0.875rem',
                  lineHeight: '1.5',
                  marginBottom: '0.5rem'
                }}>
                  <strong>Hoe werkt het?</strong> Elke call is een strategisch moment in je transformatie. 
                  Plan je calls wanneer het jou uitkomt en krijg direct een Zoom link.
                </p>
              </div>
            </div>
          </div>

          {/* Progress Bar */}
          <ProgressBar 
            calls={calls}
            userStats={userStats}
            progress={progress}
            handleBookCall={handleBookCall}
          />
        </div>
      </div>

      {/* Video Widget */}
      {clientInfo && db && (
        <div style={{ 
          paddingTop: isMobile ? '1rem' : '1.5rem',
          paddingLeft: isMobile ? '1rem' : '1.5rem',
          paddingRight: isMobile ? '1rem' : '1.5rem',
          paddingBottom: '0.5rem',
          position: 'relative',
          zIndex: 10,
          marginBottom: '0.5rem'
        }}>
          <PageVideoWidget
            client={clientInfo}
            db={db}
            pageContext="calls"
            title="Coaching Call Tips & Technieken"
            compact={true}
          />
        </div>
      )}

      {/* Notifications */}
      {notifications.length > 0 && (
        <div style={{
          background: 'linear-gradient(135deg, rgba(251, 191, 36, 0.15) 0%, rgba(251, 191, 36, 0.05) 100%)',
          backdropFilter: 'blur(10px)',
          borderLeft: '4px solid #fbbf24',
          borderRadius: isMobile ? '14px' : '16px',
          padding: isMobile ? '1.25rem' : '1.5rem',
          marginBottom: '2rem',
          border: '1px solid rgba(251, 191, 36, 0.2)',
          animation: 'slideIn 0.3s ease'
        }}>
          <div style={{ display: 'flex', gap: isMobile ? '0.75rem' : '1rem' }}>
            <Bell size={isMobile ? 18 : 20} style={{ color: '#fbbf24', marginTop: '2px', flexShrink: 0 }} />
            <div style={{ flex: 1 }}>
              <h3 style={{ 
                fontWeight: '700', 
                color: '#fff', 
                marginBottom: '0.75rem',
                fontSize: isMobile ? '1rem' : '1.1rem'
              }}>
                Nieuwe Updates
              </h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: isMobile ? '0.5rem' : '0.75rem' }}>
                {notifications.map(notif => (
                  <div 
                    key={notif.id} 
                    style={{ 
                      fontSize: isMobile ? '0.8rem' : '0.875rem', 
                      color: 'rgba(255, 255, 255, 0.9)',
                      padding: isMobile ? '0.625rem' : '0.75rem',
                      background: 'rgba(0, 0, 0, 0.3)',
                      borderRadius: isMobile ? '8px' : '10px',
                      borderLeft: '3px solid #fbbf24',
                      lineHeight: '1.5'
                    }}
                  >
                    {notif.message}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Next Call Highlight */}
      {nextCall && (
        <NextCallHighlight 
          nextCall={nextCall}
          handleBookCall={handleBookCall}
        />
      )}

      {/* Call Cards Grid */}
      <div style={{ marginTop: '2rem' }}>
        <h2 style={{ 
          fontSize: isMobile ? '1.35rem' : '1.6rem', 
          fontWeight: '700', 
          color: '#fff', 
          marginBottom: '1.5rem'
        }}>
          Jouw 6-Call Journey
        </h2>
        
        <div style={{
          display: 'grid',
          gap: isMobile ? '1rem' : '1.5rem',
          gridTemplateColumns: window.innerWidth > 1024 ? 'repeat(3, 1fr)' 
            : window.innerWidth > 640 ? 'repeat(2, 1fr)' 
            : '1fr'
        }}>
          {calls.sort((a, b) => a.call_number - b.call_number).map((call, index) => (
            <CallCard 
              key={call.id}
              call={call}
              index={index}
              handleBookCall={handleBookCall}
            />
          ))}
        </div>
      </div>

      {/* Booking Modal */}
      {showBookingModal && selectedCall && (
        <BookingModal
          selectedCall={selectedCall}
          setShowBookingModal={setShowBookingModal}
          setSelectedCall={setSelectedCall}
          calendlyLoaded={calendlyLoaded}
          setCalendlyLoaded={setCalendlyLoaded}
          modalKey={modalKey}
          calls={calls}
          setCalls={setCalls}
          loadCallData={loadCallData}
        />
      )}

      {/* Bonus Call Request Modal */}
      {showRequestModal && (
        <RequestModal
          setShowRequestModal={setShowRequestModal}
          clientInfo={clientInfo}
          plans={plans}
          loadCallData={loadCallData}
        />
      )}
    </div>
  );
}
