import useIsMobile from '../../hooks/useIsMobile'
import { useState, useEffect } from 'react'
import { User, Mail, Phone, MapPin, Award, Link, Settings, Save, X, Edit, Camera, Shield, Bell, Globe, Briefcase, Calendar, Star, ChevronRight, Check, Activity } from 'lucide-react'

// Color scheme
const profileColors = {
  primary: '#ec4899',
  primaryDark: '#db2777',
  primaryLight: '#f9a8d4',
  gradient: 'linear-gradient(135deg, #ec4899 0%, #db2777 100%)',
  backgroundGradient: 'linear-gradient(135deg, rgba(236, 72, 153, 0.1) 0%, rgba(219, 39, 119, 0.05) 100%)',
  borderColor: 'rgba(236, 72, 153, 0.1)',
  borderActive: 'rgba(236, 72, 153, 0.2)',
  boxShadow: '0 10px 25px rgba(236, 72, 153, 0.25)',
  glow: '0 0 60px rgba(236, 72, 153, 0.1)'
}

// Icon URLs
const iconUrls = {
  profile: "https://kajabi-storefronts-production.kajabi-cdn.com/kajabi-storefronts-production/file-uploads/themes/2161909977/settings_images/1e1d3f-24b5-b48-37a-1537c7b8f05e_MIND_12_.png",
  coach: "https://kajabi-storefronts-production.kajabi-cdn.com/kajabi-storefronts-production/file-uploads/themes/2161909596/settings_images/6fdbdf-1af6-0d32-752b-12f22af8a2ac_IMG_3254.jpeg"
}

export default function CoachProfilePage({ db, user }) {
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [activeSection, setActiveSection] = useState('personal')
  const [isEditing, setIsEditing] = useState(false)
  const [profileData, setProfileData] = useState({
    // Personal Info
    first_name: 'Kersten',
    last_name: 'Scheffer',
    email: user?.email || 'coach@myarc.nl',
    phone: '+31 6 12345678',
    bio: 'Founder van MY ARC • Personal Trainer met 10+ jaar ervaring • Specialist in krachttraining en voeding',
    profile_image: iconUrls.coach,
    location: 'Amsterdam, Nederland',
    
    // Business Info
    business_name: 'MY ARC Fitness',
    specializations: ['Krachttraining', 'Voeding', 'Mindset', 'Lifestyle'],
    certifications: ['NASM-CPT', 'Precision Nutrition L2', 'FMS Level 2'],
    years_experience: 10,
    
    // Social Media
    instagram: '@myarcfitness',
    facebook: 'myarcfitness',
    linkedin: 'kersten-scheffer',
    website: 'www.myarc.nl',
    
    // Settings
    notification_email: true,
    notification_push: true,
    notification_sms: false,
    language: 'nl',
    timezone: 'Europe/Amsterdam'
  })

  const [stats, setStats] = useState({
    totalClients: 24,
    activePrograms: 18,
    completedSessions: 342,
    avgRating: 4.9
  })

  const isMobile = window.innerWidth <= 768

  useEffect(() => {
    loadProfileData()
  }, [user])

  const loadProfileData = async () => {
    setLoading(true)
    try {
      // In productie: await db.getCoachProfile(user.id)
      // Simuleer data loading
      setTimeout(() => {
        setLoading(false)
      }, 500)
    } catch (error) {
      console.error('Error loading profile:', error)
      setLoading(false)
    }
  }

  const handleSave = async () => {
    setSaving(true)
    try {
      // In productie: await db.updateCoachProfile(user.id, profileData)
      await new Promise(resolve => setTimeout(resolve, 1000))
      alert('✅ Profiel succesvol bijgewerkt!')
      setIsEditing(false)
    } catch (error) {
      console.error('Error saving profile:', error)
      alert('❌ Er ging iets mis bij het opslaan')
    } finally {
      setSaving(false)
    }
  }

  const handleInputChange = (field, value) => {
    setProfileData(prev => ({
      ...prev,
      [field]: value
    }))
  }

  const sectionButtons = [
    { id: 'personal', label: 'Persoonlijk', icon: User },
    { id: 'business', label: 'Business', icon: Briefcase },
    { id: 'social', label: 'Social Media', icon: Globe },
    { id: 'settings', label: 'Instellingen', icon: Settings }
  ]

  // Progress Ring Component
  const ProgressRing = ({ progress, size = 60, color = profileColors.primary }) => {
    const radius = (size - 8) / 2
    const circumference = 2 * Math.PI * radius
    const strokeDashoffset = circumference - (progress / 100) * circumference

    return (
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        <circle
          cx={size/2}
          cy={size/2}
          r={radius}
          stroke="rgba(255,255,255,0.08)"
          strokeWidth="4"
          fill="none"
        />
        <circle
          cx={size/2}
          cy={size/2}
          r={radius}
          stroke={color}
          strokeWidth="4"
          fill="none"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          style={{ 
            transition: 'stroke-dashoffset 1s cubic-bezier(0.4, 0, 0.2, 1)',
            filter: `drop-shadow(0 0 6px ${color}44)`
          }}
        />
      </svg>
    )
  }

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(180deg, #0a0f0d 0%, #1a1a1a 100%)',
      padding: isMobile ? '0.5rem' : '1rem',
      paddingBottom: '2rem'
    }}>
      {/* Profile Header */}
      <div style={{
        background: profileColors.gradient,
        borderRadius: isMobile ? '16px' : '24px',
        padding: isMobile ? '1.5rem' : '2rem',
        marginBottom: '2rem',
        position: 'relative',
        overflow: 'hidden',
        boxShadow: profileColors.boxShadow
      }}>
        {/* Animated Background Pattern */}
        <div style={{
          position: 'absolute',
          top: '-50%',
          right: '-10%',
          width: '400px',
          height: '400px',
          background: 'radial-gradient(circle, rgba(255, 255, 255, 0.1) 0%, transparent 70%)',
          borderRadius: '50%',
          animation: 'float 6s ease-in-out infinite'
        }} />
        
        <div style={{ position: 'relative', zIndex: 1 }}>
          {/* Profile Image and Info */}
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: isMobile ? '1rem' : '1.5rem',
            marginBottom: '1.5rem'
          }}>
            <div style={{
              position: 'relative',
              width: isMobile ? '80px' : '100px',
              height: isMobile ? '80px' : '100px'
            }}>
              <img 
                src={profileData.profile_image}
                alt="Profile"
                style={{
                  width: '100%',
                  height: '100%',
                  borderRadius: '50%',
                  border: '4px solid rgba(255,255,255,0.2)',
                  objectFit: 'cover'
                }}
              />
              {isEditing && (
                <button style={{
                  position: 'absolute',
                  bottom: 0,
                  right: 0,
                  width: '32px',
                  height: '32px',
                  borderRadius: '50%',
                  background: '#fff',
                  border: 'none',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  cursor: 'pointer',
                  boxShadow: '0 2px 8px rgba(0,0,0,0.2)'
                }}>
                  <Camera size={16} color={profileColors.primary} />
                </button>
              )}
            </div>
            
            <div style={{ flex: 1 }}>
              <h1 style={{
                fontSize: isMobile ? '1.5rem' : '2rem',
                fontWeight: 'bold',
                color: '#fff',
                marginBottom: '0.25rem',
                textShadow: '0 2px 10px rgba(0,0,0,0.3)'
              }}>
                {profileData.first_name} {profileData.last_name}
              </h1>
              <p style={{
                fontSize: isMobile ? '0.875rem' : '1rem',
                color: 'rgba(255,255,255,0.9)',
                marginBottom: '0.5rem'
              }}>
                {profileData.business_name}
              </p>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
                fontSize: '0.875rem',
                color: 'rgba(255,255,255,0.8)'
              }}>
                <MapPin size={14} />
                {profileData.location}
              </div>
            </div>

            {/* Edit Button */}
            {!isEditing ? (
              <button
                onClick={() => setIsEditing(true)}
                style={{
                  padding: '0.5rem 1rem',
                  background: 'rgba(255,255,255,0.2)',
                  border: '1px solid rgba(255,255,255,0.3)',
                  borderRadius: '8px',
                  color: '#fff',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.5rem',
                  fontSize: '0.875rem',
                  fontWeight: '600',
                  backdropFilter: 'blur(10px)'
                }}
              >
                <Edit size={16} />
                Bewerk
              </button>
            ) : (
              <div style={{ display: 'flex', gap: '0.5rem' }}>
                <button
                  onClick={handleSave}
                  disabled={saving}
                  style={{
                    padding: '0.5rem 1rem',
                    background: '#fff',
                    border: 'none',
                    borderRadius: '8px',
                    color: profileColors.primary,
                    cursor: saving ? 'not-allowed' : 'pointer',
                    fontWeight: '600',
                    opacity: saving ? 0.7 : 1
                  }}
                >
                  {saving ? 'Opslaan...' : <Save size={16} />}
                </button>
                <button
                  onClick={() => setIsEditing(false)}
                  style={{
                    padding: '0.5rem 1rem',
                    background: 'rgba(255,255,255,0.2)',
                    border: '1px solid rgba(255,255,255,0.3)',
                    borderRadius: '8px',
                    color: '#fff',
                    cursor: 'pointer'
                  }}
                >
                  <X size={16} />
                </button>
              </div>
            )}
          </div>

          {/* Stats */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(4, 1fr)',
            gap: isMobile ? '0.75rem' : '1rem'
          }}>
            {[
              { label: 'Clients', value: stats.totalClients, icon: User },
              { label: 'Programma\'s', value: stats.activePrograms, icon: Activity },
              { label: 'Sessies', value: stats.completedSessions, icon: Calendar },
              { label: 'Rating', value: stats.avgRating, icon: Star }
            ].map((stat, index) => (
              <div key={index} style={{
                background: 'rgba(255,255,255,0.1)',
                backdropFilter: 'blur(10px)',
                borderRadius: '12px',
                padding: isMobile ? '0.75rem' : '1rem',
                textAlign: 'center',
                border: '1px solid rgba(255,255,255,0.1)'
              }}>
                <stat.icon size={16} color="rgba(255,255,255,0.7)" style={{ marginBottom: '0.25rem' }} />
                <div style={{
                  fontSize: isMobile ? '1.25rem' : '1.5rem',
                  fontWeight: 'bold',
                  color: '#fff'
                }}>
                  {stat.value}
                </div>
                <div style={{
                  fontSize: '0.7rem',
                  color: 'rgba(255,255,255,0.7)',
                  marginTop: '0.25rem'
                }}>
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Section Tabs */}
      <div style={{
        display: 'flex',
        gap: '0.5rem',
        marginBottom: '1.5rem',
        overflowX: 'auto',
        WebkitOverflowScrolling: 'touch',
        scrollbarWidth: 'none',
        msOverflowStyle: 'none'
      }}>
        {sectionButtons.map(section => {
          const Icon = section.icon
          const isActive = activeSection === section.id
          
          return (
            <button
              key={section.id}
              onClick={() => setActiveSection(section.id)}
              style={{
                padding: '0.75rem 1.25rem',
                background: isActive ? profileColors.backgroundGradient : 'rgba(255,255,255,0.03)',
                border: `1px solid ${isActive ? profileColors.borderActive : profileColors.borderColor}`,
                borderRadius: '12px',
                color: isActive ? profileColors.primary : 'rgba(255,255,255,0.6)',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
                fontSize: '0.875rem',
                fontWeight: '600',
                transition: 'all 0.3s ease',
                whiteSpace: 'nowrap'
              }}
            >
              <Icon size={16} />
              {section.label}
            </button>
          )
        })}
      </div>

      {/* Content Sections */}
      <div style={{
        background: 'rgba(255,255,255,0.03)',
        backdropFilter: 'blur(10px)',
        borderRadius: '16px',
        padding: isMobile ? '1.25rem' : '1.5rem',
        border: `1px solid ${profileColors.borderColor}`,
        minHeight: '400px'
      }}>
        {/* Personal Section */}
        {activeSection === 'personal' && (
          <div>
            <h3 style={{
              fontSize: '1.25rem',
              fontWeight: 'bold',
              color: profileColors.primary,
              marginBottom: '1.5rem',
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem'
            }}>
              <User size={20} />
              Persoonlijke Informatie
            </h3>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              <div style={{ display: 'grid', gridTemplateColumns: isMobile ? '1fr' : '1fr 1fr', gap: '1rem' }}>
                <div>
                  <label style={{ fontSize: '0.875rem', color: 'rgba(255,255,255,0.6)', marginBottom: '0.5rem', display: 'block' }}>
                    Voornaam
                  </label>
                  <input
                    type="text"
                    value={profileData.first_name}
                    onChange={(e) => handleInputChange('first_name', e.target.value)}
                    disabled={!isEditing}
                    style={{
                      width: '100%',
                      padding: '0.75rem',
                      background: isEditing ? 'rgba(255,255,255,0.05)' : 'transparent',
                      border: `1px solid ${isEditing ? profileColors.borderActive : profileColors.borderColor}`,
                      borderRadius: '8px',
                      color: '#fff',
                      fontSize: '1rem'
                    }}
                  />
                </div>

                <div>
                  <label style={{ fontSize: '0.875rem', color: 'rgba(255,255,255,0.6)', marginBottom: '0.5rem', display: 'block' }}>
                    Achternaam
                  </label>
                  <input
                    type="text"
                    value={profileData.last_name}
                    onChange={(e) => handleInputChange('last_name', e.target.value)}
                    disabled={!isEditing}
                    style={{
                      width: '100%',
                      padding: '0.75rem',
                      background: isEditing ? 'rgba(255,255,255,0.05)' : 'transparent',
                      border: `1px solid ${isEditing ? profileColors.borderActive : profileColors.borderColor}`,
                      borderRadius: '8px',
                      color: '#fff',
                      fontSize: '1rem'
                    }}
                  />
                </div>
              </div>

              <div>
                <label style={{ fontSize: '0.875rem', color: 'rgba(255,255,255,0.6)', marginBottom: '0.5rem', display: 'block' }}>
                  <Mail size={14} style={{ display: 'inline', marginRight: '0.25rem' }} />
                  Email
                </label>
                <input
                  type="email"
                  value={profileData.email}
                  disabled
                  style={{
                    width: '100%',
                    padding: '0.75rem',
                    background: 'transparent',
                    border: `1px solid ${profileColors.borderColor}`,
                    borderRadius: '8px',
                    color: 'rgba(255,255,255,0.5)',
                    fontSize: '1rem'
                  }}
                />
              </div>

              <div>
                <label style={{ fontSize: '0.875rem', color: 'rgba(255,255,255,0.6)', marginBottom: '0.5rem', display: 'block' }}>
                  <Phone size={14} style={{ display: 'inline', marginRight: '0.25rem' }} />
                  Telefoon
                </label>
                <input
                  type="tel"
                  value={profileData.phone}
                  onChange={(e) => handleInputChange('phone', e.target.value)}
                  disabled={!isEditing}
                  style={{
                    width: '100%',
                    padding: '0.75rem',
                    background: isEditing ? 'rgba(255,255,255,0.05)' : 'transparent',
                    border: `1px solid ${isEditing ? profileColors.borderActive : profileColors.borderColor}`,
                    borderRadius: '8px',
                    color: '#fff',
                    fontSize: '1rem'
                  }}
                />
              </div>

              <div>
                <label style={{ fontSize: '0.875rem', color: 'rgba(255,255,255,0.6)', marginBottom: '0.5rem', display: 'block' }}>
                  Bio
                </label>
                <textarea
                  value={profileData.bio}
                  onChange={(e) => handleInputChange('bio', e.target.value)}
                  disabled={!isEditing}
                  rows={4}
                  style={{
                    width: '100%',
                    padding: '0.75rem',
                    background: isEditing ? 'rgba(255,255,255,0.05)' : 'transparent',
                    border: `1px solid ${isEditing ? profileColors.borderActive : profileColors.borderColor}`,
                    borderRadius: '8px',
                    color: '#fff',
                    fontSize: '1rem',
                    resize: 'none'
                  }}
                />
              </div>
            </div>
          </div>
        )}

        {/* Business Section */}
        {activeSection === 'business' && (
          <div>
            <h3 style={{
              fontSize: '1.25rem',
              fontWeight: 'bold',
              color: profileColors.primary,
              marginBottom: '1.5rem',
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem'
            }}>
              <Briefcase size={20} />
              Business Informatie
            </h3>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              <div>
                <label style={{ fontSize: '0.875rem', color: 'rgba(255,255,255,0.6)', marginBottom: '0.5rem', display: 'block' }}>
                  Bedrijfsnaam
                </label>
                <input
                  type="text"
                  value={profileData.business_name}
                  onChange={(e) => handleInputChange('business_name', e.target.value)}
                  disabled={!isEditing}
                  style={{
                    width: '100%',
                    padding: '0.75rem',
                    background: isEditing ? 'rgba(255,255,255,0.05)' : 'transparent',
                    border: `1px solid ${isEditing ? profileColors.borderActive : profileColors.borderColor}`,
                    borderRadius: '8px',
                    color: '#fff',
                    fontSize: '1rem'
                  }}
                />
              </div>

              <div>
                <label style={{ fontSize: '0.875rem', color: 'rgba(255,255,255,0.6)', marginBottom: '0.5rem', display: 'block' }}>
                  Specialisaties
                </label>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
                  {profileData.specializations.map((spec, index) => (
                    <span key={index} style={{
                      padding: '0.5rem 1rem',
                      background: profileColors.backgroundGradient,
                      borderRadius: '20px',
                      fontSize: '0.875rem',
                      color: profileColors.primary,
                      border: `1px solid ${profileColors.borderActive}`
                    }}>
                      {spec}
                    </span>
                  ))}
                  {isEditing && (
                    <button style={{
                      padding: '0.5rem 1rem',
                      background: 'transparent',
                      border: `1px dashed ${profileColors.borderActive}`,
                      borderRadius: '20px',
                      fontSize: '0.875rem',
                      color: profileColors.primary,
                      cursor: 'pointer'
                    }}>
                      + Toevoegen
                    </button>
                  )}
                </div>
              </div>

              <div>
                <label style={{ fontSize: '0.875rem', color: 'rgba(255,255,255,0.6)', marginBottom: '0.5rem', display: 'block' }}>
                  Certificaten
                </label>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                  {profileData.certifications.map((cert, index) => (
                    <div key={index} style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.5rem',
                      padding: '0.75rem',
                      background: 'rgba(255,255,255,0.03)',
                      borderRadius: '8px',
                      border: `1px solid ${profileColors.borderColor}`
                    }}>
                      <Award size={16} color={profileColors.primary} />
                      <span style={{ color: '#fff', fontSize: '0.875rem' }}>{cert}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <label style={{ fontSize: '0.875rem', color: 'rgba(255,255,255,0.6)', marginBottom: '0.5rem', display: 'block' }}>
                  Jaren Ervaring
                </label>
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '1rem'
                }}>
                  <input
                    type="number"
                    value={profileData.years_experience}
                    onChange={(e) => handleInputChange('years_experience', e.target.value)}
                    disabled={!isEditing}
                    style={{
                      width: '100px',
                      padding: '0.75rem',
                      background: isEditing ? 'rgba(255,255,255,0.05)' : 'transparent',
                      border: `1px solid ${isEditing ? profileColors.borderActive : profileColors.borderColor}`,
                      borderRadius: '8px',
                      color: '#fff',
                      fontSize: '1rem',
                      textAlign: 'center'
                    }}
                  />
                  <span style={{ color: 'rgba(255,255,255,0.6)' }}>jaar</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Social Media Section */}
        {activeSection === 'social' && (
          <div>
            <h3 style={{
              fontSize: '1.25rem',
              fontWeight: 'bold',
              color: profileColors.primary,
              marginBottom: '1.5rem',
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem'
            }}>
              <Globe size={20} />
              Social Media & Website
            </h3>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              {[
                { label: 'Instagram', field: 'instagram', placeholder: '@username' },
                { label: 'Facebook', field: 'facebook', placeholder: 'facebook.com/...' },
                { label: 'LinkedIn', field: 'linkedin', placeholder: 'linkedin.com/in/...' },
                { label: 'Website', field: 'website', placeholder: 'www.example.com' }
              ].map((social) => (
                <div key={social.field}>
                  <label style={{ fontSize: '0.875rem', color: 'rgba(255,255,255,0.6)', marginBottom: '0.5rem', display: 'block' }}>
                    {social.label}
                  </label>
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <input
                      type="text"
                      value={profileData[social.field]}
                      onChange={(e) => handleInputChange(social.field, e.target.value)}
                      disabled={!isEditing}
                      placeholder={social.placeholder}
                      style={{
                        flex: 1,
                        padding: '0.75rem',
                        background: isEditing ? 'rgba(255,255,255,0.05)' : 'transparent',
                        border: `1px solid ${isEditing ? profileColors.borderActive : profileColors.borderColor}`,
                        borderRadius: '8px',
                        color: '#fff',
                        fontSize: '1rem'
                      }}
                    />
                    {!isEditing && profileData[social.field] && (
                      <button style={{
                        padding: '0.75rem',
                        background: profileColors.backgroundGradient,
                        border: `1px solid ${profileColors.borderActive}`,
                        borderRadius: '8px',
                        color: profileColors.primary,
                        cursor: 'pointer'
                      }}>
                        <Link size={16} />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Settings Section */}
        {activeSection === 'settings' && (
          <div>
            <h3 style={{
              fontSize: '1.25rem',
              fontWeight: 'bold',
              color: profileColors.primary,
              marginBottom: '1.5rem',
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem'
            }}>
              <Settings size={20} />
              Instellingen
            </h3>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
              {/* Notifications */}
              <div>
                <h4 style={{ color: '#fff', fontSize: '1rem', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <Bell size={16} />
                  Notificaties
                </h4>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                  {[
                    { label: 'Email notificaties', field: 'notification_email' },
                    { label: 'Push notificaties', field: 'notification_push' },
                    { label: 'SMS notificaties', field: 'notification_sms' }
                  ].map((setting) => (
                    <label key={setting.field} style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      padding: '0.75rem',
                      background: 'rgba(255,255,255,0.03)',
                      borderRadius: '8px',
                      border: `1px solid ${profileColors.borderColor}`,
                      cursor: isEditing ? 'pointer' : 'default'
                    }}>
                      <span style={{ color: 'rgba(255,255,255,0.8)', fontSize: '0.875rem' }}>
                        {setting.label}
                      </span>
                      <div style={{
                        position: 'relative',
                        width: '48px',
                        height: '24px',
                        borderRadius: '12px',
                        background: profileData[setting.field] ? profileColors.gradient : 'rgba(255,255,255,0.1)',
                        transition: 'background 0.3s ease',
                        cursor: isEditing ? 'pointer' : 'not-allowed',
                        opacity: isEditing ? 1 : 0.5
                      }}>
                        <div style={{
                          position: 'absolute',
                          top: '2px',
                          left: profileData[setting.field] ? '24px' : '2px',
                          width: '20px',
                          height: '20px',
                          borderRadius: '50%',
                          background: '#fff',
                          transition: 'left 0.3s ease',
                          boxShadow: '0 2px 4px rgba(0,0,0,0.2)'
                        }} />
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              {/* Language & Region */}
              <div>
                <h4 style={{ color: '#fff', fontSize: '1rem', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <Globe size={16} />
                  Taal & Regio
                </h4>
                <div style={{ display: 'grid', gridTemplateColumns: isMobile ? '1fr' : '1fr 1fr', gap: '1rem' }}>
                  <div>
                    <label style={{ fontSize: '0.875rem', color: 'rgba(255,255,255,0.6)', marginBottom: '0.5rem', display: 'block' }}>
                      Taal
                    </label>
                    <select
                      value={profileData.language}
                      onChange={(e) => handleInputChange('language', e.target.value)}
                      disabled={!isEditing}
                      style={{
                        width: '100%',
                        padding: '0.75rem',
                        background: isEditing ? 'rgba(255,255,255,0.05)' : 'transparent',
                        border: `1px solid ${isEditing ? profileColors.borderActive : profileColors.borderColor}`,
                        borderRadius: '8px',
                        color: '#fff',
                        fontSize: '1rem',
                        cursor: isEditing ? 'pointer' : 'not-allowed'
                      }}
                    >
                      <option value="nl" style={{ background: '#1a1a1a' }}>Nederlands</option>
                      <option value="en" style={{ background: '#1a1a1a' }}>English</option>
                    </select>
                  </div>

                  <div>
                    <label style={{ fontSize: '0.875rem', color: 'rgba(255,255,255,0.6)', marginBottom: '0.5rem', display: 'block' }}>
                      Tijdzone
                    </label>
                    <select
                      value={profileData.timezone}
                      onChange={(e) => handleInputChange('timezone', e.target.value)}
                      disabled={!isEditing}
                      style={{
                        width: '100%',
                        padding: '0.75rem',
                        background: isEditing ? 'rgba(255,255,255,0.05)' : 'transparent',
                        border: `1px solid ${isEditing ? profileColors.borderActive : profileColors.borderColor}`,
                        borderRadius: '8px',
                        color: '#fff',
                        fontSize: '1rem',
                        cursor: isEditing ? 'pointer' : 'not-allowed'
                      }}
                    >
                      <option value="Europe/Amsterdam" style={{ background: '#1a1a1a' }}>Amsterdam (CET)</option>
                      <option value="Europe/London" style={{ background: '#1a1a1a' }}>London (GMT)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Security */}
              <div>
                <h4 style={{ color: '#fff', fontSize: '1rem', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <Shield size={16} />
                  Beveiliging
                </h4>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                  <button style={{
                    padding: '0.75rem',
                    background: 'rgba(255,255,255,0.03)',
                    border: `1px solid ${profileColors.borderColor}`,
                    borderRadius: '8px',
                    color: 'rgba(255,255,255,0.8)',
                    fontSize: '0.875rem',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between'
                  }}>
                    <span>Wachtwoord wijzigen</span>
                    <ChevronRight size={16} />
                  </button>

                  <button style={{
                    padding: '0.75rem',
                    background: 'rgba(255,255,255,0.03)',
                    border: `1px solid ${profileColors.borderColor}`,
                    borderRadius: '8px',
                    color: 'rgba(255,255,255,0.8)',
                    fontSize: '0.875rem',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between'
                  }}>
                    <span>Two-Factor Authentication</span>
                    <ChevronRight size={16} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Logout Button */}
      <button
        onClick={async () => {
          await db.signOut()
          window.location.href = '/'
        }}
        style={{
          width: '100%',
          marginTop: '2rem',
          padding: '1rem',
          background: 'linear-gradient(135deg, #7f1d1d 0%, #ef4444 100%)',
          border: 'none',
          borderRadius: '12px',
          color: '#fff',
          cursor: 'pointer',
          fontSize: '1rem',
          fontWeight: 'bold',
          transition: 'all 0.3s'
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.transform = 'scale(1.02)'
          e.currentTarget.style.boxShadow = '0 4px 8px rgba(239, 68, 68, 0.3)'
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.transform = 'scale(1)'
          e.currentTarget.style.boxShadow = 'none'
        }}
      >
        Uitloggen
      </button>

      {/* Animations */}
      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-20px); }
        }
      `}</style>
    </div>
  )
}
